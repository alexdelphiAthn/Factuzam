{******************************************************************************}
{                                                                              }
{  Módulo:       UniDataComprasSesionesRepositorio                             }
{    Tipo:       Repositorio                                                   }
{ Versión:       1.0.0                                                         }
{   Fecha:       29/07/2026                                                    }
{   Autor:       Alejandro Laorden Hidalgo                                     }
{                                                                              }
{  Copyright (c) Alejandro Laorden Hidalgo. Todos los derechos reservados.     }
{                                                                              }
{  Descripción:                                                                }
{    Persistencia UniDAC de sesiones de compra con SQL configurable.           }
{******************************************************************************}
unit UniDataComprasSesionesRepositorio;

interface

uses
  Uni, inLibCatalogoSqlIntf, inLibComprasSesionesIntf;

type
  TRepositorioComprasSesiones = class(
    TInterfacedObject,
    IRepositorioComprasSesiones)
  private
    FConexion: TUniConnection;
    FCatalogoSql: ICatalogoSql;
    FIncidenciasSql: IRegistroIncidenciasSql;
    function EjecutarObtenerSiguienteLinea(
      const ASql, ASerie, ANumero: string;
      ALineaActual: Integer): Integer;
    function EjecutarConsultarCantidadesLinea(
      const ASql, ASerie, ANumero: string;
      ALinea: Integer): TCantidadesPivotSesion;
  public
    constructor Create(
      AConexion: TUniConnection;
      const ACatalogoSql: ICatalogoSql;
      const AIncidenciasSql: IRegistroIncidenciasSql = nil);
    class function DefinicionesSql:
      TDefinicionesSql; static;
    function ObtenerSiguienteLinea(
      const ASerie, ANumero: string;
      ALineaActual: Integer): Integer;
    function ConsultarCantidadesLinea(
      const ASerie, ANumero: string;
      ALinea: Integer): TCantidadesPivotSesion;
  end;

implementation

uses
  System.SysUtils, inLibCatalogoSqlEjecucion;

const
  SQL_SIGUIENTE_LINEA =
    'SELECT MIN(LINEA_SESLIN) AS SIGUIENTE ' +
    '  FROM fza_compras_sesiones_lineas ' +
    ' WHERE SERIE_SES_SESLIN = :s ' +
    '   AND NUMERO_SES_SESLIN = :n ' +
    '   AND LINEA_SESLIN > :l';
  SQL_CANTIDADES_LINEA =
    'SELECT ID_AV_PIVOT_SESCEL, ' +
    '       SUM(CANTIDAD_SESCEL) AS TOTAL ' +
    '  FROM fza_compras_sesiones_celdas ' +
    ' WHERE SERIE_SES_SESCEL = :s ' +
    '   AND NUMERO_SES_SESCEL = :n ' +
    '   AND LINEA_SES_SESCEL = :l ' +
    ' GROUP BY ID_AV_PIVOT_SESCEL';

function DefinicionSiguienteLinea: TDefinicionSql;
begin
  Result := CrearDefinicionSql(
    'RepositorioComprasSesiones',
    'ObtenerSiguienteLinea',
    SQL_SIGUIENTE_LINEA,
    's,n,l',
    'SIGUIENTE',
    tssSelect,
    pesPerfilLecturaConFallback);
end;

function DefinicionCantidadesLinea: TDefinicionSql;
begin
  Result := CrearDefinicionSql(
    'RepositorioComprasSesiones',
    'ConsultarCantidadesLinea',
    SQL_CANTIDADES_LINEA,
    's,n,l',
    'ID_AV_PIVOT_SESCEL,TOTAL',
    tssSelect,
    pesPerfilLecturaConFallback);
end;

constructor TRepositorioComprasSesiones.Create(
  AConexion: TUniConnection;
  const ACatalogoSql: ICatalogoSql;
  const AIncidenciasSql: IRegistroIncidenciasSql);
begin
  inherited Create;
  FConexion := AConexion;
  FCatalogoSql := ACatalogoSql;
  FIncidenciasSql := AIncidenciasSql;
end;

class function TRepositorioComprasSesiones.DefinicionesSql:
  TDefinicionesSql;
begin
  SetLength(Result, 2);
  Result[0] := DefinicionSiguienteLinea;
  Result[1] := DefinicionCantidadesLinea;
end;

function TRepositorioComprasSesiones.EjecutarObtenerSiguienteLinea(
  const ASql, ASerie, ANumero: string;
  ALineaActual: Integer): Integer;
var
  oConsulta: TUniQuery;
begin
  Result := 0;
  oConsulta := TUniQuery.Create(nil);
  try
    oConsulta.Connection := FConexion;
    oConsulta.SQL.Text := ASql;
    oConsulta.ParamByName('s').AsString := ASerie;
    oConsulta.ParamByName('n').AsString := ANumero;
    oConsulta.ParamByName('l').AsInteger := ALineaActual;
    oConsulta.Open;
    if not oConsulta.FieldByName('SIGUIENTE').IsNull then
      Result := oConsulta.FieldByName(
        'SIGUIENTE').AsInteger;
  finally
    FreeAndNil(oConsulta);
  end;
end;

function TRepositorioComprasSesiones.EjecutarConsultarCantidadesLinea(
  const ASql, ASerie, ANumero: string;
  ALinea: Integer): TCantidadesPivotSesion;
var
  iIndice: Integer;
  oConsulta: TUniQuery;
begin
  Result := nil;
  oConsulta := TUniQuery.Create(nil);
  try
    oConsulta.Connection := FConexion;
    oConsulta.SQL.Text := ASql;
    oConsulta.ParamByName('s').AsString := ASerie;
    oConsulta.ParamByName('n').AsString := ANumero;
    oConsulta.ParamByName('l').AsInteger := ALinea;
    oConsulta.Open;
    SetLength(Result, oConsulta.RecordCount);
    iIndice := 0;
    while not oConsulta.Eof do
    begin
      Result[iIndice].IdValorPivot :=
        oConsulta.FieldByName(
          'ID_AV_PIVOT_SESCEL').AsInteger;
      Result[iIndice].Cantidad :=
        oConsulta.FieldByName('TOTAL').AsFloat;
      Inc(iIndice);
      oConsulta.Next;
    end;
  finally
    FreeAndNil(oConsulta);
  end;
end;

function TRepositorioComprasSesiones.ObtenerSiguienteLinea(
  const ASerie, ANumero: string;
  ALineaActual: Integer): Integer;
var
  oDefinicion: TDefinicionSql;
  iSiguiente: Integer;
begin
  oDefinicion := DefinicionSiguienteLinea;
  iSiguiente := 0;
  EjecutarLecturaSqlConFallback(
    oDefinicion,
    FCatalogoSql,
    procedure(const ASql: string)
    begin
      iSiguiente := EjecutarObtenerSiguienteLinea(
        ASql,
        ASerie,
        ANumero,
        ALineaActual);
    end,
    FIncidenciasSql);
  Result := iSiguiente;
end;

function TRepositorioComprasSesiones.ConsultarCantidadesLinea(
  const ASerie, ANumero: string;
  ALinea: Integer): TCantidadesPivotSesion;
var
  oCantidades: TCantidadesPivotSesion;
  oDefinicion: TDefinicionSql;
begin
  oDefinicion := DefinicionCantidadesLinea;
  oCantidades := nil;
  EjecutarLecturaSqlConFallback(
    oDefinicion,
    FCatalogoSql,
    procedure(const ASql: string)
    begin
      oCantidades := EjecutarConsultarCantidadesLinea(
        ASql,
        ASerie,
        ANumero,
        ALinea);
    end,
    FIncidenciasSql);
  Result := oCantidades;
end;

end.
