{******************************************************************************}
{                                                                              }
{  Módulo:       UniDataCatalogoSqlAplicacion                                  }
{    Tipo:       Composición                                                   }
{ Versión:       1.0.0                                                         }
{   Fecha:       30/07/2026                                                    }
{   Autor:       Alejandro Laorden Hidalgo                                     }
{                                                                              }
{  Copyright (c) Alejandro Laorden Hidalgo. Todos los derechos reservados.     }
{                                                                              }
{  Descripción:                                                                }
{    Compone el registro completo de definiciones SQL de la aplicación.        }
{******************************************************************************}
unit UniDataCatalogoSqlAplicacion;

interface

uses
  inLibCatalogoSqlIntf;

function CrearRegistroDefinicionesSqlAplicacion:
  IRegistroDefinicionesSql;

implementation

uses
  inLibCatalogoSqlRegistro,
  UniDataComprasSesionesRepositorio;

function CrearRegistroDefinicionesSqlAplicacion:
  IRegistroDefinicionesSql;
var
  oRegistro: TRegistroDefinicionesSql;
begin
  oRegistro := TRegistroDefinicionesSql.Create;
  oRegistro.AgregarRango(
    TRepositorioComprasSesiones.DefinicionesSql);
  Result := oRegistro;
end;

end.
