﻿{******************************************************************************}
{                                                                              }
{  Módulo:       inMtoCajaOpe                                                  }
{    Tipo:       Formulario (Mto)                                              }
{ Versión:       1.0.0                                                         }
{   Fecha:       11/05/2026                                                    }
{   Autor:       Alejandro Laorden Hidalgo                                     }
{                                                                              }
{  Copyright (c) Alejandro Laorden Hidalgo. Todos los derechos reservados.     }
{                                                                              }
{  Descripción:                                                                }
{    Operativa de caja: introduccion de lineas de venta.                       }
{    Captura articulos, atributos y descuentos del ticket actual.              }
{******************************************************************************}
unit inMtoCajaOpe;

interface

uses
  Winapi.Windows, Winapi.Messages, System.SysUtils, System.Variants,
  System.Classes, Vcl.Graphics, inMtoGenSearch, system.Math, inMtoFrmBase,
  Vcl.Controls, Vcl.Forms, Vcl.Dialogs, cxGraphics, cxControls, cxLookAndFeels,
  cxLookAndFeelPainters, cxContainer, cxEdit, dxCoreGraphics, cxTextEdit,
  cxMaskEdit, cxButtonEdit, Vcl.ExtCtrls, cxLabel, Vcl.Menus, cxStyles,
  cxCustomData, cxFilter, cxData, cxDataStorage, cxNavigator, dxDateRanges,
  dxScrollbarAnnotations, Data.DB, Data.FmtBcd, Data.SqlTimSt, cxDBData,
  cxClasses, cxGridCustomTableView, system.types,
  cxGridTableView, cxGridDBTableView, cxGridLevel, cxGridCustomView, cxGrid,
  Vcl.StdCtrls, cxButtons, Datasnap.DBClient, Datasnap.Provider, UniDataCaja,
  JvComponentBase, JvEnterTab, cxDropDownEdit, cxFontNameComboBox, Uni,
  cxCurrencyEdit, cxSpinEdit, cxSplitter, cxDBLookupComboBox,
  cxDBExtLookupComboBox, MemDS, DBAccess, cxEditRepositoryItems, system.UITypes,
  System.Actions, Vcl.ActnList, Vcl.Imaging.PngImage, inLibFotos,
  System.Generics.Collections, System.Diagnostics, cxLocalization,
  inLibLectorScanner, inLibCajaTipos, inLibCajaVentanasIntf,
  inLibCajaVentaIntf, inLibCatalogoSqlIntf;

const
  WM_CANCELAR_LINEA = WM_APP + 100;
  WM_SALTAR_ATRIBUTO = WM_APP + 101;
  // Diferimos FinalizarUltimoAtributo / avance de columna fuera del
  // OnButtonClick del TcxButtonEdit. Si los ejecutamos en linea, cxGrid
  // sigue manteniendo referencia al editor inplace que acaba de procesar
  // el popup; cuando FinalizarUltimoAtributo lanza el ShowMessage de
  // "no hay stock" y luego dispara DataChange via EnableControls/Append,
  // el editor inplace se desparenta y salta EInvalidOperation. Con
  // PostMessage el click handler retorna, cxGrid limpia su estado y
  // luego procesamos.
  WM_FINALIZAR_ATRIB_CAJA = WM_APP + 102;
  WM_AVANZAR_ATRIB_CAJA   = WM_APP + 103;
  // Diferimos tambien la apertura del popup desde el OnEnter del
  // TcxButtonEdit. Cuando WMAvanzarAtribCaja salta de Color a Talla,
  // ShowEdit -> InitEdit -> OnEnter ocurren en cadena en el mismo
  // callstack; el editor inplace de la talla aun no esta del todo
  // colocado y ClientToScreen pide Handle -> Parent -> EInvalidOperation.
  // Con PostMessage, OnEnter retorna, cxGrid termina de parentar, y solo
  // entonces abrimos el popup.
  WM_ABRIR_POPUP_AV       = WM_APP + 104;
  // El grid termina de crear la fila después del cambio de dataset. El foco
  // se aplica en un mensaje posterior para que no restaure la columna previa.
  WM_ENFOCAR_ARTICULO_CAJA = WM_APP + 105;
type
  TfrmMtoOpeCaja = class(TfrmBase, IOperacionCaja)
    pnlUp: TPanel;
    pnlCli: TPanel;
    lblFecha: TcxLabel;
    pnlAccionesIzq: TPanel;
    btnF12: TcxButton;
    btnF3: TcxButton;
    btnF6: TcxButton;
    btnF5: TcxButton;
    btnF7: TcxButton;
    lblCobro: TcxLabel;
    lblBuscar: TcxLabel;
    lblTextoTarifa: TcxLabel;
    lblIndIVA: TcxLabel;
    lblOtro: TcxLabel;
    pnlAccionesDer: TPanel;
    cxgrdLineasOpe: TcxGrid;
    tvLineasOpe: TcxGridDBTableView;
    cxgrdlvlLineasOpe: TcxGridLevel;
    tvEmpleado: TcxGridDBColumn;
    tvArticulo: TcxGridDBColumn;
    tvDescripcion: TcxGridDBColumn;
    tvUds: TcxGridDBColumn;
    tvTipoCantidad: TcxGridDBColumn;
    tvPrecioUni: TcxGridDBColumn;
    tvDescuento: TcxGridDBColumn;
    tvDescuentoMenos: TcxGridDBColumn;
    tvTotal: TcxGridDBColumn;
    tvFechaOperacion: TcxGridDBColumn;
    lblTotal: TcxLabel;
    btnF8: TcxButton;
    lblEliminar: TcxLabel;
    lblNombreEmpleado: TcxLabel;
    lblCliente: TcxLabel;
    btnCodigoCliente: TcxButtonEdit;
    lblNombreCliente: TcxLabel;
    tmrReloj: TTimer;
    dsLineas: TDataSource;
    jvEnterTab: TJvEnterAsTab;
    lblFechaCaja: TcxLabel;
    btnCodigoEmpleado: TcxButtonEdit;
    lblTarifa: TcxLabel;
    lblInstrucciones: TcxLabel;
    lblTipoRectificativa: TcxLabel;
    pnlBusqueda: TPanel;
    cxgrdStock: TcxGrid;
    dbtvStock: TcxGridDBTableView;
    cxgrdlvlBusqueda: TcxGridLevel;
    dsStock: TDataSource;
    pnlFotoStock: TPanel;
    imgFotoStock: TImage;
    splFotoStock: TcxSplitter;
    splOpe: TcxSplitter;
    cxstylrpstry: TcxStyleRepository;
    styPrincipal: TcxStyle;
    styImporte: TcxStyle;
    tmrBusq: TTimer;
    dsBusq: TDataSource;
    qryBusq: TUniQuery;
    tvrBusq: TcxGridViewRepository;
    dbtvBusq: TcxGridDBTableView;
    styCabecera: TcxStyle;
    dbtvBusqINPUT_BUSQUEDA: TcxGridDBColumn;
    dbtvBusqCODIGO_ARTICULO: TcxGridDBColumn;
    dbtvBusqDESCRIPCION_ARTICULO: TcxGridDBColumn;
    dbtvBusqTEMPORADA: TcxGridDBColumn;
    dbtvBusqPROVEEDOR: TcxGridDBColumn;
    dbtvBusqREF_PROVEEDOR: TcxGridDBColumn;
    edtrepArticulo: TcxEditRepository;
    repSoloTexto: TcxEditRepositoryTextItem;
    repComboBox: TcxEditRepositoryExtLookupComboBoxItem;
    btnF61: TcxButton;
    lblBusqTick: TcxLabel;
    alCajaOpe: TActionList;
    actBuscarEmpleados: TAction;
    actSalir: TAction;
    actEliminarLinea: TAction;
    actCobro: TAction;
    btnF2: TcxButton;
    lblCargarCta: TcxLabel;
    actCargarCta: TAction;
    btnF10: TcxButton;
    lblBuscarModificar: TcxLabel;
    actBuscarModificar: TAction;
    actGuardarLayout: TAction;
    actAbrirArticulos: TAction;
    actConsultaStock: TAction;
    pnlTotal: TPanel;
    pnlBotones: TPanel;
    procedure actAbrirArticulosExecute(Sender: TObject);
    procedure actConsultaStockExecute(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure btnF5Click(Sender: TObject);
    procedure btnCodigoEmpleadoPropertiesValidate(Sender: TObject;
      var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
    procedure btnCodigoClientePropertiesValidate(Sender: TObject;
      var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
    procedure FormShow(Sender: TObject);
    procedure FormKeyPress(Sender: TObject; var Key: Char);
    procedure cxGrid1Enter(Sender: TObject);
    procedure tvArticuloPropertiesValidate(Sender: TObject;
      var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
    procedure btnCodigoClienteExit(Sender: TObject);
    procedure btnCodigoEmpleadoExit(Sender: TObject);
    procedure cxGrid1DBTableView1InitEdit(Sender: TcxCustomGridTableView;
      AItem: TcxCustomGridTableItem; AEdit: TcxCustomEdit);
    procedure cxGrid1DBTableView1EditKeyDown(Sender: TcxCustomGridTableView;
      AItem: TcxCustomGridTableItem; AEdit: TcxCustomEdit; var Key: Word;
      Shift: TShiftState);
    procedure OnAtributoChanged(Sender: TObject);
    procedure cxGrid1Exit(Sender: TObject);
    procedure tvUdsPropertiesEditValueChanged(Sender: TObject);
    procedure tvDescuentoPropertiesEditValueChanged(Sender: TObject);
    procedure tvDescuentoMenosPropertiesEditValueChanged(Sender: TObject);
    procedure tvPrecioUniPropertiesEditValueChanged(Sender: TObject);
    procedure cxGrid1DBTableView1KeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure tmrBusqTimer(Sender: TObject);
    procedure tvArticuloGetProperties(Sender: TcxCustomGridTableItem;
      ARecord: TcxCustomGridRecord; var AProperties: TcxCustomEditProperties);
    procedure repComboBoxPropertiesInitPopup(Sender: TObject);
    procedure tvArticuloPropertiesCloseUp(Sender: TObject);
    procedure cxGrid1DBTableView1CanFocusRecord(Sender: TcxCustomGridTableView;
      ARecord: TcxCustomGridRecord; var AAllow: Boolean);
    procedure tvTotalPropertiesEditValueChanged(Sender: TObject);
    procedure btnF12Click(Sender: TObject);
    procedure btnCodigoEmpleadoPropertiesButtonClick(Sender: TObject;
      AButtonIndex: Integer);
    procedure btnCodigoClientePropertiesButtonClick(Sender: TObject;
      AButtonIndex: Integer);
    procedure actBuscarEmpleadosExecute(Sender: TObject);
    procedure actSalirExecute(Sender: TObject);
    procedure actEliminarLineaExecute(Sender: TObject);
    procedure actCobroExecute(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure tvArticuloPropertiesChange(Sender: TObject);
    procedure cxGrid1DBTableView1Editing(Sender: TcxCustomGridTableView;
      AItem: TcxCustomGridTableItem; var AAllow: Boolean);
    procedure tvUdsPropertiesValidate(Sender: TObject;
      var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
    procedure cxGrid1DBTableView1MouseDown(Sender: TObject;
      Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure btnF2Click(Sender: TObject);
    procedure actCargarCtaExecute(Sender: TObject);
    procedure btnF10Click(Sender: TObject);
    procedure actBuscarModificarExecute(Sender: TObject);
    procedure cxGrid1DBTableView1FocusedRecordChanged(
      Sender: TcxCustomGridTableView; APrevFocusedRecord,
      AFocusedRecord: TcxCustomGridRecord;
      ANewItemRecordFocusingChanged: Boolean);
    procedure actGuardarLayoutExecute(Sender: TObject);
    procedure tvLineasOpeCustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo;
      var ADone: Boolean);
    procedure dbtvStockCustomDrawCell(Sender: TcxCustomGridTableView;
      ACanvas: TcxCanvas; AViewInfo: TcxGridTableDataCellViewInfo;
      var ADone: Boolean);
    procedure FormDestroy(Sender: TObject);
  private
    // Modo rectificación: ticket original que se rectifica (lo carga
    // CargarRectificacion desde Buscar operaciones)
    FSerieRectifica:  string;
    FNumeroRectifica: string;
    FTipoRectificativa: TTipoRectificativaCaja;
    FTratamientoMovRectificativa:
      TTratamientoMovimientosRectificativa;
    FCaptionPrevio:   string;
    FUltimoTickReloj: TDateTime;
    FEnfoqueArticuloPendiente: Boolean;
    FPoliticaStockVenta: IPoliticaStockVenta;
    FRepartidorDescuento: IRepartidorDescuento;
    FImpresorVenta: IImpresorVenta;
    FServicioCierreVenta: IServicioCierreVenta;
    FRepositorioConsultas: IRepositorioConsultasCaja;
    FServicioRectificacion: IServicioRectificacionCaja;
    FConsultaStock: IResultadoConsultaCaja;
    FIncidenciasSql: IRegistroIncidenciasSql;
    procedure GuardarLayoutCaja;
    procedure RestaurarLayoutCaja;
    procedure AbrirBuscarModificar;
    procedure CargarDepositosF2;
    procedure ActualizarRelojCaja;
    procedure SincronizarFechaCajaCabecera;
    procedure lblFechaCajaDblClick(Sender: TObject);
    procedure AsegurarLineaNueva;
    procedure ActualizarFoco;
    function BuscarArticulo:String;
    procedure WMCancelarLinea(var Msg: TMessage); message WM_CANCELAR_LINEA;
    function ConsolidarSiExiste(SkuBuscado: string): Boolean;
//    procedure ForzarDespliegue(Sender: TObject);
    procedure ConstruirColumnasDinamicas;
    procedure RellenarAtributosDesdeSku(Sku: string);
    procedure ActualizarColumnasDinamicas(ArticuloPadre: string);
    procedure PoblarAtributosLineasDeposito;
    procedure MostrarColumnasCuentaCliente(AActivar: Boolean);
    function ObtenerColumnaPorTag(NumColumn:Integer):TcxGridDBColumn;
    function RellenarDatosArticuloEnDataset(Codigo: string): Boolean;
    procedure RecalcularPrecioDesdeSku(sSKU:string);
    procedure ActualizarLabelTotal(Sender: TObject; NuevoTotal: Currency);
    procedure RecalcularLineasDesdeDM;
    procedure ConsultarStock(const CodigoInput: string);
    function  ValidarSkuParaVenta(const SkuFinal: string): Boolean;
    procedure EliminarLineaPorValidacion;
    procedure BuscarEmpleados;
    procedure BuscarClientes;
    function HayLineasConDeposito: Boolean;
    procedure ProcesarResultadoCierre(
      const AResultado: TResultadoCierreVenta;
      AEnviarEmail: Boolean;
      const AEmailEnvio: string);
    procedure WMSaltarAtributo(var Msg: TMessage); message WM_SALTAR_ATRIBUTO;
    procedure DsLineasDataChange(Sender: TObject; Field: TField);
    procedure RefrescarFotoStock;
    procedure tvLineasOpeAvButtonClick(Sender: TObject;
                                       AButtonIndex: Integer);
    procedure AbrirPopupAvEnEntrada(Sender: TObject);
    procedure CargarAvsValidos(const ACodArt: string;
                               AOrden: Integer;
                               var AAvs: TArray<string>);
    procedure RegistrarValorAtributo(AOrden: Integer;
                                     const AvNuevo: string);
    procedure FinalizarUltimoAtributo;
    procedure WMFinalizarAtribCaja(var Msg: TMessage);
                                       message WM_FINALIZAR_ATRIB_CAJA;
    procedure WMAvanzarAtribCaja(var Msg: TMessage);
                                       message WM_AVANZAR_ATRIB_CAJA;
    procedure WMAbrirPopupAv(var Msg: TMessage);
                                       message WM_ABRIR_POPUP_AV;
    procedure WMEnfocarArticuloCaja(var Msg: TMessage);
                                       message WM_ENFOCAR_ARTICULO_CAJA;
    procedure SolicitarFocoArticuloLineaNueva;
    procedure ProcesarLecturaScanner(const ACodigo: string);
    procedure LectorCodigoLeido(Sender: TObject; const ACodigo: string);
    function  LectorRejillaEditando: Boolean;
    function  LectorEsControlRejilla(AControl: TControl): Boolean;
    procedure LectorLecturaIniciada(Sender: TObject);
//    procedure LogPerfCaja(const AContexto, ADetalles: string);
  public
    DatosCaja: TdmCajaOpe;
  private
    // Detector reutilizable del lector de codigo de barras (trama STX/ETX +
    // rafaga por velocidad). La mecanica vive en TLectorScanner; aqui solo
    // queda el negocio (ProcesarLecturaScanner y los flags de abajo).
    FLector: TLectorScanner;
    // Activo mientras resolvemos una lectura con pistola: fuerza a
    // RellenarDatosArticuloEnDataset a buscar SOLO en codigos de barras.
    FResolviendoPorScanner: Boolean;
    // Activo durante TODO ProcesarLecturaScanner. Lo consultan los validadores
    // de cliente/empleado para no validar su texto (que pudo ensuciarse con la
    // rafaga) cuando el escaneo mueve el foco a la rejilla.
    FProcesandoLecturaScanner: Boolean;
    FValidandoCliente: Boolean;
    FCodigoEmpresa:String;
    FCodigoAlmacen, FCodigoCaja:String;
    FFecha:TDateTime;
    // CAMBIO 1: Variables de control para evitar re-entradas y bucles
    // Guarda el nº de atributos aunque el dataset haga Post
    FNumAtributosActual: Integer;
    // Evita re-entrada en el bloque del último atributo
    FProcesandoAtributo: Boolean;
    // Evita que ForzarDespliegue dispare OnAtributoChanged
    FInicializandoCombo: Boolean;
    FUltimoArticuloPadre: string;
    FActualizandoDepositos: Boolean;
    // Motivo por el que RellenarDatosArticuloEnDataset rechazó el último
    // artículo (existe y activo, pero sin SKU vendible). Lo consume el
    // validador de caja para dar un mensaje exacto en vez del genérico
    // "no encontrado o descatalogado".
    FMotivoRechazoArticulo: string;
    // Conserva el padre canonico resuelto por OnValidate. El lookup puede
    // dejar temporalmente vacio CODIGO_ART_FACLIN durante PostEditValue.
    FArticuloResueltoEdicion: string;
  private
    FNumeroCajaActual: Integer;
    // Bitmap reusable para pintar el cuadradito del color actual en el boton
    // del editor de atributos (Color, Talla, ...). Se redimensiona a 14x14
    // en cada InitEdit.
    FBmpSwatchBoton: TBitmap;
    // Stopwatch para medir el tiempo total desde que se valida el codigo de
    // articulo hasta que el popup de seleccion de AV se abre. Se arranca
    // en tvArticuloPropertiesValidate y se cierra en WMAbrirPopupAv.
    FswArtAPopup: TStopwatch;
    const MAX_CAJAS = 5;
  public
    procedure ResolverArtSkuStock(out ACodArt, ACodSku: string); override;
    function FormularioCaja: TCustomForm;
    // Carga EXTERNA ("Enviar a..." de Documentos de Trabajo): anade
    // una linea con el SKU y cantidad indicados usando el mismo flujo
    // que el lector (RellenarDatosArticuloEnDataset). False si el
    // articulo/SKU no existe o esta descatalogado.
    function CargarSkuExterno(const ASku: string;
                              ACant: Double): Boolean;
    procedure PrepararValores(AEmpresa, AAlmacen, ACaja: string;
                              AFecha: TDateTime);
    function IntentarCerrar:Boolean;
    // True si no hay venta a medias (sin líneas pendientes)
    function OperacionVacia: Boolean;
    // Carga la operación como rectificación del ticket indicado. El tipo
    // decide el signo de las líneas y la leyenda de la operación de caja.
    procedure CargarRectificacion(
      const ASerie, ANumero: string;
      ATipoRectificativa: TTipoRectificativaCaja;
      ATratamientoMovimientos:
        TTratamientoMovimientosRectificativa);
    property NumeroCajaActual: Integer read FNumeroCajaActual
                                       write FNumeroCajaActual;
  end;

implementation

{$R *.dfm}

uses
  inLibGridCantidad,
  inLibUser,
  inLibLog,
  inMtoCajaFaseCobro, inLibDevExp, inLibValoresAutomaticos,
  inLibFacturas, inLibGenBusq,
  inMtoModalGenImpSave, inLibLayoutForm,
  inLibArticulosValidador, inLibArticulosResolver,
  inLibArticulosAtributosLookup,
  inLibAtributosPaleta,
  inLibShowMto,
  inMtoStockConsulta,
  inLibCorreoTickets,
  inLibCajaDescuentos,
  inLibCajaOpeComposicion,
  UniDataCatalogoSqlAplicacion,
  System.StrUtils,
  inLibMsg;

procedure TfrmMtoOpeCaja.ActualizarFoco;
begin
  if btnCodigoEmpleado.Text = '' then
  begin
    if btnCodigoEmpleado.CanFocus then
      btnCodigoEmpleado.SetFocus;
  end
  else if cxgrdLineasOpe.CanFocus then
  begin
    cxgrdLineasOpe.SetFocus;
  end;
end;

procedure TfrmMtoOpeCaja.ActualizarRelojCaja;
var
  dtAhora: TDateTime;
begin
  dtAhora := Now;
  if FUltimoTickReloj = 0 then
    FUltimoTickReloj := dtAhora;
  if FFecha = 0 then
    FFecha := dtAhora;
  FFecha := FFecha + (dtAhora - FUltimoTickReloj);
  FUltimoTickReloj := dtAhora;
  lblFechaCaja.Caption := FormatDateTime('hh:nn:ss dddd d mmmm yyyy', FFecha);
end;

procedure TfrmMtoOpeCaja.SincronizarFechaCajaCabecera;
var
  bPost: Boolean;
begin
  bPost := False;
  if Assigned(DatosCaja) and
     DatosCaja.cdsCabecera.Active and
     (not DatosCaja.cdsCabecera.IsEmpty) then
  begin
    if DatosCaja.cdsCabecera.State = dsBrowse then
    begin
      DatosCaja.cdsCabecera.Edit;
      bPost := True;
    end;
    DatosCaja.cdsCabecera.FieldByName('FECHA_FAC').AsDateTime := FFecha;
    if bPost then
      DatosCaja.cdsCabecera.Post;
  end;
end;

procedure TfrmMtoOpeCaja.lblFechaCajaDblClick(Sender: TObject);
var
  sHora: string;
  dtHora: TDateTime;
  dtFechaBase: TDateTime;
begin
  dtFechaBase := FFecha;
  if dtFechaBase = 0 then
    dtFechaBase := Now;
  sHora := FormatDateTime('hh:nn', dtFechaBase);
  if InputQuery(STituloHoraCaja, SSolicitudHoraCaja, sHora) then
  begin
    if TryStrToTime(sHora, dtHora) then
    begin
      FFecha := Trunc(dtFechaBase) + Frac(dtHora);
      FUltimoTickReloj := Now;
      ActualizarRelojCaja;
      SincronizarFechaCajaCabecera;
      NotificarFechaCaja(FFecha);
    end
    else
      ShowMessage(SErrorHoraCajaNoValida);
  end
  else
  begin
    FFecha := Now;
    FUltimoTickReloj := Now;
    ActualizarRelojCaja;
    SincronizarFechaCajaCabecera;
    NotificarFechaCaja(FFecha);
  end;
end;

procedure TfrmMtoOpeCaja.WMSaltarAtributo(var Msg: TMessage);
begin
  if (tvLineasOpe.Controller.EditingController <> nil) and
     (tvLineasOpe.Controller.EditingController.IsEditing) then
  begin
    PostMessage(tvLineasOpe.Controller.EditingController.Edit.Handle,
                WM_KEYDOWN,
                VK_RETURN, 0);
  end;
end;

function TfrmMtoOpeCaja.CargarSkuExterno(const ASku: string;
  ACant: Double): Boolean;
begin
  // Fila en blanco lista y en edicion, como tras una lectura.
  AsegurarLineaNueva;
  if not (DatosCaja.cdsLineas.State in dsEditModes) then
    DatosCaja.cdsLineas.Edit;
  Result := RellenarDatosArticuloEnDataset(ASku);
  if Result then
  begin
    DatosCaja.cdsLineas.FieldByName('CANTIDAD_FACLIN').AsFloat := ACant;
    DatosCaja.cdsLineas.Post;
    GridRecalc(ConexionPrincipal,nil, tvLineasOpe, DatosCaja.cdsLineas,
               DatosCaja.cdsCabecera, ActualizarLabelTotal);
    AsegurarLineaNueva;
  end
  else
  begin
    if DatosCaja.cdsLineas.State in dsEditModes then
      DatosCaja.cdsLineas.Cancel;
  end;
end;

procedure TfrmMtoOpeCaja.PrepararValores(AEmpresa, AAlmacen, ACaja: string;
                                         AFecha: TDateTime);
var
  EmpleadoAnterior, NombreEmpleadoAnterior: string;
  sCodEmpleadoDefecto: string;
begin
  FCodigoEmpresa := AEmpresa;
  FCodigoAlmacen := AAlmacen;
  FCodigoCaja    := ACaja;
  FFecha         := AFecha;
  FUltimoTickReloj := Now;
  lblTipoRectificativa.Caption := '';
  lblTipoRectificativa.Visible := False;

  if Assigned(DatosCaja) then
  begin
    // 1. Guardar el empleado actual antes de vaciar
    EmpleadoAnterior := '';
    NombreEmpleadoAnterior := '';
    if DatosCaja.cdsCabecera.Active and not DatosCaja.cdsCabecera.IsEmpty then
    begin
      EmpleadoAnterior :=
            DatosCaja.cdsCabecera.FieldByName('CODIGO_CAJERO_FAC').AsString;
      NombreEmpleadoAnterior := lblNombreEmpleado.Caption;
    end;
    if (tvLineasOpe.Controller.EditingController <> nil) and
       tvLineasOpe.Controller.EditingController.IsEditing then
    begin
      tvLineasOpe.Controller.EditingController.HideEdit(True);
    end;
    // 2. Vaciar las líneas de la venta anterior
    if DatosCaja.cdsLineas.Active then
    begin
      DatosCaja.cdsLineas.DisableControls;
      try
        // --- CLAVE: Limpia el "Delta" (registros fantasma pendientes) ---
        DatosCaja.cdsLineas.CancelUpdates;

        if DatosCaja.cdsLineas.RecordCount > 0 then
          DatosCaja.cdsLineas.EmptyDataSet;
      finally
        DatosCaja.cdsLineas.EnableControls;
      end;
    end;
    tvLineasOpe.DataController.Refresh;
    // Nueva operacion: ocultamos la fecha de deposito y volvemos a la vista
    // normal de columnas (% y Menos visibles, atributos ocultos) hasta que se
    // vuelva a cargar la cuenta del cliente con F2.
    tvFechaOperacion.Visible := False;
    MostrarColumnasCuentaCliente(False);
    // 3. Vaciar la cabecera anterior y crear un registro nuevo
    if DatosCaja.cdsCabecera.Active then
    begin
      DatosCaja.cdsCabecera.CancelUpdates;
      DatosCaja.cdsCabecera.EmptyDataSet;
      DatosCaja.cdsCabecera.Append;
    end;
    lblNombreCliente.Caption := '';
    btnCodigoCliente.Text := '';
    // 4. Aplicar valores base
    DatosCaja.cdsCabecera.FieldByName('FECHA_FAC').AsDateTime := FFecha;
    AplicarValoresPorDefecto(
      ConexionPrincipal,
      DatosCaja.cdsCabecera,
      'fza_facturas');
    DatosCaja.cdsCabecera.FieldByName('CODIGO_EMP_FAC').AsString :=
      FCodigoEmpresa;
    DatosCaja.cdsCabecera.FieldByName('FECHA_FAC').AsDateTime := FFecha;
    DatosCaja.cdsCabecera.FieldByName('TIPO_FAC').AsString := 'SIMPLIFICADA';
    // --- 5. EVALUACIÓN DE PARÁMETROS DE INICIO ---
    // A) Tarifa por defecto (como tenías en FormShow)
    DatosCaja.cdsCabecera.FieldByName(
                                  'TARIFA_ARTICULO_CLIENTE_FAC').AsString :=
                                  ParametrosCaja.GetString('vgerDefTarifa', 'PVP');
    lblTarifa.Caption := DatosCaja.cdsCabecera.FieldByName(
                                    'TARIFA_ARTICULO_CLIENTE_FAC').AsString;
    // B) Empleado: Mantenemos el anterior, o buscamos el parámetro por defecto
    if EmpleadoAnterior <> '' then
    begin
      DatosCaja.cdsCabecera.FieldByName('CODIGO_CAJERO_FAC').AsString :=
                                                               EmpleadoAnterior;
      btnCodigoEmpleado.Text := EmpleadoAnterior;
      lblNombreEmpleado.Caption := NombreEmpleadoAnterior;
    end
    else if ParametrosCaja.GetBool('vgerFillEmpleadoDefecto', False) then
    begin
      sCodEmpleadoDefecto :=
        ParametrosCaja.GetString('vgerCodEmpleadoDefecto', '');
      if sCodEmpleadoDefecto <> '' then
      begin
        btnCodigoEmpleado.Text := sCodEmpleadoDefecto;
        btnCodigoEmpleado.ValidateEdit(True);
      end;
    end;
  end;
  dbtvStock.ClearItems;
  lblNombreCliente.Caption := 'VENTA CONTADO';
  btnCodigoCliente.Text := '';
  lblTotal.Caption := 'Total 0,00 €';
  ActualizarRelojCaja;
  if Self.Visible then
    ActualizarFoco;
end;

procedure TfrmMtoOpeCaja.ConsultarStock(const CodigoInput: string);
var
  View: TcxGridDBTableView;
  DataSetStock: TDataSet;
  I: Integer;
  Mapa: TDictionary<string, string>;
  sCodigoArticulo: string;
  sCodigoConsulta: string;
begin
  sCodigoConsulta := Trim(CodigoInput);
  if sCodigoConsulta <> '' then
  begin
    if ParametrosCaja.GetBool(
         'vgerStockTodosColores',
         False) and
       (Pos('/', sCodigoConsulta) > 0) and
       Assigned(DatosCaja) and
       DatosCaja.cdsLineas.Active then
    begin
      // El padre devuelve una fila por color y almacén.
      sCodigoArticulo :=
        Trim(
          DatosCaja.cdsLineas.FieldByName(
            'CODIGO_ART_FACLIN').AsString);
      if sCodigoArticulo <> '' then
      begin
        sCodigoConsulta := sCodigoArticulo;
      end;
    end;
    dsStock.DataSet := nil;
    FConsultaStock :=
      FRepositorioConsultas.ConsultarStock(
        sCodigoConsulta);
    DataSetStock := FConsultaStock.DataSet;
    dsStock.DataSet := DataSetStock;
    View := dbtvStock;
    View.BeginUpdate;
    try
      View.ClearItems;
      if not DataSetStock.IsEmpty then
      begin
        View.DataController.CreateAllItems;
        for I := 0 to View.ColumnCount - 1 do
        begin
          if (I = 0) or (I = 1) then
          begin
            View.Columns[I].HeaderAlignmentHorz := taLeftJustify
          end
          else
          begin
            View.Columns[I].HeaderAlignmentHorz := taRightJustify;
          end;
        end;
      end;
    finally
      View.EndUpdate;
    end;
    if DataSetStock.Active and
       (not DataSetStock.IsEmpty) then
    begin
      View.BeginUpdate;
      try
        try
          View.ApplyBestFit;
        except
        end;
        // ApplyBestFit no reserva el ancho del indicador de color.
        Mapa := ObtenerMapaAtributosGlobal(
          ConexionPrincipal);
        if Assigned(Mapa) and
           (Mapa.Count > 0) and
           (View.ColumnCount > 0) then
        begin
          AjustarAnchoColumnaParaSwatch(
            ConexionPrincipal,
            View.Columns[0],
            Mapa);
        end;
      finally
        View.EndUpdate;
      end;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.tvLineasOpeCustomDrawCell(
  Sender: TcxCustomGridTableView; ACanvas: TcxCanvas;
  AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
var
  Info: TInfoBasico;
  Mapa: TDictionary<string, string>;
  sArticulo: string;
  sIdVa: string;
  sTexto: string;
begin
  // Pinta el cuadradito de la paleta basica al lado del valor de atributo
  // (Color = MALVA, Talla = 48, ...) en las celdas de las lineas de venta.
  // La asignacion por articulo gana porque los codigos de proveedor pueden
  // representar colores basicos distintos segun el articulo.
  if (AViewInfo <> nil) and (AViewInfo.Item <> nil) and
     (AViewInfo.GridRecord <> nil) and
     (AViewInfo.Item.Tag >= 1) and (AViewInfo.Item.Tag <= 5) then
  begin
    sArticulo := VarToStr(
      AViewInfo.GridRecord.Values[tvArticulo.Index]);
    sTexto := AViewInfo.Text;
    Mapa := ObtenerMapaAtributosGlobal(ConexionPrincipal);
    sIdVa := '';
    if (Mapa <> nil) and (AViewInfo.Item is TcxGridColumn) then
      Mapa.TryGetValue(UpperCase(Trim(
        TcxGridColumn(AViewInfo.Item).Caption)), sIdVa);
    if ObtenerInfoBasicoArticulo(
      ConexionPrincipal,
      sArticulo,
      sIdVa,
      sTexto,
      Info) then
      ADone := PintarCeldaConCuadradoColor(ACanvas, AViewInfo, Info, sTexto);
  end;
  if (not ADone) and
     PintarCeldaSwatchSiAplica(ConexionPrincipal,ACanvas, AViewInfo, nil) then
    ADone := True;
end;

procedure TfrmMtoOpeCaja.dbtvStockCustomDrawCell(
  Sender: TcxCustomGridTableView; ACanvas: TcxCanvas;
  AViewInfo: TcxGridTableDataCellViewInfo; var ADone: Boolean);
begin
  // Solo pintamos swatch en la primera columna (Codigo "CODART/COLOR").
  // Las columnas pivotadas de talla traen cantidades y no queremos
  // cuadradito al lado de cada numero — basta con la del codigo.
  if (AViewInfo = nil) or (AViewInfo.Item = nil) then Exit;
  if AViewInfo.Item.VisibleIndex <> 0 then Exit;
  if PintarCeldaSwatchSiAplica(ConexionPrincipal,ACanvas, AViewInfo, nil) then
    ADone := True;
end;

function TfrmMtoOpeCaja.ValidarSkuParaVenta(const SkuFinal: string): Boolean;
var
  Resultado: TResultadoPoliticaStockVenta;
begin
  Resultado := FPoliticaStockVenta.Validar(
    SkuFinal,
    FCodigoAlmacen);
  if Resultado.Mensaje <> '' then
    ShowMessage(Resultado.Mensaje);
  Result := Resultado.Permitida;
end;

procedure TfrmMtoOpeCaja.EliminarLineaPorValidacion;
begin
  if not Assigned(DatosCaja) then Exit;
  if not DatosCaja.cdsLineas.Active then Exit;

  if DatosCaja.cdsLineas.State = dsInsert then
    DatosCaja.cdsLineas.Cancel
  else if DatosCaja.cdsLineas.State = dsEdit then
  begin
    DatosCaja.cdsLineas.Cancel;
    if not DatosCaja.cdsLineas.IsEmpty then
      DatosCaja.cdsLineas.Delete;
  end;

  //dbtvStock.ClearItems;
  GridRecalc(ConexionPrincipal,nil,
             tvLineasOpe,
             DatosCaja.cdsLineas,
             DatosCaja.cdsCabecera,
             ActualizarLabelTotal);
  AsegurarLineaNueva;
end;

// Hook de lectura con pistola a nivel de FORMULARIO (KeyPreview heredado de
// TfrmBase = True): da igual que control tenga el foco. Delegamos toda la
// deteccion (trama STX/ETX + rafaga por velocidad) en TLectorScanner; el codigo
// leido llega luego por OnCodigoLeido (LectorCodigoLeido).
procedure TfrmMtoOpeCaja.FormKeyPress(Sender: TObject; var Key: Char);
begin
  FLector.KeyPress(Key);
end;

procedure TfrmMtoOpeCaja.LectorCodigoLeido(Sender: TObject;
  const ACodigo: string);
begin
  ProcesarLecturaScanner(ACodigo);
end;

// El lector consulta si la rejilla estaba editando (anti-eco) y si un control
// pertenece a la rejilla (restauracion del campo solo fuera de la rejilla).
function TfrmMtoOpeCaja.LectorRejillaEditando: Boolean;
begin
  Result := (tvLineasOpe.Controller.EditingController <> nil) and
            tvLineasOpe.Controller.EditingController.IsEditing;
end;

function TfrmMtoOpeCaja.LectorEsControlRejilla(AControl: TControl): Boolean;
var
  C: TControl;
begin
  Result := False;
  C := AControl;
  while (C <> nil) and (not Result) do
  begin
    if C = cxgrdLineasOpe then
      Result := True;
    C := C.Parent;
  end;
end;

// Al iniciar una trama del lector paramos el timer de busqueda incremental.
procedure TfrmMtoOpeCaja.LectorLecturaIniciada(Sender: TObject);
begin
  tmrBusq.Enabled := False;
end;

// Procesa un codigo leido con pistola desde cualquier punto del formulario:
// lo resuelve SOLO contra codigos de barras y, si es vendible, da de alta la
// linea de venta automaticamente y deja una nueva linea lista para el
// siguiente escaneo. El alta de linea es SIEMPRE, con independencia del
// parametro vgerMoverLineaIdentif (que solo gobierna la entrada manual).
// Unica precondicion: el vendedor (cajero) debe estar dado de alta.
procedure TfrmMtoOpeCaja.ProcesarLecturaScanner(const ACodigo: string);
var
  Validador  : TArticulosValidador;
  Resolucion : TArtResolucionEntrada;
  sSku       : string;
begin
  if Assigned(DatosCaja) and DatosCaja.cdsLineas.Active then
  begin
   // Activo durante todo el procesado: evita que, al mover el foco a la
   // rejilla, los validadores de cliente/empleado intenten validar el texto
   // que la rafaga pudo dejar en esos campos.
   FProcesandoLecturaScanner := True;
   try
    // Precondicion: sin vendedor dado de alta no se admiten lecturas.
    if Trim(DatosCaja.cdsCabecera.FieldByName(
                                       'CODIGO_CAJERO_FAC').AsString) = '' then
    begin
      ShowMessage(SErrorVendedorCajaNoAsignado);
      if btnCodigoEmpleado.CanFocus then
        btnCodigoEmpleado.SetFocus;
    end
    else
    begin
      tmrBusq.Enabled := False;
      // Cerramos el editor in-place (si lo hubiera) sin volcar su contenido.
      if tvLineasOpe.Controller.EditingController.IsEditing then
        tvLineasOpe.Controller.EditingController.HideEdit(False);
      // CLAVE: resolvemos el codigo SOLO contra codigos de barras ANTES de
      // crear/rellenar ninguna linea. Asi decidimos si hay que consolidar (el
      // SKU ya esta en el ticket) sin haber grabado todavia una linea de
      // trabajo, que es justo lo que generaba el duplicado.
      Validador := TArticulosValidador.Create(ConexionPrincipal);
      try
        Resolucion := Validador.ResolverCodigoBarras(ACodigo);
      finally
        FreeAndNil(Validador);
      end;
      sSku := Resolucion.CodigoSku;
      if not Resolucion.Encontrado then
        ShowMessage(Format(SErrorCodigoBarrasVentaCajaNoEncontrado,
          [ACodigo]))
      else if (Trim(sSku) <> '') and not ValidarSkuParaVenta(sSku) then
      begin
        // SKU no vendible (inactivo o sin stock con bloqueo): ValidarSku ya
        // mostro el motivo. No añadimos ni tocamos ninguna linea.
      end
      else
      begin
        // Garantizamos una linea de trabajo VACIA en insercion, sin pisar
        // lineas ya confirmadas (la lectura puede llegar con el foco en
        // cualquier control). Esa linea vacia no comparte SKU, asi que no
        // interfiere en la deteccion de duplicados.
        if DatosCaja.cdsLineas.State = dsInsert then
        begin
          if Trim(DatosCaja.cdsLineas.FieldByName(
                                      'CODIGO_ART_FACLIN').AsString) <> '' then
          begin
            DatosCaja.cdsLineas.Post;
            DatosCaja.cdsLineas.Append;
          end;
        end
        else
        begin
          if DatosCaja.cdsLineas.State = dsEdit then
            DatosCaja.cdsLineas.Post;
          DatosCaja.cdsLineas.Append;
        end;
        // ¿El SKU ya esta en el ticket? -> sumamos cantidad en esa linea y NO
        // creamos otra. ConsolidarSiExiste se encarga de cancelar/recolocar la
        // linea de trabajo vacia (su recalculo interno la trata como insert
        // vacio). Si no esta -> rellenamos la linea de trabajo y la grabamos.
        if (Trim(sSku) <> '') and ConsolidarSiExiste(sSku) then
        begin
          // Consolidado: la unidad ya se sumo. El incremento se hizo via un
          // CLON del dataset, que no notifica al grid principal, asi que la
          // cantidad no se repintaria hasta mover el cursor. Forzamos el
          // refresco para que se vea de inmediato.
          tvLineasOpe.DataController.UpdateItems(True);
        end
        else
        begin
          FResolviendoPorScanner := True;
          try
            RellenarDatosArticuloEnDataset(ACodigo);
          finally
            FResolviendoPorScanner := False;
          end;
          if (Trim(sSku) <> '') and (sSku <> Resolucion.CodigoArticulo) then
            RellenarAtributosDesdeSku(sSku);
          if DatosCaja.cdsLineas.State in [dsInsert, dsEdit] then
            DatosCaja.cdsLineas.Post;
          GridRecalc(ConexionPrincipal,nil,
                     tvLineasOpe,
                     DatosCaja.cdsLineas,
                     DatosCaja.cdsCabecera,
                     ActualizarLabelTotal);
        end;
      end;
      // Dejamos una linea editable y el foco en la celda de articulo de la
      // rejilla, lista para encadenar lecturas venga de donde venga el foco.
      AsegurarLineaNueva;
      tvLineasOpe.Controller.EditingController.ShowEdit;
    end;
   finally
     FProcesandoLecturaScanner := False;
   end;
  end;
end;

procedure TfrmMtoOpeCaja.WMCancelarLinea(var Msg: TMessage);
var
  VieneDeDep: string;
begin
  if (DatosCaja.cdsLineas.Active) then
  begin
    // NUEVO: Bloqueo de borrado por atajo
    if not DatosCaja.cdsLineas.IsEmpty then
    begin
      VieneDeDep :=
        DatosCaja.cdsLineas.FieldByName('VIENE_DE_DEPOSITO').AsString;
      if (VieneDeDep = 'S') or (VieneDeDep = 'A') then
      begin
        ShowMessage(SErrorLineaDepositoCajaNoCancelable);
        Exit;
      end;
    end;
    if (DatosCaja.cdsLineas.State = dsInsert) then
      DatosCaja.cdsLineas.Cancel
    else if not DatosCaja.cdsLineas.IsEmpty then
      DatosCaja.cdsLineas.Delete;

    GridRecalc(ConexionPrincipal,nil,
               tvLineasOpe,
               DatosCaja.cdsLineas,
               DatosCaja.cdsCabecera,
               ActualizarLabelTotal);
    AsegurarLineaNueva;
  end;
end;

procedure TfrmMtoOpeCaja.tmrBusqTimer(Sender: TObject);
var
  EditActivo: TcxCustomEdit;
  TextEdit: TcxCustomTextEdit;
  TextoBusqueda: string;
begin
  tmrBusq.Enabled := False;
  EditActivo := nil;
  dbtvBusq.BeginUpdate;
  try
    dbtvBusq.DataController.DataSource := nil;
    dbtvBusq.DataController.Filter.Clear;
    dbtvBusq.DataController.Filter.Active := False;
    dbtvBusq.Controller.IncSearchingText := '';
    if tvLineasOpe.Controller.EditingController.IsEditing then
    begin
      EditActivo := tvLineasOpe.Controller.EditingController.Edit;
      if EditActivo <> nil then
      begin
        // Cuando el timer dispara, el editor activo puede no ser el de
        // tvArticulo (el usuario pudo moverse a otra celda durante los
        // 500ms de debounce). Solo casteamos a TcxCustomTextEdit si el
        // editor realmente lo es; en otro caso usamos EditingValue.
        // Esto evita el EInvalidCast cuando el editor activo no es de
        // tipo texto (p.ej. TcxButtonEdit de columnas de atributo).
        if EditActivo is TcxCustomTextEdit then
        begin
          TextEdit := TcxCustomTextEdit(EditActivo);
          if TextEdit.SelLength > 0 then
            TextoBusqueda := Copy(TextEdit.Text, 1, TextEdit.SelStart)
          else
            TextoBusqueda := TextEdit.Text;
        end
        else
          TextoBusqueda := VarToStr(EditActivo.EditingValue);
        TextoBusqueda := Trim(TextoBusqueda);
        if Length(TextoBusqueda) >= 1 then
        begin
          qryBusq.Connection := ConexionPrincipal;
          qryBusq.Close;
          qryBusq.ParamByName('TARIFA').AsString :=
                                              DatosCaja.cdsCabecera.FieldByName(
                                    'TARIFA_ARTICULO_CLIENTE_FAC').AsString;
          qryBusq.ParamByName('FECHA_TARIFA').AsDate :=
                                              DatosCaja.cdsCabecera.FieldByName(
                                                       'FECHA_FAC').AsDateTime;
          qryBusq.ParamByName('TOKEN').AsString := '%' + TextoBusqueda + '%';
          qryBusq.Open;
          // Diagnostico: registramos el resultado de la busqueda incremental
          // para saber si la vista vi_art_busquedas devuelve filas. El log SQL
          // estandar marca filas=- en queries con LIMIT, asi que aqui lo
          // contamos explicitamente. Si filas=0, el problema es de datos (la
          // vista no devuelve nada para esa TARIFA/FECHA) y no del UI.
          try
            inLibLog.Log.LogInfo(Format('qryBusq.Open: TARIFA="%s" ' +
              'FECHA_TARIFA="%s" TOKEN="%s" IsEmpty=%s RecordCount=%d',
              [qryBusq.ParamByName('TARIFA').AsString,
               DateToStr(qryBusq.ParamByName('FECHA_TARIFA').AsDate),
               qryBusq.ParamByName('TOKEN').AsString,
               BoolToStr(qryBusq.IsEmpty, True),
               qryBusq.RecordCount]));
            // Volcamos los primeros 5 codigos para verificar que la vista
            // realmente devuelve algo aprovechable (no nulls, codigos validos)
            if not qryBusq.IsEmpty then
            begin
              qryBusq.First;
              while (not qryBusq.Eof) and (qryBusq.RecNo <= 5) do
              begin
                inLibLog.Log.LogInfo(Format('qryBusq fila %d: cod="%s" desc="%s"',
                  [qryBusq.RecNo,
                   qryBusq.FieldByName('CODIGO_PADRE').AsString,
                   qryBusq.FieldByName('DESCRIPCION_ART').AsString]));
                qryBusq.Next;
              end;
              qryBusq.First;
            end;
          except
            on E: Exception do
              inLibLog.Log.LogWarning('qryBusq diagnostico: ' +
                                      E.ClassName + ' ' + E.Message);
          end;
          dbtvBusq.DataController.DataSource := dsBusq;
          dbtvBusq.DataController.Refresh;
        end;
      end;
    end;
  finally
    dbtvBusq.EndUpdate;
  end;
  if (EditActivo is TcxExtLookupComboBox) then
    begin
       if not TcxExtLookupComboBox(EditActivo).DroppedDown then
       begin
          if not qryBusq.IsEmpty then
             TcxExtLookupComboBox(EditActivo).DroppedDown := True;
       end
       else
       begin
          TcxExtLookupComboBox(EditActivo).Properties.DropDownRows := 15;
       end;
    end;
end;

procedure TfrmMtoOpeCaja.tvArticuloGetProperties(Sender: TcxCustomGridTableItem;
  ARecord: TcxCustomGridRecord; var AProperties: TcxCustomEditProperties);
var
  EsLaCeldaFocale: Boolean;
  ValorActual: Variant;
begin
  if (ARecord = nil) or (tvLineasOpe.Controller = nil) then
    Exit;
  ValorActual := ARecord.Values[Sender.Index];
  if (not VarIsNull(ValorActual)) and (Trim(VarToStr(ValorActual)) <> '') then
  begin
    AProperties := repSoloTexto.Properties;
    Exit;
  end;
  EsLaCeldaFocale := (tvLineasOpe.Controller.FocusedRecord = ARecord)
                     and
                     (tvLineasOpe.Controller.FocusedItem = Sender);
  if EsLaCeldaFocale then
    AProperties := repComboBox.Properties
  else
    AProperties := repSoloTexto.Properties;
end;

procedure TfrmMtoOpeCaja.tvArticuloPropertiesChange(Sender: TObject);
begin
  if not FLector.LeyendoTrama then
  begin
    tmrBusq.Enabled := False;
    tmrBusq.Enabled := True;
  end;
end;

procedure TfrmMtoOpeCaja.tvArticuloPropertiesCloseUp(Sender: TObject);
var
  Combo: TcxExtLookupComboBox;
begin
  if Sender is TcxExtLookupComboBox then
  begin
    Combo := TcxExtLookupComboBox(Sender);
    if Combo.Properties.View is TcxGridDBTableView then
    begin
      with TcxGridDBTableView(Combo.Properties.View) do
      begin
        BeginUpdate;
        try
          Controller.IncSearchingText := '';
          DataController.Filter.Clear;
          DataController.Filter.Active := False;
        finally
          EndUpdate;
        end;
      end;
    end;
  end;
end;

function TfrmMtoOpeCaja.BuscarArticulo: String;
  // Helper: ajusta DisplayLabel y, si procede, DisplayFormat de un campo.
  // El cast depende del TField concreto (TFloatField / TFMTBCDField /
  // TDateField / TSQLTimeStampField segun como UniDAC mapea la columna).
  procedure ConfigCampo(F: TField; const ALabel, AFormat: string);
  begin
    if F = nil then Exit;
    if ALabel <> '' then
      F.DisplayLabel := ALabel;
    if AFormat = '' then Exit;
    if F is TFloatField then
      TFloatField(F).DisplayFormat := AFormat
    else if F is TBCDField then
      TBCDField(F).DisplayFormat := AFormat
    else if F is TFMTBCDField then
      TFMTBCDField(F).DisplayFormat := AFormat
    else if F is TDateField then
      TDateField(F).DisplayFormat := AFormat
    else if F is TDateTimeField then
      TDateTimeField(F).DisplayFormat := AFormat
    else if F is TSQLTimeStampField then
      TSQLTimeStampField(F).DisplayFormat := AFormat;
  end;
begin
  // Popup de busqueda de articulos lanzado desde F3 en caja. Antes
  // llamabamos a PRC_BUSQUEDA_ARTICULOS (TUniStoredProc); ahora atacamos
  // vi_art_busquedas directamente como TUniQuery parametrizado por
  // tarifa y fecha (mismo criterio de vigencia que el desplegable inline
  // qryBusq). Anadimos columnas Temporada (LEFT JOIN
  // fza_articulos_propiedades + fza_propiedades_valores con
  // CODIGO_PROP_ARTPROP = 'TEMPORADA') y Proveedor (RAZON_SOCIAL_PROVEEDOR
  // ya en la vista), junto con la ref. del proveedor principal.
  // Configuramos DisplayLabel/DisplayFormat por campo
  // para que la grilla salga legible aunque no haya layout guardado en
  // fza_usuarios_perfiles para frmMtoArtFacSearch; si hay layout,// PonerAnchosTitulos lo sobrepone (vease inLibDevExp).
  var unqryBusq := TUniQuery.Create(nil);
  try
    unqryBusq.Connection := ConexionPrincipal;
    unqryBusq.SQL.Text :=
      'SELECT'                                                      + sLineBreak +
      '    v.CODIGO_ART_ART,'                                       + sLineBreak +
      '    v.DESCRIPCION_ART,'                                      + sLineBreak +
      '    v.DESCRIPCION_FAM,'                                      + sLineBreak +
      '    pv.PV                       AS TEMPORADA,'               + sLineBreak +
      '    v.RAZON_SOCIAL_PROVEEDOR,'                               + sLineBreak +
      '    v.REF_PROVEEDOR,'                                        + sLineBreak +
      '    v.CODIGO_TAR_ARTTAR,'                                    + sLineBreak +
      '    v.NOMBRE_TAR_TAR,'                                       + sLineBreak +
      '    v.PRECIO_FINAL_ARTTAR,'                                  + sLineBreak +
      '    v.FECHA_DESDE_ARTTAR,'                                   + sLineBreak +
      '    v.FECHA_HASTA_ARTTAR'                                    + sLineBreak +
      'FROM vi_art_busquedas v'                                     + sLineBreak +
      'LEFT JOIN fza_articulos_propiedades ap'                      + sLineBreak +
      '       ON ap.CODIGO_ART_ART = v.CODIGO_ART_ART'              + sLineBreak +
      '      AND ap.CODIGO_PROP_ARTPROP = ''TEMPORADA'''            + sLineBreak +
      // Nivel articulo: evita duplicar el articulo por temporadas de color
      '      AND ap.CODIGO_UNIDAD_ARTPROP = '''''                   + sLineBreak +
      'LEFT JOIN fza_propiedades_valores pv'                        + sLineBreak +
      '       ON pv.ID_PV_ARTPROP = ap.ID_PV_ARTPROP'               + sLineBreak +
      'WHERE (v.CODIGO_TAR_ARTTAR = :TARIFA'                        + sLineBreak +
      '       OR v.CODIGO_TAR_ARTTAR IS NULL)'                      + sLineBreak +
      '  AND (v.FECHA_DESDE_ARTTAR IS NULL'                         + sLineBreak +
      '       OR v.FECHA_DESDE_ARTTAR <= :FECHA_TARIFA)'            + sLineBreak +
      '  AND (v.FECHA_HASTA_ARTTAR IS NULL'                         + sLineBreak +
      '       OR v.FECHA_HASTA_ARTTAR >= :FECHA_TARIFA)'            + sLineBreak +
      'ORDER BY v.CODIGO_ART_ART';

    unqryBusq.ParamByName('TARIFA').AsString :=
                                              DatosCaja.cdsCabecera.FieldByName(
                                    'TARIFA_ARTICULO_CLIENTE_FAC').AsString;
    unqryBusq.ParamByName('FECHA_TARIFA').AsDate :=
                                              DatosCaja.cdsCabecera.FieldByName(
                                                       'FECHA_FAC').AsDateTime;

    // Abrimos aqui (en vez de dejar que lo haga EjecutarBusqueda) para
    // tener acceso a los TField y poder fijar DisplayLabel / DisplayFormat
    // antes de que cxGrdDBTabPrin.DataController.CreateAllItems cree las
    // columnas en TfrmMtoSearch.CrearTablaPrincipal.
    unqryBusq.Open;
    ConfigCampo(unqryBusq.FindField('CODIGO_ART_ART'),
                'Código',                '');
    ConfigCampo(unqryBusq.FindField('DESCRIPCION_ART'),
                'Descripción',           '');
    ConfigCampo(unqryBusq.FindField('DESCRIPCION_FAM'),
                'Familia',               '');
    ConfigCampo(unqryBusq.FindField('TEMPORADA'),
                'Temporada',             '');
    ConfigCampo(unqryBusq.FindField('RAZON_SOCIAL_PROVEEDOR'),
                'Proveedor',             '');
    ConfigCampo(unqryBusq.FindField('REF_PROVEEDOR'),
                'Ref. proveedor',        '');
    ConfigCampo(unqryBusq.FindField('CODIGO_TAR_ARTTAR'),
                'Tarifa',                '');
    ConfigCampo(unqryBusq.FindField('NOMBRE_TAR_TAR'),
                'Nombre tarifa',         '');
    ConfigCampo(unqryBusq.FindField('PRECIO_FINAL_ARTTAR'),
                'Precio',                '#,##0.00 €');
    ConfigCampo(unqryBusq.FindField('FECHA_DESDE_ARTTAR'),
                'Desde',                 'dd/mm/yyyy');
    ConfigCampo(unqryBusq.FindField('FECHA_HASTA_ARTTAR'),
                'Hasta',                 'dd/mm/yyyy');

    if TBusquedaUtils.EjecutarBusqueda(
      ConexionPrincipal,
      'Búsqueda de Artículos en Caja',
                                       unqryBusq,
                                       'frmMtoArtFacSearch',
                                       Self) then
      Result := unqryBusq.FieldByName('CODIGO_ART_ART').AsString
    else
      Result := '';
  finally
    FreeAndNil(unqryBusq);
  end;
end;

procedure TfrmMtoOpeCaja.tvArticuloPropertiesValidate(Sender: TObject;
  var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
var
  CodigoInput: string;
  CodigoPadre: string;
  SkuDetectado: string;
  NumAtributos: Integer;
begin
  // Arrancamos el cronometro global art -> primer popup para diagnosticar
  // donde se va el tiempo entre Enter en el codigo y la salida del primer
  // desplegable de atributo (lo cierra WMAbrirPopupAv).
  FswArtAPopup := TStopwatch.StartNew;
  CodigoInput := VarToStr(DisplayValue);
  FArticuloResueltoEdicion := '';
  if RellenarDatosArticuloEnDataset(CodigoInput) then
  begin
    CodigoPadre  := DatosCaja.cdsLineas.FieldByName(
                                      'CODIGO_ART_FACLIN').AsString;
    FArticuloResueltoEdicion := CodigoPadre;
    SkuDetectado := DatosCaja.cdsLineas.FieldByName(
                                        'CODIGO_UNIDAD_FACLIN').AsString;
    NumAtributos := DatosCaja.cdsLineas.FieldByName(
                                   'NUM_ATRIBUTOS_REQ_FACTURA_LINEA').AsInteger;
    // Validación parametrizada: SKU debe existir en fza_articulos_skus y, si
    // procede, tener stock. Se ejecuta sólo cuando el SKU ya está definido
    // (no es el padre a la espera de talla/color).
    if (Trim(SkuDetectado) <> '') and (SkuDetectado <> CodigoPadre) and
       not ValidarSkuParaVenta(SkuDetectado) then
    begin
      EliminarLineaPorValidacion;
      DisplayValue := null;
      Error := False;
      Abort;
    end;
    if (NumAtributos > 0) and (SkuDetectado = CodigoPadre) then
    begin
      DatosCaja.cdsLineas.FieldByName('PRECIO_SALIDA_FACLIN').AsCurrency := 0;
      GridRecalc(ConexionPrincipal,nil,
                 tvLineasOpe,
                 DatosCaja.cdsLineas,
                 DatosCaja.cdsCabecera,
                 ActualizarLabelTotal);
    end;
    if ConsolidarSiExiste(SkuDetectado) then
    begin
       // RellenarDatosArticuloEnDataset ya CONFIRMA (Post) la linea de trabajo
       // en su recalculo fiscal interno, asi que un Cancel no la elimina: si
       // tras cancelar sigue ahi y es el mismo SKU recien consolidado, la
       // BORRAMOS para no dejar duplicado (mismo patron que
       // FinalizarUltimoAtributo).
       if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
         DatosCaja.cdsLineas.Cancel;
       if not DatosCaja.cdsLineas.IsEmpty then
         if DatosCaja.cdsLineas.FieldByName('CODIGO_UNIDAD_FACLIN').AsString
              = SkuDetectado then
           DatosCaja.cdsLineas.Delete;
       DatosCaja.cdsLineas.Append;
       DisplayValue := null;
       Error := False;
       Abort;
    end;
    tmrBusq.Enabled := False;
    if (CodigoPadre <> '') and (CodigoPadre <> CodigoInput) then
    begin
       DisplayValue := CodigoPadre;
       qryBusq.Connection := ConexionPrincipal;
       if qryBusq.Active then qryBusq.Close;
       qryBusq.ParamByName('TARIFA').AsString :=
                                              DatosCaja.cdsCabecera.FieldByName(
                                    'TARIFA_ARTICULO_CLIENTE_FAC').AsString;
       qryBusq.ParamByName('FECHA_TARIFA').AsDate :=
                                              DatosCaja.cdsCabecera.FieldByName(
                                                       'FECHA_FAC').AsDateTime;
       qryBusq.ParamByName('TOKEN').AsString := CodigoPadre;
       qryBusq.Open;
    end;
    ActualizarColumnasDinamicas(CodigoPadre);
    // Solo desglosamos atributos si SkuDetectado es un SKU real (distinto
    // del padre). Si SkuDetectado == CodigoPadre estamos a la espera de
    // que el usuario elija talla/color: la query no encontraria nada y
    // gastariamos un round-trip a BBDD para nada.
    if (Trim(SkuDetectado) <> '') and (NumAtributos > 0)
       and (SkuDetectado <> CodigoPadre) then
    begin
       RellenarAtributosDesdeSku(SkuDetectado);
    end;
    Error := False;
  end
  else
  begin
    Error := True;
    if FMotivoRechazoArticulo <> '' then
      ErrorText := FMotivoRechazoArticulo
    else
      ErrorText := SErrorArticuloCajaNoEncontradoDescatalogado;
  end;
end;

procedure TfrmMtoOpeCaja.tvDescuentoMenosPropertiesEditValueChanged(
  Sender: TObject);
begin
  // Ponemos a 0 los precios finales para que CalcularLinea
  // respete el descuento y calcule el precio en base a él.
  if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
  begin
    DatosCaja.cdsLineas.FieldByName(
      'PRECIO_VENTA_CIVA_ARTICULO_FACLIN').AsCurrency := 0;
    DatosCaja.cdsLineas.FieldByName(
      'PRECIO_VENTA_SIVA_ARTICULO_FACLIN').AsCurrency := 0;
  end;

  GridRecalc(ConexionPrincipal,Sender,
             tvLineasOpe,
             DatosCaja.cdsLineas,
             DatosCaja.cdsCabecera,
             ActualizarLabelTotal);
end;

procedure TfrmMtoOpeCaja.tvDescuentoPropertiesEditValueChanged(Sender: TObject);
begin
  // Ponemos a 0 los precios finales para que CalcularLinea
  // respete el descuento y calcule el precio en base a él.
  if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
  begin
    DatosCaja.cdsLineas.FieldByName(
      'PRECIO_VENTA_CIVA_ARTICULO_FACLIN').AsCurrency := 0;
    DatosCaja.cdsLineas.FieldByName(
      'PRECIO_VENTA_SIVA_ARTICULO_FACLIN').AsCurrency := 0;
  end;

  GridRecalc(ConexionPrincipal,Sender,
             tvLineasOpe,
             DatosCaja.cdsLineas,
             DatosCaja.cdsCabecera,
             ActualizarLabelTotal);
end;

procedure TfrmMtoOpeCaja.tvPrecioUniPropertiesEditValueChanged(Sender: TObject);
begin
  if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
  begin
    DatosCaja.cdsLineas.FieldByName(
                     'PRECIO_VENTA_CIVA_ARTICULO_FACLIN').AsCurrency := 0;
    DatosCaja.cdsLineas.FieldByName(
                     'PRECIO_VENTA_SIVA_ARTICULO_FACLIN').AsCurrency := 0;
  end;

  GridRecalc(ConexionPrincipal,Sender,
             tvLineasOpe,
             DatosCaja.cdsLineas,
             DatosCaja.cdsCabecera,
             ActualizarLabelTotal);
end;

procedure TfrmMtoOpeCaja.tvTotalPropertiesEditValueChanged(Sender: TObject);
begin
  GridRecalc(ConexionPrincipal,Sender,
             tvLineasOpe,
             DatosCaja.cdsLineas,
             DatosCaja.cdsCabecera,
             ActualizarLabelTotal);
end;

procedure TfrmMtoOpeCaja.tvUdsPropertiesEditValueChanged(Sender: TObject);
begin
  GridRecalc(ConexionPrincipal,Sender,
             tvLineasOpe,
             DatosCaja.cdsLineas,
             DatosCaja.cdsCabecera,
             ActualizarLabelTotal);
end;

procedure TfrmMtoOpeCaja.tvUdsPropertiesValidate(Sender: TObject;
  var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
var
  VieneDeDep: string;
  CantOriginal, NuevaCant: Double;
begin
  if (DatosCaja = nil) or not DatosCaja.cdsLineas.Active then
    Exit;
  VieneDeDep := DatosCaja.cdsLineas.FieldByName('VIENE_DE_DEPOSITO').AsString;
  if VieneDeDep = 'S' then
  begin
    // Convertimos de forma segura el valor tecleado a float
    NuevaCant := StrToFloatDef(VarToStrDef(DisplayValue, '0'), 0);
    CantOriginal := DatosCaja.cdsLineas.FieldByName(
                                              'CANTIDAD_FACLIN').AsFloat;
    // Verificamos que la magnitud sea idéntica (solo permite cambiar signo)
    if Abs(NuevaCant) <> Abs(CantOriginal) then
    begin
      Error := True;
      ErrorText := SErrorCantidadArticuloDepositoCajaNoValida;
    end
    else
    begin
      Error := False;

      // NUEVA LÓGICA: Si cambia a negativo, es una CANCELACIÓN
      if NuevaCant < 0 then
      begin
        DatosCaja.cdsLineas.FieldByName('ACCION_DEPOSITO').AsString :=
                                                                     'CANCELAR';
        // Ponemos el precio a 0 para no devolver el dinero de la prenda
        DatosCaja.cdsLineas.FieldByName(
                                  'PRECIO_SALIDA_FACLIN').AsCurrency := 0;
        DatosCaja.cdsLineas.FieldByName(
                     'PRECIO_VENTA_CIVA_ARTICULO_FACLIN').AsCurrency := 0;
        DatosCaja.cdsLineas.FieldByName(
                     'PRECIO_VENTA_SIVA_ARTICULO_FACLIN').AsCurrency := 0;
        DatosCaja.cdsLineas.FieldByName(
                                       'PORCENTAJE_DTO_FACLIN').AsFloat := 0;
        DatosCaja.cdsLineas.FieldByName(
                                    'PRECIO_DTO_FACLIN').AsCurrency := 0;
      end
      else
      begin
        // Si lo vuelve a poner en positivo, restauramos la acción y su precio
        DatosCaja.cdsLineas.FieldByName('ACCION_DEPOSITO').AsString := 'COBRAR';
        DatosCaja.cdsLineas.FieldByName('PRECIO_SALIDA_FACLIN').AsCurrency :=
          DatosCaja.cdsLineas.FieldByName('PRECIO_ORIGINAL_DEP').AsCurrency;
      end;
    end;
  end;
end;

function TfrmMtoOpeCaja.RellenarDatosArticuloEnDataset(Codigo: string): Boolean;
var
  CodigoLimpio  : string;
  Validador     : TArticulosValidador;
  Resolver      : TArticulosResolver;
  Resolucion    : TArtResolucionEntrada;
  Datos         : TArticuloDatos;
  CodTarifa     : string;
  FechaTicket   : TDateTime;
begin
  Result := False;
  FMotivoRechazoArticulo := '';
  CodigoLimpio := UpperCase(Trim(Codigo));
  if CodigoLimpio = '' then Exit;
  Validador := TArticulosValidador.Create(ConexionPrincipal);
  Resolver := TArticulosResolver.Create(
    ConexionPrincipal,
    ParametrosCaja);
  try
    // Si la entrada viene de la pistola (STX...ETX), resolvemos UNICAMENTE
    // contra codigos de barras; en cualquier otro caso, busqueda unificada.
    if FResolviendoPorScanner then
      Resolucion := Validador.ResolverCodigoBarras(CodigoLimpio)
    else
      Resolucion := Validador.Resolver(CodigoLimpio);
    if not Resolucion.Encontrado then
    begin
      Exit;
    end;

    CodTarifa   := DatosCaja.cdsCabecera.FieldByName(
                                          'TARIFA_ARTICULO_CLIENTE_FAC').AsString;
    FechaTicket := DatosCaja.cdsCabecera.FieldByName('FECHA_FAC').AsDateTime;

    DatosCaja.cdsLineas.DisableControls;
    try
      if DatosCaja.cdsLineas.State = dsBrowse then DatosCaja.cdsLineas.Edit;
      DatosCaja.cdsLineas.FieldByName('DESCRIPCION_ARTICULO_FACLIN').AsString :=
                                                Resolucion.DescripcionArticulo;
      DatosCaja.cdsLineas.FieldByName('TIPO_ARTICULO_FACLIN').AsString :=
                                                Resolucion.TipoArticulo;
      DatosCaja.cdsLineas.FieldByName('CODIGO_ART_FACLIN').AsString :=
                                                Resolucion.CodigoArticulo;
      DatosCaja.cdsLineas.FieldByName(
        'NUM_ATRIBUTOS_REQ_FACTURA_LINEA').AsInteger
                                                := Resolucion.NumAtributosReq;

      if Resolucion.CodigoSku <> '' then
      begin
        // SKU resuelto (uno único, o detectado por la vista de búsqueda).
        if not FActualizandoDepositos then
        begin
          ConsultarStock(Resolucion.CodigoSku);
        end;
        DatosCaja.cdsLineas.FieldByName('CODIGO_UNIDAD_FACLIN').AsString :=
                                                Resolucion.CodigoSku;
        RecalcularPrecioDesdeSku(Resolucion.CodigoSku);
        Result := True;
      end
      else if Resolucion.RequiereSku then
      begin
        // Padre con varios SKUs: se mostrarán talla/color al usuario. La
        // línea queda con descripción/IVA/% dto del padre, pero sin precio
        // definitivo hasta que se elija el SKU.
        if not FActualizandoDepositos then
        begin
          ConsultarStock(Resolucion.CodigoArticulo);
        end;
        DatosCaja.cdsLineas.FieldByName('CODIGO_UNIDAD_FACLIN').AsString :=
                                                Resolucion.CodigoArticulo;
        if not FActualizandoDepositos then
        begin
          Datos := Resolver.ResolverDatos(Resolucion.CodigoArticulo, '',
                                          CodTarifa, FechaTicket);
          // ResolverDatos no calcula precio cuando hay >1 SKU sin elegir;
          // pedimos el del padre explícitamente para arrastrar IVA y %dto.
          var Precio := Resolver.ResolverPrecio(Resolucion.CodigoArticulo, '',
                                                CodTarifa, FechaTicket);
          DatosCaja.cdsLineas.FieldByName('TIPO_IVA_ARTICULO_FACLIN').AsString
                                                := Datos.TipoIVA;
          DatosCaja.cdsLineas.FieldByName('ESIMP_INCL_TARIFA_FACLIN').AsString
                                                := IfThen(Precio.EsImpIncl,
                                                          'S',
                                                          'N');
          DatosCaja.cdsLineas.FieldByName('PORCENTAJE_DTO_FACLIN').AsFloat
                                                := Precio.PorcentajeDto;
          DatosCaja.cdsLineas.FieldByName('PRECIO_SALIDA_FACLIN').AsCurrency :=
            0;
          DatosCaja.cdsLineas.FieldByName('PRECIO_DTO_FACLIN').AsCurrency := 0;
          DatosCaja.cdsLineas.FieldByName(
                            'PRECIO_VENTA_CIVA_ARTICULO_FACLIN').AsCurrency := 0;
          DatosCaja.cdsLineas.FieldByName(
                            'PRECIO_VENTA_SIVA_ARTICULO_FACLIN').AsCurrency := 0;
          DatosCaja.cdsLineas.FieldByName('CANTIDAD_FACLIN').AsCurrency := 1;
        end;
        Result := True;
      end
      else
      begin
        // Artículo localizado y activo, pero sin SKU vendible (p. ej. una
        // variación que se quedó sin tallas/colores). Guardamos el motivo
        // para que el validador de caja muestre un mensaje exacto en vez
        // del genérico "no encontrado o descatalogado".
        FMotivoRechazoArticulo := Resolucion.Mensaje;
      end;
    finally
      DatosCaja.cdsLineas.EnableControls;
    end;
    if Result and (not FActualizandoDepositos) then
      GridRecalc(ConexionPrincipal,nil, tvLineasOpe, DatosCaja.cdsLineas,
                 DatosCaja.cdsCabecera, ActualizarLabelTotal);
  finally
    FreeAndNil(Validador);
    FreeAndNil(Resolver);
  end;
end;

procedure TfrmMtoOpeCaja.repComboBoxPropertiesInitPopup(Sender: TObject);
var
  View: TcxGridDBTableView;
begin
  if Sender is TcxExtLookupComboBox then
  begin
    if TcxExtLookupComboBox(Sender).Properties.View is TcxGridDBTableView then
    begin
       View := TcxGridDBTableView(TcxExtLookupComboBox(Sender).Properties.View);
       View.BeginUpdate;
       try
         View.Controller.IncSearchingText := '';
         View.DataController.Filter.Clear;
         View.DataController.Filter.Active := False;
         View.DataController.Filter.AutoDataSetFilter := False;
         View.DataController.Refresh;
       finally
         View.EndUpdate;
       end;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.RecalcularPrecioDesdeSku(sSKU: string);
var
  Resolver     : TArticulosResolver;
  Precio       : TArticuloPrecio;
  CodTarifa    : string;
  CodArt       : string;
  FechaFactura : TDateTime;
begin
  if Trim(sSKU) = '' then Exit;
  CodTarifa    := DatosCaja.cdsCabecera.FieldByName(
                                       'TARIFA_ARTICULO_CLIENTE_FAC').AsString;
  FechaFactura := DatosCaja.cdsCabecera.FieldByName('FECHA_FAC').AsDateTime;
  CodArt       := DatosCaja.cdsLineas.FieldByName('CODIGO_ART_FACLIN').AsString;

  Resolver := TArticulosResolver.Create(
    ConexionPrincipal,
    ParametrosCaja);
  try
    Precio := Resolver.ResolverPrecio(CodArt, sSKU, CodTarifa, FechaFactura);
    if not Precio.TieneRegistro then Exit;

    DatosCaja.cdsLineas.FieldByName('ESIMP_INCL_TARIFA_FACLIN').AsString :=
                                                IfThen(Precio.EsImpIncl,
                                                       'S',
                                                       'N');
    DatosCaja.cdsLineas.FieldByName('PRECIO_SALIDA_FACLIN').AsCurrency :=
                                                Precio.PrecioSalida;
    DatosCaja.cdsLineas.FieldByName('CANTIDAD_FACLIN').AsCurrency := 1;
    DatosCaja.cdsLineas.FieldByName('PORCENTAJE_DTO_FACLIN').AsFloat :=
                                                Precio.PorcentajeDto;

    DatosCaja.cdsLineas.FieldByName('PRECIO_DTO_FACLIN').AsCurrency := 0;
    DatosCaja.cdsLineas.FieldByName(
                          'PRECIO_VENTA_CIVA_ARTICULO_FACLIN').AsCurrency := 0;
    DatosCaja.cdsLineas.FieldByName(
                          'PRECIO_VENTA_SIVA_ARTICULO_FACLIN').AsCurrency := 0;

    GridRecalc(ConexionPrincipal,nil, tvLineasOpe, DatosCaja.cdsLineas,
               DatosCaja.cdsCabecera, ActualizarLabelTotal);
  finally
    FreeAndNil(Resolver);
  end;
end;

procedure TfrmMtoOpeCaja.RellenarAtributosDesdeSku(Sku: string);
var
  Lookup  : TArticulosAtributosLookup;
  Valores : TArray<TArticuloAtributoValor>;
  V       : TArticuloAtributoValor;
  i       : Integer;
begin
  if Trim(Sku) = '' then Exit;
  Lookup := TArticulosAtributosLookup.Create(ConexionPrincipal);
  try
    Valores := Lookup.ObtenerAtributosDeSku(Sku);
    if Length(Valores) = 0 then
    begin
      Exit;
    end;

    if not (DatosCaja.cdsLineas.State in [dsEdit, dsInsert]) then
      DatosCaja.cdsLineas.Edit;

    for V in Valores do
    begin
      i := V.Orden;
      if (i >= 1) and (i <= 5) then
        DatosCaja.cdsLineas.FieldByName('ATTR' + IntToStr(
          i) + '_VALOR').AsString
                                                                       := V.Valor;
    end;
  finally
    FreeAndNil(Lookup);
  end;
end;

function TfrmMtoOpeCaja.ConsolidarSiExiste(SkuBuscado: string): Boolean;
var
  Clon: TClientDataSet;
  OldQty: Double;
  VieneDeDep: string;
begin
  Result := False;
  if ParametrosCaja.GetBool('vgerAgruparUnidadesIguales', False) and
     (Trim(SkuBuscado) <> '') then
  begin
    Clon := TClientDataSet.Create(nil);
    try
      Clon.CloneCursor(DatosCaja.cdsLineas, True);
      Clon.First;
      while not Clon.Eof do
      begin
        VieneDeDep := Clon.FieldByName('VIENE_DE_DEPOSITO').AsString;
        // Solo consolidamos líneas de venta normal.
        // Las líneas de depósito ('S' = prenda apartada, 'A' = abono)
        // NO se consolidan: representan operaciones distintas aunque
        // compartan SKU con un artículo que el cliente se lleva ahora.
        if (VieneDeDep <> 'S') and (VieneDeDep <> 'A') and
           (Clon.FieldByName('CODIGO_UNIDAD_FACLIN').AsString = SkuBuscado)
           and (Clon.RecNo <> DatosCaja.cdsLineas.RecNo) then
        begin
          OldQty := Clon.FieldByName('CANTIDAD_FACLIN').AsFloat;
          Clon.Edit;
          Clon.FieldByName('CANTIDAD_FACLIN').AsFloat := OldQty + 1;
          dsLineas.DataSet.DisableControls;
          Clon.Post;
          dsLineas.DataSet.EnableControls;
          GridRecalc(ConexionPrincipal,nil,
                     tvLineasOpe,
                     DatosCaja.cdsLineas,
                     DatosCaja.cdsCabecera,
                     ActualizarLabelTotal);
          Result := True;
          Break;
        end;
        Clon.Next;
      end;
    finally
      FreeAndNil(Clon);
    end;
  end;
end;

procedure TfrmMtoOpeCaja.ConstruirColumnasDinamicas;
var
  i: Integer;
  Col: TcxGridDBColumn;
  MaxAtributos: Integer;
  IndiceBase:Integer;
begin
  MaxAtributos := 5;
  IndiceBase := tvArticulo.Index;
  tvLineasOpe.BeginUpdate;
  try
    for i := 1 to MaxAtributos do
    begin
      Col := tvLineasOpe.CreateColumn;
      Col.Name := 'tvAtributoDyn' + IntToStr(i);
      Col.Tag := i;
      Col.DataBinding.FieldName := 'ATTR' + IntToStr(i) + '_VALOR';
      Col.Caption := '-';
      Col.Visible := False;
      Col.Width := 80;
      // TcxButtonEdit con un boton bkEllipsis (que cambiamos a bkGlyph en
      // InitEdit cuando el AV actual tiene swatch en la paleta basica). El
      // click abre SeleccionarAvConPaleta — mismo patron que inMtoInventarios.
      Col.PropertiesClass := TcxButtonEditProperties;
      with TcxButtonEditProperties(Col.Properties) do
      begin
        ReadOnly := True;
        Buttons.Clear;
        with Buttons.Add do
        begin
          Default := True;
          Kind := bkEllipsis;
        end;
        OnButtonClick := tvLineasOpeAvButtonClick;
      end;
      Col.Index := IndiceBase + i;
    end;
  finally
    tvLineasOpe.EndUpdate;
  end;
end;

procedure TfrmMtoOpeCaja.PoblarAtributosLineasDeposito;
var
  QryNom: TUniQuery;
  Nombres: TStringList;
  art, sku: string;
  i: Integer;
begin
  // Rellena Color/Talla (ATTR*_NOMBRE/_VALOR) de cada prenda apartada que se
  // ha cargado con F2, igual que haria un escaneo normal, para que se vean
  // sin entrar linea por linea. La carga de depositos no los puebla (esta
  // optimizada para no lanzar queries por fila).
  QryNom := TUniQuery.Create(nil);
  Nombres := TStringList.Create;
  DatosCaja.cdsLineas.DisableControls;
  FActualizandoDepositos := True;
  try
    QryNom.Connection := ConexionPrincipal;
    QryNom.SQL.Text :=
      'SELECT vat.NOMBRE_VA AS NOMBRE_ATRIBUTO ' +
      '  FROM fza_articulos a ' +
      '  JOIN fza_variaciones_atributos vat ' +
      '    ON vat.ID_VAR_VA = a.TIPO_VARIACION_ART ' +
      ' WHERE a.CODIGO_ART_ART = :ART ' +
      ' ORDER BY vat.ORDEN_VA LIMIT 5';
    DatosCaja.cdsLineas.First;
    while not DatosCaja.cdsLineas.Eof do
    begin
      // Solo las prendas ('S'); el abono ('A') no tiene Color/Talla.
      if DatosCaja.cdsLineas.FieldByName(
                                     'VIENE_DE_DEPOSITO').AsString = 'S' then
      begin
        art := DatosCaja.cdsLineas.FieldByName('CODIGO_ART_FACLIN').AsString;
        sku := DatosCaja.cdsLineas.FieldByName('CODIGO_UNIDAD_FACLIN').AsString;
        Nombres.Clear;
        QryNom.Close;
        QryNom.ParamByName('ART').AsString := art;
        QryNom.Open;
        while not QryNom.Eof do
        begin
          Nombres.Add(QryNom.FieldByName('NOMBRE_ATRIBUTO').AsString);
          QryNom.Next;
        end;
        DatosCaja.cdsLineas.Edit;
        DatosCaja.cdsLineas.FieldByName(
          'NUM_ATRIBUTOS_REQ_FACTURA_LINEA').AsInteger := Nombres.Count;
        for i := 1 to 5 do
        begin
          if i <= Nombres.Count then
            DatosCaja.cdsLineas.FieldByName(
              'ATTR' + IntToStr(i) + '_NOMBRE').AsString := Nombres[i - 1]
          else
            DatosCaja.cdsLineas.FieldByName(
              'ATTR' + IntToStr(i) + '_NOMBRE').AsString := '';
        end;
        RellenarAtributosDesdeSku(sku);
        DatosCaja.cdsLineas.Post;
      end;
      DatosCaja.cdsLineas.Next;
    end;
  finally
    FActualizandoDepositos := False;
    DatosCaja.cdsLineas.EnableControls;
    FreeAndNil(Nombres);
    FreeAndNil(QryNom);
  end;
end;

procedure TfrmMtoOpeCaja.MostrarColumnasCuentaCliente(AActivar: Boolean);
var
  Clon: TClientDataSet;
  Col: TcxGridDBColumn;
  Nombre: string;
  i: Integer;
begin
  // Vista de cuenta de cliente (F2): sobran las columnas % y Menos y faltan
  // Color/Talla. AActivar=True monta esa vista; False vuelve a la normal (el
  // escaneo reactiva los atributos por linea).
  tvLineasOpe.BeginUpdate;
  try
    tvDescuento.Visible := not AActivar;
    tvDescuentoMenos.Visible := not AActivar;
    if AActivar then
    begin
      Clon := TClientDataSet.Create(nil);
      try
        Clon.CloneCursor(DatosCaja.cdsLineas, True);
        for i := 1 to 5 do
        begin
          Col := ObtenerColumnaPorTag(i);
          if Col <> nil then
          begin
            // Caption = nombre del atributo de la primera prenda que lo tenga.
            Nombre := '';
            Clon.First;
            while (Nombre = '') and not Clon.Eof do
            begin
              if Clon.FieldByName('VIENE_DE_DEPOSITO').AsString = 'S' then
                Nombre := Clon.FieldByName(
                  'ATTR' + IntToStr(i) + '_NOMBRE').AsString;
              Clon.Next;
            end;
            Col.Options.Editing := False;
            if Nombre <> '' then
            begin
              Col.Caption := Nombre;
              Col.Visible := True;
            end
            else
            begin
              Col.Caption := '-';
              Col.Visible := False;
            end;
          end;
        end;
      finally
        FreeAndNil(Clon);
      end;
    end
    else
    begin
      // Reseteamos los atributos e invalidamos la cache para que el proximo
      // escaneo los vuelva a pintar segun el articulo.
      for i := 1 to 5 do
      begin
        Col := ObtenerColumnaPorTag(i);
        if Col <> nil then
        begin
          Col.Visible := False;
          Col.Caption := '-';
          Col.Options.Editing := False;
        end;
      end;
      FUltimoArticuloPadre := '';
    end;
  finally
    tvLineasOpe.EndUpdate;
  end;
end;

// CAMBIO 2: OnAtributoChanged sale inmediatamente si estamos inicializando el
// combo
procedure TfrmMtoOpeCaja.OnAtributoChanged(Sender: TObject);
var
  Edit: TcxCustomEdit;
  SkuNuevo: string;
begin
  // Si ForzarDespliegue está asignando ItemIndex := 0, no procesamos
  if FInicializandoCombo then Exit;
  Edit := Sender as TcxCustomEdit;
  if not DatosCaja.cdsLineas.Active then Exit;
  Edit.PostEditValue;
  if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
  begin
     SkuNuevo := DatosCaja.GenerarSkuFinal(
        DatosCaja.cdsLineas.FieldByName(
                                       'CODIGO_ART_FACLIN').AsString
     );
     DatosCaja.cdsLineas.FieldByName('CODIGO_UNIDAD_FACLIN').AsString :=
                                                                       SkuNuevo;
     var NumAtributosRequeridos := DatosCaja.cdsLineas.FieldByName(
                                   'NUM_ATRIBUTOS_REQ_FACTURA_LINEA').AsInteger;
     var NumSeparadores := 0;
     for var i := 1 to Length(SkuNuevo) do
     begin
        if SkuNuevo[i] = '/' then
           Inc(NumSeparadores);
     end;
     if NumSeparadores = NumAtributosRequeridos then
       RecalcularPrecioDesdeSku(SkuNuevo);
  end;
end;

procedure TfrmMtoOpeCaja.cxGrid1DBTableView1CanFocusRecord(
  Sender: TcxCustomGridTableView; ARecord: TcxCustomGridRecord;
  var AAllow: Boolean);
var
  CodArticulo, SkuActual: string;
begin
  if (DatosCaja.cdsLineas.State = dsInsert) then
  begin
    CodArticulo := DatosCaja.cdsLineas.FieldByName(
                                      'CODIGO_ART_FACLIN').AsString;
    if Trim(CodArticulo) = '' then
    begin
      DatosCaja.cdsLineas.Cancel;
    end
    else
    begin
      SkuActual := DatosCaja.cdsLineas.FieldByName(
                                        'CODIGO_UNIDAD_FACLIN').AsString;
      if SkuActual = '' then
         SkuActual := CodArticulo;
      if ConsolidarSiExiste(SkuActual) then
      begin
        // La linea de trabajo ya puede estar grabada: Cancel no la quita.
        // Si tras cancelar sigue ahi con el mismo SKU consolidado, la
        // borramos para no duplicar (mismo patron que en Validate).
        if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
          DatosCaja.cdsLineas.Cancel;
        if not DatosCaja.cdsLineas.IsEmpty then
          if DatosCaja.cdsLineas.FieldByName('CODIGO_UNIDAD_FACLIN').AsString
               = SkuActual then
            DatosCaja.cdsLineas.Delete;
      end;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.cxGrid1DBTableView1Editing(
  Sender: TcxCustomGridTableView; AItem: TcxCustomGridTableItem;
  var AAllow: Boolean);
begin
  if (DatosCaja <> nil) and
     DatosCaja.cdsLineas.Active and
     not DatosCaja.cdsLineas.IsEmpty then
  begin
    // Si la línea es la prenda base del depósito
    if DatosCaja.cdsLineas.FieldByName('VIENE_DE_DEPOSITO').AsString = 'S' then
    begin
      // Solo permitimos editar la columna de Cantidad/Unidades
      if AItem <> tvUds then
        AAllow := False;
    end
    // Si la línea es el abono (anticipo de dinero, marcado con 'A' según tu
    //UniDataCaja)
    else if DatosCaja.cdsLineas.FieldByName(
      'VIENE_DE_DEPOSITO').AsString = 'A' then
    begin
      // No permitimos tocar absolutamente nada de la línea del abono
      AAllow := False;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.cxGrid1DBTableView1EditKeyDown(
  Sender: TcxCustomGridTableView; AItem: TcxCustomGridTableItem;
  AEdit: TcxCustomEdit; var Key: Word; Shift: TShiftState);
var
  NumAtributos: Integer;
  PrimeraColAtributo: TcxGridDBColumn;
  ValorActual: string;
begin
  if (AItem = tvArticulo) and
     not (Key in [VK_RETURN, VK_ESCAPE, VK_UP, VK_DOWN, VK_TAB, VK_LEFT,
                  VK_RIGHT, VK_F1..VK_F12]) then
  begin
    tmrBusq.Enabled := False;
    tmrBusq.Enabled := True;
  end;
  if (Key = VK_UP) and (DatosCaja.cdsLineas.State = dsInsert) then
  begin
    var CodArticulo := DatosCaja.cdsLineas.FieldByName(
                                      'CODIGO_ART_FACLIN').AsString;
    if Trim(CodArticulo) = '' then
    begin
      DatosCaja.cdsLineas.Cancel;
      Key := 0;
      Exit;
    end;
  end;
  if (Key <> VK_RETURN) then
    Exit;
  if (AItem = tvArticulo) then
  begin
    tmrBusq.Enabled := False;
    // Doble Enter en la columna Articulo: el TcxExtLookupComboBox tiene
    // ImmediateDropDownWhenActivated=True, asi que cuando el usuario
    // teclea el codigo el dropdown queda abierto. El primer Enter cierra
    // el dropdown internamente (selecciona la fila resaltada) y se
    // "consume" sin que PostEditValue dispare Validate; hace falta un
    // segundo Enter para confirmar. Lo cerramos aqui explicitamente para
    // que el flujo siga en el mismo handler: DroppedDown:=False, luego
    // PostEditValue -> Validate -> avance de foco, todo en un solo Enter.
    if (AEdit is TcxCustomDropDownEdit)
       and TcxCustomDropDownEdit(AEdit).DroppedDown then
      TcxCustomDropDownEdit(AEdit).DroppedDown := False;
    if AEdit is TcxCustomTextEdit then
      ValorActual := Trim(TcxCustomTextEdit(AEdit).Text)
    else
      ValorActual := Trim(VarToStr(AEdit.EditValue));
    if ValorActual = '' then
    begin
      var sCodigo := BuscarArticulo;
      if sCodigo <> '' then
      begin
        AEdit.EditValue := sCodigo;
        if not RellenarDatosArticuloEnDataset(sCodigo) then
        begin
          if FMotivoRechazoArticulo <> '' then
            ShowMessage(FMotivoRechazoArticulo)
          else
            ShowMessage(SErrorArticuloVentaCajaNoEncontrado);
          Key := 0;
          Exit;
        end;
      end
      else
      begin
        Key := 0;
        Exit;
      end;
    end;
    FArticuloResueltoEdicion := '';
    AEdit.PostEditValue;
    if DatosCaja.cdsLineas.State = dsBrowse then
      DatosCaja.cdsLineas.Edit;
    var CodArticuloActual := DatosCaja.cdsLineas.FieldByName(
                                      'CODIGO_ART_FACLIN').AsString;
    if (Trim(CodArticuloActual) = '') and
       (Trim(FArticuloResueltoEdicion) <> '') then
    begin
      CodArticuloActual := FArticuloResueltoEdicion;
      DatosCaja.cdsLineas.FieldByName(
        'CODIGO_ART_FACLIN').AsString := CodArticuloActual;
    end;
    ActualizarColumnasDinamicas(CodArticuloActual);
    // CAMBIO 3: Usar FNumAtributosActual en lugar de leer del dataset
    NumAtributos := FNumAtributosActual;
    var SkuDetectado := DatosCaja.cdsLineas.FieldByName(
                                        'CODIGO_UNIDAD_FACLIN').AsString;
    // Validación parametrizada del SKU resuelto (también protege la rama de
    // BuscarArticulo, que no pasa por tvArticuloPropertiesValidate).
    if (Trim(SkuDetectado) <> '') and (SkuDetectado <> CodArticuloActual) and
       not ValidarSkuParaVenta(SkuDetectado) then
    begin
      EliminarLineaPorValidacion;
      Key := 0;
      Exit;
    end;
    if (Trim(SkuDetectado) <> '') and (SkuDetectado <> CodArticuloActual) then
    begin
       RellenarAtributosDesdeSku(SkuDetectado);
       if ParametrosCaja.GetBool('vgerMoverLineaIdentif', True) then
       begin
         if DatosCaja.cdsLineas.State in [dsInsert, dsEdit] then
           DatosCaja.cdsLineas.Post;
         DatosCaja.cdsLineas.Append;
         tvLineasOpe.Controller.FocusedColumn := tvArticulo;
       end
       else
       begin
         tvLineasOpe.Controller.FocusedColumn := tvDescripcion;
       end;
       tvLineasOpe.Controller.EditingController.ShowEdit;
       Key := 0;
       Exit;
    end;
    if (NumAtributos = 0) then
    begin
       // Verificamos el parámetro para saber a dónde saltar
       if ParametrosCaja.GetBool('vgerMoverLineaIdentif', True) then
       begin
         // Comportamiento habitual: Guardar, nueva línea y foco a Artículo
         DatosCaja.cdsLineas.Post;
         DatosCaja.cdsLineas.Append;
         tvLineasOpe.Controller.FocusedColumn := tvArticulo;
       end
       else
       begin
         // Comportamiento alternativo: Quedarse en la línea y pasar a
         // Descripción
         tvLineasOpe.Controller.FocusedColumn := tvDescripcion;
       end;
       tvLineasOpe.Controller.EditingController.ShowEdit;
       Key := 0;
       Exit;
    end
    else if (NumAtributos > 0) then
    begin
       if Trim(SkuDetectado) <> '' then
          RellenarAtributosDesdeSku(SkuDetectado);
       PrimeraColAtributo := ObtenerColumnaPorTag(1);
       if PrimeraColAtributo <> nil then
       begin
         PrimeraColAtributo.Visible := True;
         tvLineasOpe.Controller.FocusedColumn := PrimeraColAtributo;
         tvLineasOpe.Controller.EditingController.ShowEdit;
         Key := 0;
         Exit;
       end;
    end;
  end;
  // Atributos dinamicos (Color, Talla, ...) ya no usan TcxComboBox: el
  // popup SeleccionarAvConPaleta se abre desde OnButtonClick del TcxButtonEdit
  // y la logica del ultimo atributo (validar SKU, consultar stock, avanzar
  // foco) vive en FinalizarUltimoAtributo, invocado desde RegistrarValorAtributo.
end;

procedure TfrmMtoOpeCaja.cxGrid1DBTableView1FocusedRecordChanged(
  Sender: TcxCustomGridTableView; APrevFocusedRecord,
  AFocusedRecord: TcxCustomGridRecord; ANewItemRecordFocusingChanged: Boolean);
var
  sCodPadre, sSku, VieneDeDep: string;
  EsDeposito: boolean;
begin
  if not DatosCaja.cdsLineas.Active then Exit;
  if FActualizandoDepositos then Exit;
  if AFocusedRecord = nil then Exit;
  if AFocusedRecord.IsNewItemRecord then
  begin
    // La línea nueva conserva el último stock mostrado y queda lista para
    // recibir un código de barras.
    btnF3.Enabled := True;
    btnF8.Enabled := True;
    SolicitarFocoArticuloLineaNueva;
  end
  else if not DatosCaja.cdsLineas.IsEmpty then
  begin
    VieneDeDep := DatosCaja.cdsLineas.FieldByName(
      'VIENE_DE_DEPOSITO').AsString;
    // Deshabilitar F3 y F8 (eliminar) visualmente en líneas de depósito
    EsDeposito := (VieneDeDep = 'S') or (VieneDeDep = 'A');
    btnF3.Enabled := not EsDeposito;
    btnF8.Enabled := not EsDeposito;
    sCodPadre := DatosCaja.cdsLineas.FieldByName(
      'CODIGO_ART_FACLIN').AsString;
    sSku := DatosCaja.cdsLineas.FieldByName(
      'CODIGO_UNIDAD_FACLIN').AsString;
    if sCodPadre <> '' then
      ActualizarColumnasDinamicas(sCodPadre);
    if (Pos('/', sSku) > 0) and
       (Trim(DatosCaja.cdsLineas.FieldByName(
         'ATTR1_VALOR').AsString) = '') then
      RellenarAtributosDesdeSku(sSku);
    if Trim(sSku) <> '' then
      ConsultarStock(sSku)
    else if Trim(sCodPadre) <> '' then
      ConsultarStock(sCodPadre);
  end;
end;


procedure TfrmMtoOpeCaja.cxGrid1DBTableView1InitEdit(
  Sender: TcxCustomGridTableView; AItem: TcxCustomGridTableItem;
  AEdit: TcxCustomEdit);
var
  BE        : TcxButtonEdit;
  AvActual  : string;
  NombreAtb : string;
  IdVa      : string;
  Mapa      : TDictionary<string, string>;
  Info      : TInfoBasico;
  Btn       : TcxEditButton;
begin
  // Estilo Excel: al entrar en una celda, teclear sustituye su contenido.
  if AEdit is TcxCustomTextEdit then
    TcxCustomTextEdit(AEdit).SelectAll;
  // Columnas de atributo dinamico (Color, Talla, ...). Mismo patron que
  // inMtoInventarios:
  //   (1) Si el AV actual tiene color en la paleta basica, el boton muestra
  //       un glyph con el cuadradito; si no, vuelve a bkEllipsis.
  //   (2) Si la celda esta vacia, OnEnter dispara el popup automaticamente
  //       (sustituye al antiguo Combo.DroppedDown via ForzarDespliegue).
  if (AItem.Tag >= 1) and (AItem.Tag <= 5) then
  begin
    if AEdit is TcxButtonEdit then
    begin
      BE := TcxButtonEdit(AEdit);
      BE.Tag := AItem.Tag;
      if BE.Properties.Buttons.Count > 0 then
      begin
        Btn := BE.Properties.Buttons[0];

        AvActual  := '';
        NombreAtb := '';
        if DatosCaja.cdsLineas.Active
           and (not DatosCaja.cdsLineas.IsEmpty) then
        begin
          AvActual  := DatosCaja.cdsLineas.FieldByName(
                         'ATTR' + IntToStr(AItem.Tag) + '_VALOR').AsString;
          NombreAtb := DatosCaja.cdsLineas.FieldByName(
                         'ATTR' + IntToStr(AItem.Tag) + '_NOMBRE').AsString;
        end;

        IdVa := '';
        Mapa := ObtenerMapaAtributosGlobal(ConexionPrincipal);
        if Mapa <> nil then
          Mapa.TryGetValue(UpperCase(Trim(NombreAtb)), IdVa);

        Info := Default(TInfoBasico);
        if (IdVa <> '') and (Trim(AvActual) <> '') then
          ObtenerInfoBasico(ConexionPrincipal,IdVa, AvActual, Info);

        if Info.EsValido and
           PintarSwatchEnBitmap(FBmpSwatchBoton, Info, 14) then
        begin
          Btn.Glyph.Assign(FBmpSwatchBoton);
          Btn.Kind := bkGlyph;
        end
        else
          Btn.Kind := bkEllipsis;

        if Trim(AvActual) = '' then
          BE.OnEnter := AbrirPopupAvEnEntrada
        else
          BE.OnEnter := nil;
      end;
    end;
  end;
  if AItem = tvArticulo then
  begin
    if AEdit is TcxCustomTextEdit then
      TcxCustomTextEdit(AEdit).Properties.OnChange :=
                                                     tvArticuloPropertiesChange;
    var ValorActual :=
                    AItem.GridView.Controller.FocusedRecord.Values[AItem.Index];
    if (not VarIsNull(ValorActual)) and (Trim(VarToStr(ValorActual)) <> '') then
    begin
       if AEdit is TcxCustomTextEdit then
       begin
          TcxCustomTextEdit(AEdit).Text := VarToStr(ValorActual);
          TcxCustomTextEdit(AEdit).SelectAll;
       end;
    end
    else
    begin
       if qryBusq.Active then
          qryBusq.Close;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.cxGrid1DBTableView1KeyDown(Sender: TObject;
  var Key: Word; Shift: TShiftState);
begin
  if (Key = VK_ESCAPE) then
  begin
    if DatosCaja.cdsLineas.State = dsInsert then
    begin
      DatosCaja.cdsLineas.Cancel;
      Key := 0;
      Exit;
    end;
    if DatosCaja.cdsLineas.RecordCount > 0 then
    begin
      if MessageDlg(SPreguntaCancelarVentaCaja,
                    mtConfirmation, [mbYes, mbNo], 0) = mrYes then
      begin
        Close;
      end;
    end
    else
    begin
      Close;
    end;
    Key := 0;
  end;
  if (Key = VK_UP) and (DatosCaja.cdsLineas.State = dsInsert) then
  begin
    var CodArticulo := DatosCaja.cdsLineas.FieldByName(
                                      'CODIGO_ART_FACLIN').AsString;
    if Trim(CodArticulo) = '' then
    begin
      DatosCaja.cdsLineas.Cancel;
      Key := 0;
      Exit;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.cxGrid1DBTableView1MouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  // No cambiar la celda elegida; solo crear una linea si no existe ninguna.
  if (Button = mbLeft) and DatosCaja.cdsLineas.IsEmpty then
    AsegurarLineaNueva;
end;

procedure TfrmMtoOpeCaja.cxGrid1Enter(Sender: TObject);
begin
  if not DatosCaja.cdsLineas.Active then Exit;
  if DatosCaja.cdsLineas.State = dsBrowse then
  begin
    DatosCaja.cdsLineas.Append;
    tvLineasOpe.Controller.FocusedColumn := tvArticulo;
    tvLineasOpe.Controller.EditingController.ShowEdit;
  end;
  jvEnterTab.EnterAsTab := False;
end;

procedure TfrmMtoOpeCaja.cxGrid1Exit(Sender: TObject);
begin
  jvEnterTab.EnterAsTab := True;
end;

procedure TfrmMtoOpeCaja.actBuscarEmpleadosExecute(Sender: TObject);
var
  LCtrl: TWinControl;
  CodigoBuscado: string;
  CurrentEdit: TcxCustomEdit;
begin
  if tvLineasOpe.Controller.FocusedItem <> nil then
  if (tvLineasOpe.Controller.FocusedItem.Tag > 0) then
  begin
    if dsLineas.DataSet.State = dsBrowse then
      dsLineas.DataSet.Edit;
    if not tvLineasOpe.Controller.EditingController.IsEditing then
    begin
      tvLineasOpe.Controller.EditingController.ShowEdit;
    end;
    if tvLineasOpe.Controller.EditingController.IsEditing then
     begin
       CurrentEdit := tvLineasOpe.Controller.EditingController.Edit;
       // F3 sobre una columna de atributo (Color, Talla, ...) abre el popup
       // SeleccionarAvConPaleta directamente, equivalente al antiguo
       // Combo.DroppedDown := True.
       if (CurrentEdit is TcxButtonEdit) then
       begin
         tvLineasOpeAvButtonClick(CurrentEdit, 0);
         Exit;
       end;
    end;
  end;
  LCtrl := Screen.ActiveControl;
  if (LCtrl = btnCodigoEmpleado) or (LCtrl.Parent = btnCodigoEmpleado) then
  begin
    BuscarEmpleados;
  end
  else if (LCtrl = btnCodigoCliente) or (LCtrl.Parent = btnCodigoCliente) then
  begin
    BuscarClientes;
  end
  else
  begin
    if DatosCaja.cdsLineas.Active and not DatosCaja.cdsLineas.IsEmpty then
    begin
      var VieneDeDep :=
                  DatosCaja.cdsLineas.FieldByName('VIENE_DE_DEPOSITO').AsString;
      if (VieneDeDep = 'S') or (VieneDeDep = 'A') then
        Exit;
    end;
    CodigoBuscado := BuscarArticulo;
    if CodigoBuscado <> '' then
    begin
      if DatosCaja.cdsLineas.State = dsBrowse then
      begin
        if DatosCaja.cdsLineas.IsEmpty then
          DatosCaja.cdsLineas.Append
        else
          DatosCaja.cdsLineas.Edit;
      end;
      if RellenarDatosArticuloEnDataset(CodigoBuscado) then
      begin
        var CodArticulo := DatosCaja.cdsLineas.FieldByName(
                                      'CODIGO_ART_FACLIN').AsString;
        var SkuDetectado := DatosCaja.cdsLineas.FieldByName(
               'CODIGO_UNIDAD_FACLIN').AsString; // <-- Rescatamos el SKU
        // Validación parametrizada del SKU resuelto en la búsqueda. Si el SKU
        // no existe o no tiene stock (según parámetros), descartamos la línea.
        if (Trim(SkuDetectado) <> '') and (SkuDetectado <> CodArticulo) and
           not ValidarSkuParaVenta(SkuDetectado) then
        begin
          EliminarLineaPorValidacion;
          Exit;
        end;
        ActualizarColumnasDinamicas(CodArticulo);
        var NumAtributos := FNumAtributosActual;
        if (Trim(SkuDetectado) <> '') and (NumAtributos > 0) then
        begin
           RellenarAtributosDesdeSku(SkuDetectado);
        end;
        cxgrdLineasOpe.SetFocus;
        // Comprobamos si es un SKU completo (el código de unidad es distinto al
        // padre)
        var EsSkuCompleto := (Trim(SkuDetectado) <> '')
           and (SkuDetectado <> CodArticulo);
        // Supongamos que lees tu parámetro global así (ajusta el nombre a tu
        // variable real)
        var AutoPasarLinea :=
          ParametrosCaja.GetBool('vgerMoverLineaIdentif', False);
        // Si necesita atributos Y NO ES un SKU ya cerrado, nos paramos en la
        // columna de atributos
        if (NumAtributos > 0) and not EsSkuCompleto then
        begin
          var PrimeraCol := ObtenerColumnaPorTag(1);
          if PrimeraCol <> nil then
          begin
            PrimeraCol.Visible := True;
            tvLineasOpe.Controller.FocusedColumn := PrimeraCol;
            tvLineasOpe.Controller.EditingController.ShowEdit;
          end;
        end
        else
        begin
          // El artículo ya está completo (sea simple o un SKU cerrado)
          if AutoPasarLinea then
          begin
            // Forzamos el guardado de la línea actual (si está en edición) para
            // evitar que se pierda
            if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
              DatosCaja.cdsLineas.Post;

            // Creamos línea nueva y ponemos el foco en el buscador de artículos
            DatosCaja.cdsLineas.Append;
            tvLineasOpe.Controller.FocusedColumn := tvArticulo;
            tvLineasOpe.Controller.EditingController.ShowEdit;
          end
          else
          begin
            // Si el parámetro está desactivado, el cajero decide. Lo normal es
            // dejarle en Cantidad.
          end;
        end;
      end;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.actCargarCtaExecute(Sender: TObject);
begin
  btnF2Click(Sender);
end;

procedure TfrmMtoOpeCaja.AbrirBuscarModificar;
var
  oAnfitrion: IAnfitrionCajaVentanas;
  oConsulta: IConsultaOperacionesCaja;
  oFormulario: TCustomForm;
begin
  if (FCodigoEmpresa = '') or
     (FCodigoAlmacen = '') or
     (FCodigoCaja = '') then
    ShowMessage(SErrorUbicacionCajaBuscarOperacionesNoAsignada)
  else
  begin
    oAnfitrion := ExigirAnfitrionCaja(Application.MainForm);
    oConsulta :=
      oAnfitrion.CrearConsultaOperacionesCaja(Application, Permisos);
    oFormulario := oConsulta.FormularioConsultaCaja;
    try
      oFormulario.PopupParent := Self;
      oConsulta.PrepararValores(
        FCodigoEmpresa,
        FCodigoAlmacen,
        FCodigoCaja,
        FFecha);
      oFormulario.Show;
    except
      FreeAndNil(oFormulario);
      raise;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.btnF10Click(Sender: TObject);
begin
  AbrirBuscarModificar;
end;

procedure TfrmMtoOpeCaja.actBuscarModificarExecute(Sender: TObject);
begin
  btnF10Click(Sender);
end;

procedure TfrmMtoOpeCaja.actCobroExecute(Sender: TObject);
begin
  btnF12Click(Sender);
end;

procedure TfrmMtoOpeCaja.actEliminarLineaExecute(Sender: TObject);
var
  VieneDeDep: string;
begin
  // NUEVO: Bloqueo de borrado
  if DatosCaja.cdsLineas.Active and not DatosCaja.cdsLineas.IsEmpty then
  begin
    VieneDeDep := DatosCaja.cdsLineas.FieldByName('VIENE_DE_DEPOSITO').AsString;
    if (VieneDeDep = 'S') or (VieneDeDep = 'A') then
    begin
      ShowMessage(SErrorLineaDepositoCajaNoEliminable);
      Exit;
    end;
  end;

  if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
    DatosCaja.cdsLineas.Cancel
  else
    if DatosCaja.cdsLineas.State in [dsBrowse] then
      DatosCaja.cdsLineas.Delete;
  AsegurarLineaNueva;
end;

procedure TfrmMtoOpeCaja.actGuardarLayoutExecute(Sender: TObject);
begin
  GuardarLayoutCaja;
end;

procedure TfrmMtoOpeCaja.actAbrirArticulosExecute(Sender: TObject);
var
  sCodArt: string;
begin
  sCodArt := '';
  if Assigned(DatosCaja) and
     Assigned(DatosCaja.cdsLineas) and
     DatosCaja.cdsLineas.Active then
    sCodArt := DatosCaja.cdsLineas.FieldByName('CODIGO_ART_FACLIN').AsString;
  ShowMto(Application.MainForm, 'Articulos', sCodArt);
end;

procedure TfrmMtoOpeCaja.RestaurarLayoutCaja;
var
  Layout: TLayoutLoader;
begin
  Layout := TLayoutLoader.Create(Self.Name, ContextoSesion, PerfilesUsuario);
  try
    if not Layout.Disponible then Exit;
    Layout.RestaurarGeometria(Self);
    Layout.RestaurarAlturaPanel('StockPanelHeight', pnlBusqueda, 30);
    Layout.RestaurarAnchoPanel('FotoStockWidth',   pnlFotoStock, 50);
    Layout.RestaurarGrid('Lineas', tvLineasOpe);
  finally
    FreeAndNil(Layout);
  end;
end;

procedure TfrmMtoOpeCaja.actSalirExecute(Sender: TObject);
begin
  if (DatosCaja.cdsLineas.Active) and (not DatosCaja.cdsLineas.IsEmpty) then
  begin
    if MessageDlg(SPreguntaBorrarVentaCaja,
                  mtConfirmation, [mbYes, mbNo], 0) = mrYes then
    begin
      if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
         DatosCaja.cdsLineas.Cancel;
      Close;
    end;
  end
  else
  begin
    Close;
  end;
end;

procedure TfrmMtoOpeCaja.ActualizarColumnasDinamicas(ArticuloPadre: string);
var
  i: Integer;
  Col: TcxGridDBColumn;
  NombresAtributos: TStringList;
  Cacheado: Boolean;
begin
  // --- OPTIMIZACIÓN: Si es el mismo tipo de artículo, no repintamos ---
  Cacheado := SameText(ArticuloPadre, FUltimoArticuloPadre);
  if Cacheado then
  begin
    Exit;
  end;
  FUltimoArticuloPadre := ArticuloPadre;

  NombresAtributos := TStringList.Create;
  try
    // Solo atacamos la base de datos si hay un artículo real
    if (ArticuloPadre <> '') and (ArticuloPadre <> 'ACUENTA') then
    begin
      datosCaja.qryDefinicionArticulo.Connection := ConexionPrincipal;
      datosCaja.qryDefinicionArticulo.Close;
      // ANTES: 4-way join sobre fza_articulos_skus -> fza_atributos_sku ->
      //        fza_atributos_valores -> vi_atributos_nombres con DISTINCT.
      //        Medido: 9.6 s en MariaDB con datos reales — el cuello del
      //        flujo "Enter del codigo -> primer popup". La vista
      //        vi_atributos_nombres por dentro hace un join + distinct
      //        y al envolverla aqui en otro JOIN+DISTINCT, el optimizador
      //        no la materializa.
      // AHORA: lookup directo fza_articulos -> fza_variaciones_atributos
      //        via TIPO_VARIACION_ART (que ya tiene indice). Es PK seek
      //        sobre articulos y PK seek sobre variaciones_atributos.
      //        Para un articulo con variacion TC, devuelve 2 filas
      //        (Color, Talla). Para un articulo sin variacion, 0 filas.
      datosCaja.qryDefinicionArticulo.SQL.Text :=
      'SELECT vat.NOMBRE_VA      AS NOMBRE_ATRIBUTO,    ' +
      '       vat.ORDEN_VA       AS ORDEN_VISUAL_ATRIBUTO ' +
      '  FROM fza_articulos a                            ' +
      '  JOIN fza_variaciones_atributos vat              ' +
      '    ON vat.ID_VAR_VA = a.TIPO_VARIACION_ART       ' +
      ' WHERE a.CODIGO_ART_ART = :ARTICULO               ' +
      ' ORDER BY vat.ORDEN_VA                            ' +
      ' LIMIT 5';
      datosCaja.qryDefinicionArticulo.ParamByName('ARTICULO').AsString :=
        ArticuloPadre;
      datosCaja.qryDefinicionArticulo.Open;
      while not datosCaja.qryDefinicionArticulo.Eof do
      begin
        NombresAtributos.Add(datosCaja.qryDefinicionArticulo.FieldByName(
          'NOMBRE_ATRIBUTO').AsString);
        datosCaja.qryDefinicionArticulo.Next;
      end;
    end;
    FNumAtributosActual := NombresAtributos.Count;

    // Solo tocamos la memoria del dataset si estamos escaneando algo nuevo
    if DatosCaja.cdsLineas.Active
       and (DatosCaja.cdsLineas.State in [dsEdit, dsInsert]) then
      DatosCaja.cdsLineas.FieldByName(
        'NUM_ATRIBUTOS_REQ_FACTURA_LINEA').AsInteger := NombresAtributos.Count;

    tvLineasOpe.BeginUpdate;
    try
      for i := 1 to 5 do
      begin
        Col := ObtenerColumnaPorTag(i);
        if (Col <> nil) then
        begin
          if i <= NombresAtributos.Count then
          begin
            Col.Caption := NombresAtributos[i-1];
            Col.Visible := True;
            Col.Options.Editing := True;
            if DatosCaja.cdsLineas.Active
               and (DatosCaja.cdsLineas.State in [dsEdit, dsInsert]) then
              DatosCaja.cdsLineas.FieldByName('ATTR' + IntToStr(
                i) + '_NOMBRE').AsString := NombresAtributos[i-1];
          end
          else
          begin
            Col.Visible := False;
            Col.Options.Editing := False;
            Col.Caption := '-';
          end;
        end;
      end;
    finally
      tvLineasOpe.EndUpdate;
    end;
  finally
    FreeAndNil(NombresAtributos);
  end;
//  tvLineasOpe.ApplyBestFit(nil, True, False);
end;

procedure TfrmMtoOpeCaja.ActualizarLabelTotal(Sender: TObject;
  NuevoTotal: Currency);
begin
  lblTotal.Caption := Format('Total %m', [NuevoTotal]);
end;

procedure TfrmMtoOpeCaja.RecalcularLineasDesdeDM;
begin
  GridRecalc(
    ConexionPrincipal,
    nil,
    tvLineasOpe,
    DatosCaja.cdsLineas,
    DatosCaja.cdsCabecera,
    ActualizarLabelTotal);
end;

procedure TfrmMtoOpeCaja.btnCodigoClienteExit(Sender: TObject);
var
  Edit: TcxCustomEdit;
begin
  if Sender is TcxCustomEdit then
  begin
    Edit := TcxCustomEdit(Sender);
    if Edit.EditModified then
    begin
      Edit.ValidateEdit(True);
      Edit.EditModified := False;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.btnCodigoClientePropertiesValidate(Sender: TObject;
  var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
var
  sNomCliente: string;
  sCodigo: string;
  Totales: TFacturaTotales;
  Cliente: TClienteCaja;
begin
  // Durante un escaneo no validamos el cliente: el foco se mueve a la rejilla
  // y el campo pudo quedar con la rafaga; lo da por bueno y no molesta.
  if FProcesandoLecturaScanner then
  begin
    Error := False;
    Exit;
  end;
  if FValidandoCliente then
    Exit;
  FValidandoCliente := True;
  try
  // =======================================================================
  // 1. LIMPIEZA INCONDICIONAL DE DEPÓSITOS DEL CLIENTE ANTERIOR
  // =======================================================================
  if DatosCaja.cdsLineas.Active then
  begin
    // Si hay una línea a medio meter, la cancelamos para evitar Abort en
    // BeforePost
    if DatosCaja.cdsLineas.State in [dsInsert, dsEdit] then
    begin
      if Trim(DatosCaja.cdsLineas.FieldByName(
        'CODIGO_ART_FACLIN').AsString) = '' then
        DatosCaja.cdsLineas.Cancel
      else
        DatosCaja.cdsLineas.Post;
    end;
    DatosCaja.cdsLineas.DisableControls;
    try
      DatosCaja.cdsLineas.First;
      while not DatosCaja.cdsLineas.Eof do
      begin
        if (DatosCaja.cdsLineas.FieldByName('VIENE_DE_DEPOSITO').AsString = 'S')
           or
           (DatosCaja.cdsLineas.FieldByName(
             'VIENE_DE_DEPOSITO').AsString = 'A') then
        begin
          DatosCaja.cdsLineas.Delete;
        end
        else
        begin
          DatosCaja.cdsLineas.Next;
        end;
      end;
    finally
      DatosCaja.cdsLineas.EnableControls;
    end;
  end;
  // =======================================================================
  // 2. BÚSQUEDA Y ASIGNACIÓN DEL NUEVO CLIENTE
  // =======================================================================
  sCodigo := VarToStr(DisplayValue);

  if Trim(sCodigo) = '' then
  begin
    lblNombreCliente.Caption := 'VENTA CONTADO';
    DatosCaja.cdsCabecera.Edit;
    DatosCaja.cdsCabecera.FieldByName('CODIGO_CLI_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'RAZON_SOCIAL_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName('NIF_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName('MOVIL_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName('EMAIL_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'DIRECCION1_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'DIRECCION2_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName('POBLACION_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName('PROVINCIA_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'CODIGO_POSTAL_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'CODIGO_PAI_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'NOMBRE_PAI_CLIENTE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'CODIGO_OFICINA_CONTABLE_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'CODIGO_ORGANO_GESTOR_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName(
      'CODIGO_UNIDAD_TRAMITADORA_FAC').AsString := '';
    DatosCaja.cdsCabecera.FieldByName('TARIFA_ARTICULO_CLIENTE_FAC').AsString :=
      DatosCaja.GetTarifaDefault;
    DatosCaja.cdsCabecera.FieldByName(
      'ESIMP_INCL_TARIFA_CLIENTE_FAC').AsString := 'S';
    lblTarifa.Caption :=
      DatosCaja.cdsCabecera.FieldByName('TARIFA_ARTICULO_CLIENTE_FAC').AsString;
    Error := False;
  end
  else
  begin
    if FRepositorioConsultas.ObtenerCliente(
         sCodigo,
         Cliente) then
    begin
      DatosCaja.cdsCabecera.Edit;
      DatosCaja.cdsCabecera.FieldByName(
        'CODIGO_CLI_FAC').AsString :=
        Cliente.Codigo;
      sNomCliente := Cliente.RazonSocial;
      DatosCaja.cdsCabecera.FieldByName(
        'RAZON_SOCIAL_CLIENTE_FAC').AsString :=
        Cliente.RazonSocial;
      DatosCaja.cdsCabecera.FieldByName(
        'NIF_CLIENTE_FAC').AsString :=
        Cliente.Nif;
      DatosCaja.cdsCabecera.FieldByName(
        'MOVIL_CLIENTE_FAC').AsString :=
        Cliente.Movil;
      DatosCaja.cdsCabecera.FieldByName(
        'EMAIL_CLIENTE_FAC').AsString :=
        Cliente.Email;
      DatosCaja.cdsCabecera.FieldByName(
        'DIRECCION1_CLIENTE_FAC').AsString :=
        Cliente.Direccion1;
      DatosCaja.cdsCabecera.FieldByName(
        'DIRECCION2_CLIENTE_FAC').AsString :=
        Cliente.Direccion2;
      DatosCaja.cdsCabecera.FieldByName(
        'POBLACION_CLIENTE_FAC').AsString :=
        Cliente.Poblacion;
      DatosCaja.cdsCabecera.FieldByName(
        'PROVINCIA_CLIENTE_FAC').AsString :=
        Cliente.Provincia;
      DatosCaja.cdsCabecera.FieldByName(
        'CODIGO_POSTAL_CLIENTE_FAC').AsString :=
        Cliente.CodigoPostal;
      DatosCaja.cdsCabecera.FieldByName(
        'CODIGO_PAI_CLIENTE_FAC').AsString :=
        Cliente.CodigoPais;
      DatosCaja.cdsCabecera.FieldByName(
        'NOMBRE_PAI_CLIENTE_FAC').AsString :=
        Cliente.NombrePais;
      DatosCaja.cdsCabecera.FieldByName(
        'CODIGO_OFICINA_CONTABLE_FAC').AsString :=
        Cliente.CodigoOficinaContable;
      DatosCaja.cdsCabecera.FieldByName(
        'CODIGO_ORGANO_GESTOR_FAC').AsString :=
        Cliente.CodigoOrganoGestor;
      DatosCaja.cdsCabecera.FieldByName(
        'CODIGO_UNIDAD_TRAMITADORA_FAC').AsString :=
        Cliente.CodigoUnidadTramitadora;
      DatosCaja.cdsCabecera.FieldByName(
        'ESIVA_RECARGO_CLIENTE_FAC').AsString :=
        Cliente.EsIvaRecargo;
      DatosCaja.cdsCabecera.FieldByName(
        'ESIVA_EXENTO_CLIENTE_FAC').AsString :=
        Cliente.EsIvaExento;
      DatosCaja.cdsCabecera.FieldByName(
        'ESREGIMENESPECIALAGRICOLA_CLIENTE_FAC').AsString :=
        Cliente.EsRegimenEspecialAgricola;
      DatosCaja.cdsCabecera.FieldByName(
        'ESRETENCIONES_CLIENTE_FAC').AsString :=
        Cliente.EsRetenciones;
      DatosCaja.cdsCabecera.FieldByName(
        'ESINTRACOMUNITARIO_CLIENTE_FAC').AsString :=
        Cliente.EsIntracomunitario;
      if Trim(Cliente.CodigoFormaPago) <> '' then
      begin
        DatosCaja.cdsCabecera.FieldByName(
          'FORMA_PAGO_FAC').AsString :=
          Cliente.CodigoFormaPago;
      end;
      DatosCaja.cdsCabecera.FieldByName(
        'TARIFA_ARTICULO_CLIENTE_FAC').AsString :=
        Cliente.TarifaArticulo;
      lblTarifa.Caption :=
        Cliente.TarifaArticulo;
      // Si es un cliente con depósitos, los cargamos.
      if SameText(Cliente.EsPermiteDeuda, 'S') then
      begin
        tvLineasOpe.BeginUpdate;
        FActualizandoDepositos := True;
        try
          if ParametrosCaja.GetBool(
               'vgerAutoLoadDepositos',
               False) then
          begin
            DatosCaja.CargarDepositosCliente(
              sCodigo);
          end;
        finally
          tvLineasOpe.EndUpdate;
          FActualizandoDepositos := False;
        end;
      end;
    end;
    if sNomCliente = '' then
    begin
      Error := True;
      ErrorText := SErrorCodigoClienteCajaNoExiste;
    end
    else
    begin
      Error := False;
      lblNombreCliente.Caption := sNomCliente;
      ErrorText := '';
    end;
  end;
  // =======================================================================
  // 3. PROTECCIÓN CONTRA DATASET VACÍO Y RECÁLCULO FINAL
  // =======================================================================
  if DatosCaja.cdsLineas.Active then
  begin
    tvLineasOpe.DataController.UpdateItems(False);

    // 2º Ponemos el foco en la línea nueva
    AsegurarLineaNueva;

    // 3º Como paso final absoluto, pisamos la etiqueta leyendo la memoria
    // contable
    Totales := TFacturaTotales.Create(ConexionPrincipal,DatosCaja.cdsCabecera,
                                      DatosCaja.cdsLineas);
    try
      Totales.ProcesarFacturaCompleta;
      ActualizarLabelTotal(nil, Totales.Totales.TotalLiquido);
    finally
      FreeAndNil(Totales);
    end;
  end;
  finally
    FValidandoCliente := False;
  end;
end;

procedure TfrmMtoOpeCaja.AsegurarLineaNueva;
begin
  if Assigned(DatosCaja) and DatosCaja.cdsLineas.Active then
  begin
    // 1. Si no hay líneas en absoluto, insertamos una.
    if DatosCaja.cdsLineas.IsEmpty then
    begin
      DatosCaja.cdsLineas.Append;
    end
    // 2. Si ya hay líneas, verificamos que no estemos YA insertando una nueva
    else if not (DatosCaja.cdsLineas.State = dsInsert) then
    begin
      // Solo añadimos si la línea actual tiene un código de artículo.
      // Así evitamos crear líneas en blanco repetidas si hacen varios clics.
      if Trim(DatosCaja.cdsLineas.FieldByName(
        'CODIGO_ART_FACLIN').AsString) <> '' then
      begin
        DatosCaja.cdsLineas.Append;
      end;
    end;
    // 3. Forzamos el foco visual a la celda del Artículo, lista para escanear
    if cxgrdLineasOpe.CanFocus then
      cxgrdLineasOpe.SetFocus;
    tvLineasOpe.Controller.FocusedColumn := tvArticulo;
    SolicitarFocoArticuloLineaNueva;
  end;
end;

procedure TfrmMtoOpeCaja.btnCodigoEmpleadoExit(Sender: TObject);
begin
  if Sender is TcxCustomEdit then
    TcxCustomEdit(Sender).ValidateEdit(True);
end;

procedure TfrmMtoOpeCaja.BuscarClientes;
var
  formulario: TfrmMtoSearch;
  Consulta: IResultadoConsultaCaja;
begin
  Consulta := FRepositorioConsultas.ConsultarClientes;
  formulario := TfrmMtoSearch.Create(nil);
  try
    formulario.Name := 'frmMtoCliSearch';
    formulario.Caption := 'Búsqueda de Clientes';
    formulario.dsTablaG.DataSet := Consulta.DataSet;
    formulario.ProcesarPerfiles;
    formulario.ShowModal;
    if formulario.sFicha = 'S' then
    begin
      btnCodigoCliente.Text :=
        Consulta.DataSet.FieldByName('Código').AsString;
      if btnCodigoCliente.ValidateEdit(True) then
      begin
        cxgrdLineasOpe.SetFocus;
      end;
    end;
  finally
    FreeAndNil(formulario);
  end;
end;

procedure TfrmMtoOpeCaja.btnCodigoEmpleadoPropertiesButtonClick(Sender: TObject;
  AButtonIndex: Integer);
begin
  BuscarEmpleados;
end;

procedure TfrmMtoOpeCaja.btnCodigoClientePropertiesButtonClick(Sender: TObject;
  AButtonIndex: Integer);
begin
  BuscarClientes;
end;

procedure TfrmMtoOpeCaja.btnCodigoEmpleadoPropertiesValidate(Sender: TObject;
  var DisplayValue: Variant; var ErrorText: TCaption; var Error: Boolean);
var
  sNomEmpleado: string;
  sCodigo: string;
  Empleado: TEmpleadoCaja;
  Encontrado: Boolean;
begin
  // Durante un escaneo no validamos el empleado (mismo motivo que en cliente).
  if FProcesandoLecturaScanner then
  begin
    Error := False;
  end;
  if not FProcesandoLecturaScanner then
  begin
    sCodigo := VarToStr(DisplayValue);
    Encontrado :=
      (Trim(sCodigo) <> '') and
      DatosCaja.BuscarYMostrarNombre(
        'EMPLEADOS',
        sCodigo,
        sNomEmpleado);
    if Encontrado then
    begin
      Empleado.Codigo := sCodigo;
      Empleado.Nombre := sNomEmpleado;
    end;
    if not Encontrado then
    begin
      Encontrado :=
        FRepositorioConsultas.BuscarEmpleado(
          sCodigo,
          Empleado);
    end;
    if Encontrado then
    begin
      DisplayValue := Empleado.Codigo;
      lblNombreEmpleado.Caption := Empleado.Nombre;
      DatosCaja.cdsCabecera.Edit;
      DatosCaja.cdsCabecera.FieldByName(
        'CODIGO_CAJERO_FAC').AsString :=
        Empleado.Codigo;
      Error := False;
      ErrorText := '';
    end
    else
    begin
      Error := True;
      ErrorText := SErrorEmpleadoCajaNoEncontrado;
      lblNombreEmpleado.Caption := '';
    end;
  end;
//  tvLineasOpe.ApplyBestFit(nil, True, False);
end;

function TfrmMtoOpeCaja.HayLineasConDeposito: Boolean;
var
  Bkm: TBookmark;
  VieneDeDep: string;
begin
  Result := False;
  DatosCaja.cdsLineas.DisableControls;
  Bkm := DatosCaja.cdsLineas.GetBookmark;
  try
    DatosCaja.cdsLineas.First;
    while not DatosCaja.cdsLineas.Eof do
    begin
      VieneDeDep :=
        DatosCaja.cdsLineas.FieldByName('VIENE_DE_DEPOSITO').AsString;
      if (VieneDeDep = 'S') or (VieneDeDep = 'A') then
      begin
        Result := True;
        Break;
      end;
      DatosCaja.cdsLineas.Next;
    end;
  finally
    if DatosCaja.cdsLineas.BookmarkValid(Bkm) then
      DatosCaja.cdsLineas.GotoBookmark(Bkm);
    DatosCaja.cdsLineas.FreeBookmark(Bkm);
    DatosCaja.cdsLineas.EnableControls;
  end;
end;

procedure TfrmMtoOpeCaja.ProcesarResultadoCierre(
  const AResultado: TResultadoCierreVenta;
  AEnviarEmail: Boolean;
  const AEmailEnvio: string);
var
  sMensajeCorreo: string;
begin
  if FNumeroRectifica <> '' then
  begin
    if FTipoRectificativa = trcSustitutiva then
      RefrescarConsultasOperacionesCaja;
    FSerieRectifica := '';
    FNumeroRectifica := '';
    FTipoRectificativa := trcNinguna;
    FTratamientoMovRectificativa := tmrMantenerOriginales;
    if FCaptionPrevio <> '' then
      Caption := FCaptionPrevio;
  end;
  if AResultado.CodigoValeGenerado <> '' then
  begin
    ShowMessage(Format(
      SInfoValeCajaEntregar,
      [AResultado.CodigoValeGenerado]));
  end;
  if AEnviarEmail then
  begin
    Screen.Cursor := crHourGlass;
    try
      if EnviarDocumentacionOperacion(
        ParametrosApp,
        ConexionPrincipal,
        FCodigoEmpresa,
        FCodigoAlmacen,
        FCodigoCaja,
        AResultado.NumeroGenerado,
        AEmailEnvio,
        sMensajeCorreo) then
      begin
        ShowMessage(sMensajeCorreo);
      end
      else
      begin
        ShowMessage(Format(
          SErrorCorreoOperacionCajaNoEnviado,
          [sMensajeCorreo]));
      end;
    finally
      Screen.Cursor := crDefault;
    end;
  end;
  PrepararValores(
    FCodigoEmpresa,
    FCodigoAlmacen,
    FCodigoCaja,
    FFecha);
end;

procedure TfrmMtoOpeCaja.btnF12Click(Sender: TObject);
var
  frmFaseCobro: TfrmMtoCajaFaseCobro;
  ObjTotales: TFacturaTotales;
  Solicitud: TSolicitudCierreVenta;
  Resultado: TResultadoCierreVenta;
  sSerieDocumento: string;
  sTipoFactura: string;
  dtFechaFactura: TDateTime;
begin
  if DatosCaja.cdsLineas.State in [dsInsert, dsEdit] then
  begin
    if DatosCaja.cdsLineas.State = dsInsert then
    begin
      if Trim(DatosCaja.cdsLineas.FieldByName(
        'CODIGO_ART_FACLIN').AsString) = '' then
      begin
        DatosCaja.cdsLineas.Cancel;
      end
      else
      begin
        DatosCaja.cdsLineas.Post;
      end;
    end
    else
    begin
      DatosCaja.cdsLineas.Post;
    end;
  end;
  ActualizarRelojCaja;
  SincronizarFechaCajaCabecera;
  frmFaseCobro := nil;
  ObjTotales := nil;
  try
    ObjTotales := TFacturaTotales.Create(
      ConexionPrincipal,
      DatosCaja.cdsCabecera,
      DatosCaja.cdsLineas);
    ObjTotales.ProcesarFacturaCompleta;
    frmFaseCobro := TfrmMtoCajaFaseCobro.Create(Self);
    frmFaseCobro.CargarDatosDesdeFactura(ObjTotales);
    frmFaseCobro.FHayLineasDeposito := HayLineasConDeposito;
    frmFaseCobro.FCodigoEmpresa := FCodigoEmpresa;
    frmFaseCobro.FCodigoAlmacen := FCodigoAlmacen;
    frmFaseCobro.FCodigoCaja := FCodigoCaja;
    frmFaseCobro.FFecha := FFecha;
    frmFaseCobro.FCodigoCliente :=
           DatosCaja.cdsCabecera.FieldByName('CODIGO_CLI_FAC').AsString;
    frmFaseCobro.FEmailCliente :=
           DatosCaja.cdsCabecera.FieldByName('EMAIL_CLIENTE_FAC').AsString;
    frmFaseCobro.FNifCliente :=
           DatosCaja.cdsCabecera.FieldByName('NIF_CLIENTE_FAC').AsString;
    frmFaseCobro.FCodigoPaisCliente :=
           DatosCaja.cdsCabecera.FieldByName(
             'CODIGO_PAI_CLIENTE_FAC').AsString;
    frmFaseCobro.FNombrePaisCliente :=
           DatosCaja.cdsCabecera.FieldByName(
             'NOMBRE_PAI_CLIENTE_FAC').AsString;
    if FNumeroRectifica <> '' then
      frmFaseCobro.FRectificaA := FSerieRectifica + '\' + FNumeroRectifica;
    if frmFaseCobro.ShowModal = mrOk then
    begin
      if frmFaseCobro.DatosCobro.ImporteDescuentoGlobal > 0 then
      begin
        AplicarRepartoDescuentoDataSet(
          FRepartidorDescuento,
          DatosCaja.cdsLineas,
          frmFaseCobro.DatosCobro.ImporteDescuentoGlobal);
        ObjTotales.ProcesarFacturaCompleta;
      end;
      sSerieDocumento := frmFaseCobro.cbbSERIE_FAC.Text;
      sTipoFactura := 'SIMPLIFICADA';
      dtFechaFactura := 0;
      if frmFaseCobro.TipoImpresion = tiFactura then
      begin
        sSerieDocumento := frmFaseCobro.FSerieFactura;
        sTipoFactura := 'NORMAL';
        dtFechaFactura := frmFaseCobro.FFechaFactura;
      end;
      if (frmFaseCobro.TipoImpresion <> tiFactura) and
         (FNumeroRectifica <> '') then
      begin
        sTipoFactura := 'RECTIFICATIVA';
      end;
      ActualizarRelojCaja;
      SincronizarFechaCajaCabecera;
      frmFaseCobro.FFecha := FFecha;
      Solicitud := Default(TSolicitudCierreVenta);
      Solicitud.TipoImpresion := frmFaseCobro.TipoImpresion;
      Solicitud.Grabacion.CodigoEmpresa := FCodigoEmpresa;
      Solicitud.Grabacion.CodigoAlmacen := FCodigoAlmacen;
      Solicitud.Grabacion.CodigoCaja := FCodigoCaja;
      Solicitud.Grabacion.SerieDocumento := sSerieDocumento;
      Solicitud.Grabacion.TipoFactura := sTipoFactura;
      Solicitud.Grabacion.FechaFactura := dtFechaFactura;
      Solicitud.Grabacion.FechaOperacion := FFecha;
      Solicitud.Grabacion.NumeroManual := frmFaseCobro.FNumeroManual;
      Solicitud.Grabacion.TipoRectificativa := FTipoRectificativa;
      Solicitud.Grabacion.SerieRectificada := FSerieRectifica;
      Solicitud.Grabacion.NumeroRectificado := FNumeroRectifica;
      Solicitud.Grabacion.TratamientoMovimientos :=
        FTratamientoMovRectificativa;
      Solicitud.Grabacion.DatosCobro := frmFaseCobro.DatosCobro;
      Resultado := FServicioCierreVenta.Ejecutar(Solicitud);
      if Resultado.Grabada then
      begin
        ProcesarResultadoCierre(
          Resultado,
          frmFaseCobro.EnviarEmail,
          frmFaseCobro.EmailEnvio);
      end;
    end;
  finally
    if Assigned(frmFaseCobro) then
      FreeAndNil(frmFaseCobro);
    FreeAndNil(ObjTotales);
  end;
end;

function TfrmMtoOpeCaja.OperacionVacia: Boolean;
begin
  Result := True;
  if Assigned(DatosCaja) and DatosCaja.cdsLineas.Active then
  begin
    if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
      DatosCaja.cdsLineas.Cancel;
    Result := DatosCaja.cdsLineas.IsEmpty;
  end;
end;

function TfrmMtoOpeCaja.FormularioCaja: TCustomForm;
begin
  Result := Self;
end;

procedure TfrmMtoOpeCaja.CargarRectificacion(
  const ASerie, ANumero: string;
  ATipoRectificativa: TTipoRectificativaCaja;
  ATratamientoMovimientos:
    TTratamientoMovimientosRectificativa);
var
  Resultado: TResultadoRectificacionCaja;
begin
  Resultado := FServicioRectificacion.Cargar(
    ASerie,
    ANumero,
    ATipoRectificativa,
    ATratamientoMovimientos,
    DatosCaja.cdsCabecera,
    DatosCaja.cdsLineas);
  FSerieRectifica := Resultado.Serie;
  FNumeroRectifica := Resultado.Numero;
  FTipoRectificativa := Resultado.Tipo;
  FTratamientoMovRectificativa :=
    Resultado.TratamientoMovimientos;
  if FCaptionPrevio = '' then
  begin
    FCaptionPrevio := Caption;
  end;
  Caption :=
    FCaptionPrevio +
    '  —  RECTIFICATIVA ' +
    Resultado.DescripcionTipo +
    ' de ' +
    Resultado.Serie +
    '\' +
    Resultado.Numero;
  lblTipoRectificativa.Caption := 'RECTIFICATIVA' + sLineBreak +
    Resultado.DescripcionTipo;
  lblTipoRectificativa.Visible := True;
end;

procedure TfrmMtoOpeCaja.CargarDepositosF2;
var
  sCodigoCliente: string;
  Totales: TFacturaTotales;
begin
  sCodigoCliente :=
    DatosCaja.cdsCabecera.FieldByName('CODIGO_CLI_FAC').AsString;
  if (Trim(sCodigoCliente) = '') or (Trim(sCodigoCliente) = '0') then
  begin
    ShowMessage(SErrorClienteDepositosCajaNoSeleccionado);
    Exit;
  end;

  // 1. Matar la edición activa limpiamente (Evita el error de
  // Artículo no encontrado en la línea en blanco)
  if (tvLineasOpe.Controller.EditingController <> nil) and
     tvLineasOpe.Controller.EditingController.IsEditing then
  begin
    tvLineasOpe.Controller.EditingController.HideEdit(False);
  end;
  // 2. Cancelar línea a medias si la hubiera
  if DatosCaja.cdsLineas.State in [dsInsert, dsEdit] then
    DatosCaja.cdsLineas.Cancel;
  // 3. Limpieza y carga de depósitos de forma silenciosa
  DatosCaja.cdsLineas.DisableControls;
  tvLineasOpe.BeginUpdate;
  FActualizandoDepositos := True;
  try
    DatosCaja.cdsLineas.First;
    while not DatosCaja.cdsLineas.Eof do
    begin
      if (DatosCaja.cdsLineas.FieldByName('VIENE_DE_DEPOSITO').AsString = 'S')
                                                                              or
         (DatosCaja.cdsLineas.FieldByName(
                                       'VIENE_DE_DEPOSITO').AsString = 'A') then
        DatosCaja.cdsLineas.Delete
      else
        DatosCaja.cdsLineas.Next;
    end;
    DatosCaja.CargarDepositosCliente(sCodigoCliente);
  finally
    DatosCaja.cdsLineas.EnableControls;
    tvLineasOpe.EndUpdate;
    FActualizandoDepositos := False;
  end;
  tvLineasOpe.DataController.UpdateItems(False);
  // Modo cuenta de cliente (F2): rellenamos Color/Talla de cada prenda y
  // ajustamos las columnas (fecha de la operacion visible; % y Menos ocultas)
  // antes de añadir la linea en blanco de escaneo.
  PoblarAtributosLineasDeposito;
  tvFechaOperacion.Visible := True;
  MostrarColumnasCuentaCliente(True);
  // 5. Preparamos la línea en blanco para seguir escaneando (ahora ya no rompe
  // la caché)
  AsegurarLineaNueva;
  // 6. Calculamos el total SIEMPRE AL FINAL, forzando la lectura de memoria
  // interna
  Totales := TFacturaTotales.Create(
    ConexionPrincipal,
    DatosCaja.cdsCabecera,
    DatosCaja.cdsLineas);
  try
    Totales.ProcesarFacturaCompleta;
    ActualizarLabelTotal(nil, Totales.Totales.TotalLiquido);
  finally
    FreeAndNil(Totales);
  end;
end;

procedure TfrmMtoOpeCaja.btnF2Click(Sender: TObject);
begin
  CargarDepositosF2;
end;

procedure TfrmMtoOpeCaja.btnF5Click(Sender: TObject);
var
  i: Integer;
  NextIndex: Integer;
  TargetForm: TfrmMtoOpeCaja;
  Found: Boolean;
  const MAX_OPERACIONES = 5;
begin
  NextIndex := Self.Tag + 1;
  if NextIndex > MAX_OPERACIONES then
    NextIndex := 1;
  Found := False;
  TargetForm := nil;
  for i := 0 to Screen.FormCount - 1 do
  begin
    if Screen.Forms[i] is TfrmMtoOpeCaja then
    begin
      if Screen.Forms[i].Tag = NextIndex then
      begin
        TargetForm := TfrmMtoOpeCaja(Screen.Forms[i]);
        Found := True;
        Break;
      end;
    end;
  end;
  if Found then
  begin
    TargetForm.Show;
    TargetForm.BringToFront;
    if TargetForm.WindowState = wsMinimized then
      TargetForm.WindowState := wsNormal;
  end
  else
  begin
    TargetForm := TfrmMtoOpeCaja.Create(Application, Permisos);
    TargetForm.PopupParent := Self.PopupParent;
    TargetForm.Tag := NextIndex;
    TargetForm.Caption := Format('Operación %d - (Caja Real %s)',
                                 [NextIndex, Self.FCodigoCaja]);
    TargetForm.PrepararValores(Self.FCodigoEmpresa,
                               Self.FCodigoAlmacen,
                               Self.FCodigoCaja,
                               Self.FFecha);
    TargetForm.Show;
  end;
  Self.Hide;
end;

procedure TfrmMtoOpeCaja.BuscarEmpleados;
var
  formulario: TfrmMtoSearch;
  Consulta: IResultadoConsultaCaja;
begin
  Consulta := FRepositorioConsultas.ConsultarEmpleados;
  formulario := TfrmMtoSearch.Create(nil);
  try
    formulario.Name := 'frmMtoEmpCajSearch';
    formulario.Caption := 'Búsqueda de Empleados en Caja';
    formulario.dsTablaG.DataSet := Consulta.DataSet;
    formulario.ProcesarPerfiles;
    formulario.ShowModal;
    if formulario.sFicha = 'S' then
    begin
      btnCodigoEmpleado.Text :=
        Consulta.DataSet.Fields[0].AsString;
      if btnCodigoEmpleado.ValidateEdit(True) then
      begin
        btnCodigoCliente.SetFocus;
      end;
    end;
  finally
    FreeAndNil(formulario);
  end;
end;

procedure TfrmMtoOpeCaja.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Action := caFree;
end;

procedure TfrmMtoOpeCaja.FormDestroy(Sender: TObject);
begin
  dsStock.DataSet := nil;
  FConsultaStock := nil;
  FServicioRectificacion := nil;
  FRepositorioConsultas := nil;
  FIncidenciasSql := nil;
  FServicioCierreVenta := nil;
  FImpresorVenta := nil;
  FRepartidorDescuento := nil;
  FPoliticaStockVenta := nil;
  FreeAndNil(FLector);
  FreeAndNil(FBmpSwatchBoton);
end;

// Carga en imgFotoStock la foto a 300 px del articulo / SKU de la
// linea activa. Lo invoca DsLineasDataChange al cambiar de registro.
procedure TfrmMtoOpeCaja.RefrescarFotoStock;
var
  sArt : string;
  sSku : string;
  info : TFotoInfo;
  sRuta: string;
  png  : TPngImage;
begin
  if Assigned(imgFotoStock) and Assigned(dsLineas) then
  begin
    LeerArtSkuDeDataSet(dsLineas.DataSet, sArt, sSku);
    // La linea nueva conserva la foto del ultimo articulo introducido.
    if sArt <> '' then
    begin
      imgFotoStock.Picture.Assign(nil);
      info  := oFotos.Resolver(sArt, sSku);
      sRuta := oFotos.RutaFoto(info, frPx300);
      if sRuta <> '' then
      begin
        png := TPngImage.Create;
        try
          png.LoadFromFile(sRuta);
          imgFotoStock.Picture.Assign(png);
        finally
          FreeAndNil(png);
        end;
      end;
    end;
  end;
end;

procedure TfrmMtoOpeCaja.DsLineasDataChange(Sender: TObject; Field: TField);
begin
  // Solo refrescamos cuando cambia el registro activo (Field = nil),// no en cada cambio de columna.
  if Field = nil then
  begin
    RefrescarFotoStock;
    if Assigned(DatosCaja) and DatosCaja.cdsLineas.Active and
       (DatosCaja.cdsLineas.State = dsInsert) and
       (Trim(DatosCaja.cdsLineas.FieldByName(
         'CODIGO_ART_FACLIN').AsString) = '') then
      SolicitarFocoArticuloLineaNueva;
  end;
end;

procedure TfrmMtoOpeCaja.SolicitarFocoArticuloLineaNueva;
begin
  if (not FEnfoqueArticuloPendiente) and
     (not (csDestroying in ComponentState)) then
  begin
    FEnfoqueArticuloPendiente := True;
    PostMessage(Handle, WM_ENFOCAR_ARTICULO_CAJA, 0, 0);
  end;
end;

procedure TfrmMtoOpeCaja.WMEnfocarArticuloCaja(var Msg: TMessage);
begin
  FEnfoqueArticuloPendiente := False;
  if Assigned(DatosCaja) and DatosCaja.cdsLineas.Active and
     (DatosCaja.cdsLineas.State = dsInsert) and
     (Trim(DatosCaja.cdsLineas.FieldByName(
       'CODIGO_ART_FACLIN').AsString) = '') then
  begin
    if cxgrdLineasOpe.CanFocus then
      cxgrdLineasOpe.SetFocus;
    if tvLineasOpe.Controller.EditingController.IsEditing and
       (tvLineasOpe.Controller.EditingItem <> tvArticulo) then
      tvLineasOpe.Controller.EditingController.HideEdit(False);
    tvLineasOpe.Controller.FocusedColumn := tvArticulo;
    if not tvLineasOpe.Controller.EditingController.IsEditing then
      tvLineasOpe.Controller.EditingController.ShowEdit;
  end;
end;

procedure TfrmMtoOpeCaja.FormCreate(Sender: TObject);
var
  bCatalogoSqlActivo: Boolean;
  oCatalogoSql: ICatalogoSql;
  oServicios: TServiciosOperacionCaja;
begin
  inherited;
  // Detector del lector de codigo de barras (modo restaurar, con anti-eco para
  // la rejilla editable). Los parametros salen de la configuracion de caja.
  FLector := TLectorScanner.Create;
  FLector.Activo := ParametrosCaja.GetBool('vgerScanVelActivo', True);
  FLector.UmbralMs := ParametrosCaja.GetInt('vgerScanVelMs', 40);
  FLector.LongitudMinima := ParametrosCaja.GetInt('vgerScanMinLong', 4);
  // En caja, la lectura se procesa como artículo desde cualquier columna.
  FLector.OmitirEnRejilla := False;
  FLector.OnCodigoLeido := LectorCodigoLeido;
  FLector.OnLecturaIniciada := LectorLecturaIniciada;
  FLector.OnRejillaEditando := LectorRejillaEditando;
  FLector.OnEsControlRejilla := LectorEsControlRejilla;
  FBmpSwatchBoton := TBitmap.Create;
  // FswArtAPopup es un record (TStopwatch) — se inicializa a cero por
  // defecto, IsRunning sera False hasta que se arranque en
  // tvArticuloPropertiesValidate.
  DatosCaja := TdmCajaOpe.Create(Self, ConexionPrincipal, ParametrosApp,
    ParametrosCaja);
  bCatalogoSqlActivo := False;
  if Assigned(PerfilesUsuario) then
    bCatalogoSqlActivo := SameText(
      PerfilesUsuario.ObtenerValorPerfil(
        Self.Name,
        'oGetSQLFromDB',
        'False'),
      'True');
  CrearCatalogoSqlAplicacion(
    PerfilesUsuario,
    bCatalogoSqlActivo,
    oCatalogoSql,
    FIncidenciasSql);
  oServicios := CrearServiciosOperacionCaja(
    Self,
    ParametrosApp,
    ConexionPrincipal,
    ParametrosCaja,
    Permisos,
    ContextoSesion,
    DatosCaja,
    oCatalogoSql,
    FIncidenciasSql);
  FRepositorioConsultas :=
    oServicios.RepositorioConsultas;
  FServicioRectificacion :=
    oServicios.ServicioRectificacion;
  FPoliticaStockVenta :=
    oServicios.PoliticaStock;
  FRepartidorDescuento :=
    oServicios.RepartidorDescuento;
  FImpresorVenta :=
    oServicios.Impresor;
  FServicioCierreVenta :=
    oServicios.ServicioCierre;
  dsLineas.DataSet := DatosCaja.cdsLineas;
  dsStock.DataSet := nil;
  dsLineas.OnDataChange := DsLineasDataChange;
  ConstruirColumnasDinamicas;
  // Cantidad con decimales segun la unidad de cada linea (telas por metros...).
  VincularCantidadGrid(tvUds, tvTipoCantidad);
  DatosCaja.OnUpdateTotal := ActualizarLabelTotal;
  DatosCaja.OnRellenarArticulo  := RellenarDatosArticuloEnDataset;
  DatosCaja.OnRellenarAtributos := RellenarAtributosDesdeSku;
  DatosCaja.OnRecalcularLineas := RecalcularLineasDesdeDM;
  lblFechaCaja.OnDblClick := lblFechaCajaDblClick;
  tvEmpleado.Visible :=
    ParametrosCaja.GetBool('vgerShowEmpleadoLinea', True);
  var PermiteDescuentos :=
    ParametrosCaja.GetBool('vgerDescuentos', True);
  tvDescuento.Options.Editing := PermiteDescuentos;
  tvDescuentoMenos.Options.Editing := PermiteDescuentos;
  // El Total tambien es editable y, al bajarlo, aplica un descuento
  // implicito (GridRecalc recalcula % y Menos a partir del total). Si no
  // se permiten descuentos hay que bloquearlo igual que % y Menos; de lo
  // contrario seria una via para saltarse el control editando el total.
  tvTotal.Options.Editing := PermiteDescuentos;
  // El Precio unitario es la otra via: bajarlo reduce el importe (un
  // descuento de facto). Con descuentos denegados, el precio de tarifa
  // queda intocable.
  tvPrecioUni.Options.Editing := PermiteDescuentos;
  with dbtvBusq.DataController do
  begin
    DataModeController.GridMode := True;
    DataModeController.SyncMode := False;
    Filter.AutoDataSetFilter := False;
    Options := Options - [dcoImmediatePost, dcoGroupsAlwaysExpanded];
  end;
  with dbtvBusq.OptionsBehavior do
  begin
    IncSearch := False;
    IncSearchItem := nil;
  end;
  repSoloTexto.Properties.OnValidate := tvArticuloPropertiesValidate;
  repComboBox.Properties.OnCloseUp   := tvArticuloPropertiesCloseUp;
end;

procedure TfrmMtoOpeCaja.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
  // El lector resetea su estado, captura si la rejilla editaba y cierra la
  // lectura por velocidad (consume el VK_RETURN si era una rafaga del lector).
  FLector.KeyDown(Key, Shift);
  if (Key = VK_F5) then
    btnF5.Click;
  // Ctrl+F12 -> resetear layout
  if (Key = VK_F12) and (ssCtrl in Shift) and not (ssAlt in Shift) then
  begin
    ResetearLayout(Self.Name, PerfilesUsuario);
    Key := 0;
  end;
end;

// Ctrl+U: consulta de stock del articulo de la linea que se esta metiendo.
// Lee el (articulo, sku) de la linea enfocada con el mismo helper que usan
// los mantenimientos via TfrmMtoGen.ResolverArtSkuActivo (CODIGO_ART_FACLIN
// y CODIGO_UNIDAD_FACLIN estan entre sus alias). Si la linea aun no tiene
// articulo resuelto, abre la consulta vacia con su buscador.
procedure TfrmMtoOpeCaja.ResolverArtSkuStock(out ACodArt, ACodSku: string);
begin
  // Articulo/sku de la linea de caja en foco (vacio si aun no hay).
  ACodArt := '';
  ACodSku := '';
  if Assigned(DatosCaja) and Assigned(DatosCaja.cdsLineas) then
    inLibFotos.LeerArtSkuDeDataSet(DatosCaja.cdsLineas, ACodArt, ACodSku);
end;

procedure TfrmMtoOpeCaja.actConsultaStockExecute(Sender: TObject);
var
  sArt: string;
  sSku: string;
begin
  ResolverArtSkuStock(sArt, sSku);
  inMtoStockConsulta.MostrarStockConsulta(sArt,
    sSku);
end;

procedure TfrmMtoOpeCaja.FormShow(Sender: TObject);
begin
  RestaurarLayoutCaja;
  ActualizarFoco;
end;

// ForzarDespliegue queda como stub porque sigue en la declaracion privada;
// el OnEnter de TcxButtonEdit ahora apunta a AbrirPopupAvEnEntrada que
// abre el popup SeleccionarAvConPaleta directamente (mismo patron que
// inMtoInventarios).
//procedure TfrmMtoOpeCaja.ForzarDespliegue(Sender: TObject);
//begin
//  // Sin uso: el flujo de seleccion de atributos pasa por
//  // AbrirPopupAvEnEntrada + tvLineasOpeAvButtonClick.
//end;

procedure TfrmMtoOpeCaja.AbrirPopupAvEnEntrada(Sender: TObject);
var
  BE: TcxCustomEdit;
begin
  // OnEnter single-shot: cuando el usuario entra en una celda Color/Talla
  // vacia, disparamos el popup automaticamente (sustituye a la antigua
  // ForzarDespliegue que desplegaba el TcxComboBox).
  //
  // No abrimos el popup en linea: cuando WMAvanzarAtribCaja salta de Color
  // a Talla, ShowEdit/InitEdit/OnEnter encadenan en el mismo callstack y
  // el TcxButtonEdit recien creado para Talla aun no ha terminado de
  // parentar; ClientToScreen dentro de tvLineasOpeAvButtonClick pediria
  // Handle -> Parent -> EInvalidOperation. PostMessage hace que el handler
  // retorne y cxGrid acabe la colocacion antes de abrir el popup.
  if not (Sender is TcxCustomEdit) then Exit;
  BE := TcxCustomEdit(Sender);
  BE.OnEnter := nil;
  PostMessage(Self.Handle, WM_ABRIR_POPUP_AV, 0, 0);
end;

procedure TfrmMtoOpeCaja.WMAbrirPopupAv(var Msg: TMessage);
var
  CurrentEdit: TcxCustomEdit;
begin
  // Disparado por AbrirPopupAvEnEntrada via PostMessage. Para entonces
  // cxGrid ya termino de parentar el TcxButtonEdit, asi que podemos
  // llamar al click handler con el editor actual.
  // Si FswArtAPopup esta en marcha, registramos el tiempo total desde
  // tvArticuloPropertiesValidate hasta aqui — es lo que el usuario
  // percibe como "demora entre Enter del codigo y desplegable".
  if FswArtAPopup.IsRunning then
  begin
    FswArtAPopup.Stop;
  end;
  if not tvLineasOpe.Controller.EditingController.IsEditing then Exit;
  CurrentEdit := tvLineasOpe.Controller.EditingController.Edit;
  if (CurrentEdit is TcxButtonEdit)
     and (CurrentEdit.Tag >= 1) and (CurrentEdit.Tag <= 5) then
    tvLineasOpeAvButtonClick(CurrentEdit, 0);
end;

procedure TfrmMtoOpeCaja.CargarAvsValidos(const ACodArt: string;
  AOrden: Integer; var AAvs: TArray<string>);
var
  Lookup : TArticulosAtributosLookup;
  Vals   : TArray<TArticuloAtributoValor>;
  i      : Integer;
begin
  // Devuelve los AV (BLANCO, MALVA, 42, 44, ...) que el articulo tiene
  // referenciados en alguno de sus SKUs para la columna `AOrden`. Mismo
  // metodo que usa inMtoInventarios: ordena por ORDEN_AV para que tallas
  // S/M/L/XL salgan correctamente.
  SetLength(AAvs, 0);
  if Trim(ACodArt) = '' then Exit;
  if (AOrden < 1) or (AOrden > 5) then Exit;
  Lookup := TArticulosAtributosLookup.Create(ConexionPrincipal);
  try
    Vals := Lookup.ObtenerAvsEnSkus(ACodArt, AOrden);
  finally
    FreeAndNil(Lookup);
  end;
  SetLength(AAvs, Length(Vals));
  for i := 0 to High(Vals) do
    AAvs[i] := Vals[i].Valor;
end;

procedure TfrmMtoOpeCaja.RegistrarValorAtributo(AOrden: Integer;
                                                 const AvNuevo: string);
var
  SkuNuevo: string;
  NumAtributosRequeridos, NumSeparadores, i: Integer;
begin
  // Aplica el AV elegido por el usuario en el popup al campo ATTRn_VALOR
  // y recalcula el SKU final (CODIGO_UNIDAD_FACLIN). Si el SKU queda
  // completo, dispara el recalculo de precio. La finalizacion de la linea
  // (validar SKU, consultar stock, avanzar foco) se hace fuera para no
  // mover el foco con el editor todavia activo: ver tvLineasOpeAvButtonClick.
  // Sustituye al antiguo OnAtributoChanged del TcxComboBox.
  if (AOrden < 1) or (AOrden > 5) then Exit;
  if not DatosCaja.cdsLineas.Active then Exit;
  if DatosCaja.cdsLineas.IsEmpty then Exit;
  if DatosCaja.cdsLineas.State = dsBrowse then
    DatosCaja.cdsLineas.Edit;
  if not (DatosCaja.cdsLineas.State in [dsEdit, dsInsert]) then Exit;

  DatosCaja.cdsLineas.FieldByName(
    'ATTR' + IntToStr(AOrden) + '_VALOR').AsString := AvNuevo;

  SkuNuevo := DatosCaja.GenerarSkuFinal(
                DatosCaja.cdsLineas.FieldByName(
                  'CODIGO_ART_FACLIN').AsString);
  if Trim(SkuNuevo) = '' then
    SkuNuevo := DatosCaja.cdsLineas.FieldByName(
                  'CODIGO_ART_FACLIN').AsString;
  DatosCaja.cdsLineas.FieldByName('CODIGO_UNIDAD_FACLIN').AsString := SkuNuevo;

  NumAtributosRequeridos := DatosCaja.cdsLineas.FieldByName(
                              'NUM_ATRIBUTOS_REQ_FACTURA_LINEA').AsInteger;
  NumSeparadores := 0;
  for i := 1 to Length(SkuNuevo) do
    if SkuNuevo[i] = '/' then Inc(NumSeparadores);

  if (NumAtributosRequeridos > 0)
     and (NumSeparadores = NumAtributosRequeridos) then
    RecalcularPrecioDesdeSku(SkuNuevo);
end;

procedure TfrmMtoOpeCaja.FinalizarUltimoAtributo;
var
  SkuNuevo : string;
  EstabaInsertando : Boolean;
begin
  // Logica que antes vivia inline en cxGrid1DBTableView1EditKeyDown cuando
  // se confirmaba el ultimo atributo de la linea. Encapsulada para poder
  // invocarla desde tvLineasOpeAvButtonClick (popup) sin duplicar codigo.
  if FProcesandoAtributo then Exit;
  if not DatosCaja.cdsLineas.Active then Exit;
  if DatosCaja.cdsLineas.IsEmpty then Exit;

  // Defensivo: aseguramos que no queda un inplace editor activo antes de
  // empezar a hacer Cancel/Append. Los broadcasts del data link (sobre
  // todo tras el ShowMessage de "no hay stock") intentarian refrescar el
  // TcxButtonEdit y, si cxGrid ya lo desparento, salta EInvalidOperation.
  // HideEdit(False): no intentamos PostEditValue, los campos ya estan
  // escritos por RegistrarValorAtributo.
  if tvLineasOpe.Controller.EditingController.IsEditing then
    tvLineasOpe.Controller.EditingController.HideEdit(False);

  FProcesandoAtributo := True;
  DatosCaja.cdsLineas.DisableControls;
  try
    EstabaInsertando := (DatosCaja.cdsLineas.State = dsInsert);
    SkuNuevo := DatosCaja.cdsLineas.FieldByName(
                                       'CODIGO_UNIDAD_FACLIN').AsString;

    if EstabaInsertando and ConsolidarSiExiste(SkuNuevo) then
    begin
      if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
        DatosCaja.cdsLineas.Cancel;
      if not DatosCaja.cdsLineas.IsEmpty then
        if DatosCaja.cdsLineas.FieldByName(
                   'CODIGO_UNIDAD_FACLIN').AsString = SkuNuevo then
          DatosCaja.cdsLineas.Delete;
      DatosCaja.cdsLineas.EnableControls;
      DatosCaja.cdsLineas.Append;
      tvLineasOpe.Controller.FocusedColumn := tvArticulo;
      tvLineasOpe.Controller.EditingController.ShowEdit;
      Exit;
    end;

    if not ValidarSkuParaVenta(SkuNuevo) then
    begin
      if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
        DatosCaja.cdsLineas.Cancel;
      if not DatosCaja.cdsLineas.IsEmpty
         and (DatosCaja.cdsLineas.FieldByName(
                      'CODIGO_UNIDAD_FACLIN').AsString = SkuNuevo) then
        DatosCaja.cdsLineas.Delete;
      DatosCaja.cdsLineas.EnableControls;
      //dbtvStock.ClearItems;
      DatosCaja.cdsLineas.Append;
      tvLineasOpe.Controller.FocusedColumn := tvArticulo;
      tvLineasOpe.Controller.EditingController.ShowEdit;
      Exit;
    end;

    ConsultarStock(SkuNuevo);
  finally
    FProcesandoAtributo := False;
    DatosCaja.cdsLineas.EnableControls;
  end;

  if ParametrosCaja.GetBool('vgerMoverLineaIdentif', True) then
  begin
    if DatosCaja.cdsLineas.State in [dsInsert, dsEdit] then
      DatosCaja.cdsLineas.Post;
    DatosCaja.cdsLineas.Append;
    tvLineasOpe.Controller.FocusedColumn := tvArticulo;
  end
  else
    tvLineasOpe.Controller.FocusedColumn := tvDescripcion;

  tvLineasOpe.Controller.EditingController.ShowEdit;
end;

procedure TfrmMtoOpeCaja.tvLineasOpeAvButtonClick(Sender: TObject;
                                                   AButtonIndex: Integer);
var
  Col       : TcxGridColumn;
  Orden     : Integer;
  ArtPadre  : string;
  AvActual  : string;
  NombreAtb : string;
  IdVa      : string;
  AvNuevo   : string;
  Avs       : TArray<string>;
  Mapa      : TDictionary<string, string>;
  EditCtrl  : TWinControl;
  ScrPt     : TPoint;
  WidHint   : Integer;
begin
  // Click en el boton de una columna de atributo (Color, Talla, ...): abre
  // el popup SeleccionarAvConPaleta con cuadraditos de paleta. Mismo flujo
  // que inMtoInventarios.tvLineasSkuPropertiesButtonClick.
  Col := tvLineasOpe.Controller.FocusedColumn;
  if Col = nil then Exit;
  Orden := Col.Tag;
  if (Orden < 1) or (Orden > 5) then Exit;
  if not DatosCaja.cdsLineas.Active then Exit;
  if DatosCaja.cdsLineas.IsEmpty then Exit;

  ArtPadre  := DatosCaja.cdsLineas.FieldByName(
                 'CODIGO_ART_FACLIN').AsString;
  AvActual  := DatosCaja.cdsLineas.FieldByName(
                 'ATTR' + IntToStr(Orden) + '_VALOR').AsString;
  NombreAtb := DatosCaja.cdsLineas.FieldByName(
                 'ATTR' + IntToStr(Orden) + '_NOMBRE').AsString;

  CargarAvsValidos(ArtPadre, Orden, Avs);
  if Length(Avs) = 0 then
  begin
    ShowMessage(SErrorValoresAtributoCajaNoDefinidos);
    Exit;
  end;

  IdVa := '';
  Mapa := ObtenerMapaAtributosGlobal(ConexionPrincipal);
  if Mapa <> nil then
    Mapa.TryGetValue(UpperCase(Trim(NombreAtb)), IdVa);

  // Posicion del popup justo debajo del editor. SeleccionarAvConPaleta
  // acepta (-1, -1) para auto-centrar; lo usamos como fallback. cxGrid
  // mantiene los TcxButtonEdit en un pool y a veces el editor inplace que
  // recibimos en Sender (sea via OnButtonClick, OnEnter via
  // AbrirPopupAvEnEntrada, o F3 via actBuscarEmpleadosExecute) llega sin
  // Parent en la pasada — ClientToScreen pide Handle, Handle pide Parent
  // y salta EInvalidOperation. Comprobamos HasParent y, por si hay carrera
  // entre el check y la llamada, envolvemos en try/except.
  ScrPt.X := -1; ScrPt.Y := -1;
  WidHint := 120;
  if (Sender is TWinControl) and TWinControl(Sender).HasParent then
  begin
    EditCtrl := TWinControl(Sender);
    try
      ScrPt   := EditCtrl.ClientToScreen(Point(0, EditCtrl.Height));
      WidHint := EditCtrl.Width;
    except
      on E: EInvalidOperation do
      begin
        ScrPt.X := -1;
        ScrPt.Y := -1;
        WidHint := 120;
      end;
    end;
  end;

  if not SeleccionarAvConPaleta(ConexionPrincipal,IdVa, Avs, AvActual, AvNuevo,
                                 ScrPt.X, ScrPt.Y, WidHint, ArtPadre) then
    Exit;

  RegistrarValorAtributo(Orden, AvNuevo);

  // Reflejamos el AV nuevo en el editor para que el usuario lo vea sin
  // tener que esperar a que se reabra la celda. Solo si Sender sigue
  // parentado: durante el modal SeleccionarAvConPaleta cxGrid puede
  // haberle quitado el Parent al editor inplace (perdida de foco) y un
  // EditValue := X sobre un control sin parent dispara EInvalidOperation
  // 'no tiene ventana principal'.
  if (Sender is TcxCustomEdit) and TWinControl(Sender).HasParent then
  begin
    try
      TcxCustomEdit(Sender).EditValue := AvNuevo;
    except
      on E: EInvalidOperation do
        // Defensivo: si cxGrid desparenta el editor entre el HasParent
        // de arriba y el set EditValue, seguimos sin pintar — el data
        // link ya tiene el valor via RegistrarValorAtributo.
        ;
    end;
  end;

  // Cerramos el editor inplace ANTES de tocar cdsLineas / cambiar foco. Usamos
  // HideEdit(False) porque RegistrarValorAtributo ya escribio el campo: pedir
  // PostEditValue (HideEdit(True)) sobre un editor que cxGrid pudo
  // desparentar durante el popup vuelve a disparar EInvalidOperation.
  if tvLineasOpe.Controller.EditingController.IsEditing then
    tvLineasOpe.Controller.EditingController.HideEdit(False);

  // Diferimos via PostMessage para soltar el callstack del OnButtonClick.
  // Asi cxGrid termina de limpiar el editor inplace (que ya HideEdit'amos)
  // antes de que FinalizarUltimoAtributo abra el ShowMessage de "no hay
  // stock" o haga Cancel/Append. Si lo hacemos en linea, los DataChange
  // del EnableControls/Append intentan refrescar el TcxButtonEdit que
  // cxGrid todavia tiene en su pool con Parent = nil -> EInvalidOperation.
  if (Orden = FNumAtributosActual) and (FNumAtributosActual > 0) then
    PostMessage(Self.Handle, WM_FINALIZAR_ATRIB_CAJA, 0, 0)
  else
    PostMessage(Self.Handle, WM_AVANZAR_ATRIB_CAJA, Orden + 1, 0);

end;

procedure TfrmMtoOpeCaja.WMFinalizarAtribCaja(var Msg: TMessage);
var
  sArticulo: string;
  sSku: string;
  i: Integer;
  iNumAtributos: Integer;
  iNumSeparadores: Integer;
  bSkuCompleto: Boolean;
begin
  // Ejecuta FinalizarUltimoAtributo fuera del callstack del OnButtonClick
  // del TcxButtonEdit. Ver tvLineasOpeAvButtonClick para el motivo.
  // El mensaje solo es valido cuando ya se han elegido todos los atributos.
  // Asi un mensaje ajeno o atrasado nunca valida el articulo padre como SKU.
  bSkuCompleto := False;
  if DatosCaja.cdsLineas.Active and not DatosCaja.cdsLineas.IsEmpty then
  begin
    sArticulo := Trim(DatosCaja.cdsLineas.FieldByName(
      'CODIGO_ART_FACLIN').AsString);
    sSku := Trim(DatosCaja.cdsLineas.FieldByName(
      'CODIGO_UNIDAD_FACLIN').AsString);
    iNumAtributos := DatosCaja.cdsLineas.FieldByName(
      'NUM_ATRIBUTOS_REQ_FACTURA_LINEA').AsInteger;
    iNumSeparadores := 0;
    for i := 1 to Length(sSku) do
    begin
      if sSku[i] = '/' then
        Inc(iNumSeparadores);
    end;
    bSkuCompleto := (sArticulo <> '') and (sSku <> sArticulo) and
      (iNumAtributos > 0) and (iNumSeparadores = iNumAtributos);
  end;
  if bSkuCompleto then
    FinalizarUltimoAtributo;
end;

procedure TfrmMtoOpeCaja.WMAvanzarAtribCaja(var Msg: TMessage);
var
  SigCol : TcxGridDBColumn;
  sw : TStopwatch;
begin
  // Avanza el foco a la siguiente columna de atributo. Diferido por la
  // misma razon que WMFinalizarAtribCaja.
  sw := TStopwatch.StartNew;
  SigCol := ObtenerColumnaPorTag(Msg.WParam);
  if (SigCol <> nil) and SigCol.Visible then
  begin
    tvLineasOpe.Controller.FocusedColumn := SigCol;
    tvLineasOpe.Controller.EditingController.ShowEdit;
  end;
//  LogPerfCaja('CajaOpe.AvanzarAtrib',//    Format('tag=%d | total=%d ms',//           [Integer(Msg.WParam),sw.ElapsedMilliseconds]));
end;

procedure TfrmMtoOpeCaja.GuardarLayoutCaja;
var
  Layout: TLayoutSaver;
begin
  Layout := TLayoutSaver.Create(Self.Name, PerfilesUsuario);
  try
    Layout.GuardarGeometria(Self);
    Layout.GuardarAlturaPanel('StockPanelHeight', pnlBusqueda);
    Layout.GuardarAnchoPanel('FotoStockWidth',    pnlFotoStock);
    Layout.GuardarGrid('Lineas', tvLineasOpe);
    if Layout.PreguntarYGrabar('Personalización Caja') then
      ShowMessage(SInfoLayoutCajaGuardado);
  finally
    FreeAndNil(Layout);
  end;
end;

function TfrmMtoOpeCaja.IntentarCerrar: Boolean;
begin
  Result := True;
  if (csDestroying in ComponentState) then Exit;
  if (DatosCaja.cdsLineas.Active) and (not DatosCaja.cdsLineas.IsEmpty) then
  begin
    if not Visible then
    begin
      Show;
      BringToFront;
    end;
    if MessageDlg(
      Format(SPreguntaEliminarOperacionCajaPendiente, [Self.Tag]),
                  mtConfirmation, [mbYes, mbNo], 0) = mrYes then
    begin
      if DatosCaja.cdsLineas.State in [dsEdit, dsInsert] then
        DatosCaja.cdsLineas.Cancel;
      Close;
    end
    else
    begin
      Result := False;
    end;
  end
  else
  begin
    Close;
  end;
end;

function TfrmMtoOpeCaja.ObtenerColumnaPorTag(
  NumColumn: Integer): TcxGridDBColumn;
var
  i:Integer;
begin
  Result := nil;
  for i:= 0 to tvLineasOpe.ColumnCount - 1 do
    if (tvLineasOpe.Columns[i].Tag = NumColumn) then
    begin
      Result := (tvLineasOpe.Columns[i] as TcxGridDBColumn);
      Exit;
    end;
end;

procedure TfrmMtoOpeCaja.Timer1Timer(Sender: TObject);
begin
  ActualizarRelojCaja;
end;

end.
