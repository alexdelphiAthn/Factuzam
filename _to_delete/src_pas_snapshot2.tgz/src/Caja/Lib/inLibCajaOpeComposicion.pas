﻿{******************************************************************************}
{                                                                              }
{  Módulo:       inLibCajaOpeComposicion                                       }
{    Tipo:       Factoría                                                      }
{ Versión:       1.0.0                                                         }
{   Fecha:       29/07/2026                                                    }
{   Autor:       Alejandro Laorden Hidalgo                                     }
{                                                                              }
{  Copyright (c) Alejandro Laorden Hidalgo. Todos los derechos reservados.     }
{                                                                              }
{  Descripción:                                                                }
{    Construye los servicios utilizados por la ventana de operación de caja.  }
{******************************************************************************}
unit inLibCajaOpeComposicion;

interface

uses
  System.Classes, Uni, UniDataCaja,
  inLibParametrosIntf, inLibPermisosIntf,
  inLibContextoSesionIntf, inLibCatalogoSqlIntf,
  inLibCajaVentaIntf;

function CrearServiciosOperacionCaja(
  APropietario: TComponent;
  const AParametrosApp: IParametrosAplicacion;
  AConexion: TUniConnection;
  const AParametrosCaja: IParametrosCaja;
  const APermisos: IPermisosAplicacion;
  const AContextoSesion: IContextoSesionAplicacion;
  ADatosCaja: TdmCajaOpe;
  const ACatalogoSql: ICatalogoSql = nil;
  const AIncidenciasSql: IRegistroIncidenciasSql = nil
): TServiciosOperacionCaja;

implementation

uses
  inLibCajaStock,
  inLibCajaDescuentos,
  UniDataCajaConsultasRepositorio,
  inLibCajaRectificacion,
  inLibCajaCierreVenta,
  inMtoCajaImpresorVenta,
  inMtoCajaGrabadorVenta;

function CrearServiciosOperacionCaja(
  APropietario: TComponent;
  const AParametrosApp: IParametrosAplicacion;
  AConexion: TUniConnection;
  const AParametrosCaja: IParametrosCaja;
  const APermisos: IPermisosAplicacion;
  const AContextoSesion: IContextoSesionAplicacion;
  ADatosCaja: TdmCajaOpe;
  const ACatalogoSql: ICatalogoSql;
  const AIncidenciasSql: IRegistroIncidenciasSql
): TServiciosOperacionCaja;
begin
  Result.RepositorioConsultas :=
    TRepositorioConsultasCaja.Create(
      AConexion,
      ACatalogoSql,
      AIncidenciasSql);
  Result.ServicioRectificacion :=
    TServicioRectificacionCaja.Create(
      Result.RepositorioConsultas);
  Result.PoliticaStock :=
    TPoliticaStockVenta.Create(
      AConexion,
      AParametrosCaja);
  Result.RepartidorDescuento :=
    TRepartidorDescuento.Create;
  Result.Impresor :=
    TImpresorVentaVcl.Create(
      APropietario,
      AParametrosApp,
      AConexion,
      AParametrosCaja,
      APermisos);
  Result.ServicioCierre :=
    TServicioCierreVenta.Create(
      TGrabadorVentaCaja.Create(ADatosCaja),
      Result.Impresor,
      AParametrosCaja,
      AContextoSesion,
      AConexion);
end;

end.
