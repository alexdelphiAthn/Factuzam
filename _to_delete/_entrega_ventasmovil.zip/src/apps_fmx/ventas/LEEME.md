# VentasFzam — ventas del día en el móvil

App FMX de **solo lectura**. Enseña las líneas de venta de un día con su
foto y el total del día. No escribe nada en Factuzam.

Proyecto independiente, igual que `recuento`: no se compila dentro de
`fzam.dproj` y la UI se construye por código, sin `.fmx`.

## Qué se ve

Por línea: hora, SKU, descripción, temporada, proveedor, importe y la foto
del artículo a 300 px. Al tocar una fila se abre la ficha con todo:
familia, color, precio de coste, PVP, descuento en % y en euros, precio de
venta y total.

En la cabecera, los cuatro totales del día: **venta**, **coste**,
**margen** (importe y %) y **descuento**. Si escribes en el buscador, los
totales pasan a ser los de lo filtrado y se rotula «(filtrado)».

> El margen se calcula contra la **base imponible**, no contra la venta con
> IVA: el precio de coste no lleva IVA, así que restarlo del importe con
> IVA daría un margen inflado de varios puntos. Por eso la app enseña la
> venta con IVA (que es lo que cuadra con la caja) y a la vez un margen
> honesto.

## Puesta en marcha

1. Con `CertApiWeb`, crear una credencial con los ámbitos **`ventas:leer`**
   y **`fotos:leer`**. Sin el segundo el listado sale sin fotos.
2. En el servidor: subir `ventas/lineas.php`, `fotos/imagen.php` y
   `privado/ventas_proyeccion.php`, y lanzar
   `sql/esquema_ventas_lineas.sql` contra la BBDD del webservice.
3. Abrir la app, botón ⚙, y rellenar URL base, token y referencia.

## Manejo

- **◀ / ▶** cambian de día. Tocar la fecha vuelve a hoy.
- El buscador filtra en local sobre lo ya descargado, así que va instantáneo
  y no vuelve a llamar al servidor.
- Las ventas **anuladas** no cuentan ni salen. El endpoint las excluye salvo
  que se pida `incluir_anuladas=1`.

## Detalles de implementación

- **Fotos**: se piden una sola vez por artículo + color (no por talla) y
  quedan cacheadas en disco, así que el segundo día que las mires ya no
  bajan. La descarga va en segundo plano después de pintar la lista: el
  listado sale de inmediato aunque la red vaya lenta, y las fotos aparecen
  cuando llegan. `fotos/imagen.php` manda ETag, o sea que ni siquiera se
  retransmiten si no han cambiado.
- **Cambio de día durante una descarga**: cada carga lleva un número de
  generación; si cambias de día a media descarga, las fotos pendientes se
  abandonan en vez de pintarse sobre la lista nueva.
- **El día es el de la factura** (`FECHA_FAC`), no el instante UTC de
  recepción. Así el corte del día es el del negocio y no baila con el huso
  horario ni con cuándo se sincronizó el ticket.
- Cada hilo usa su propia instancia de `TVentasApi`: `THTTPClient` no es
  seguro de compartir entre hilos.

## Limitación conocida

La **temporada** de las ventas enviadas **antes** de este cambio llega
vacía: esos eventos se serializaron sin ella y no se puede reconstruir hacia
atrás. Se arregla sola en cuanto esas ventas se vuelvan a enviar; las nuevas
la traen desde el primer momento.
