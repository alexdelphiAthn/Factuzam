{******************************************************************************}
{                                                                              }
{  Módulo:       inLibArqueo                                                   }
{    Tipo:       Fachada                                                       }
{ Versión:       1.1.0                                                         }
{   Fecha:       30/07/2026                                                    }
{   Autor:       Alejandro Laorden Hidalgo                                     }
{                                                                              }
{  Copyright (c) Alejandro Laorden Hidalgo. Todos los derechos reservados.     }
{                                                                              }
{  Descripción:                                                                }
{    Tipos compatibles y SQL de resúmenes pendiente de extraer del dominio.   }
{******************************************************************************}
unit inLibArqueo;

interface

uses
  inLibArqueoIntf;

const
  TipoOpVenta = inLibArqueoIntf.TipoOpVenta;
  TipoOpDevolucion = inLibArqueoIntf.TipoOpDevolucion;
  TipoOpCobroCuenta = inLibArqueoIntf.TipoOpCobroCuenta;
  TipoOpEntradaCambio = inLibArqueoIntf.TipoOpEntradaCambio;
  TipoOpGastoCaja = inLibArqueoIntf.TipoOpGastoCaja;
  TipoOpDeposito = inLibArqueoIntf.TipoOpDeposito;
  TipoOpValeRedimido = inLibArqueoIntf.TipoOpValeRedimido;
  EstadoDepositoAbierto = inLibArqueoIntf.EstadoDepositoAbierto;

type
  TArqueoPagoForma = inLibArqueoIntf.TArqueoPagoForma;
  TArqueoCaja = inLibArqueoIntf.TArqueoCaja;

  TArqueoCalculadora = class
  public
    class function SQLResumenSeccion(ANiveles: Integer): string;
    class function SQLResumenTemporada: string;
  end;

implementation

uses
  System.SysUtils,
  inLibRectificativas;

class function TArqueoCalculadora.SQLResumenSeccion(
  ANiveles: Integer): string;
var
  sRuta: string;
  sJoins: string;
  sPadre: string;
  sNiveles: string;
  i: Integer;
begin
  sRuta := 'CONCAT_WS(''|''';
  for i := 8 downto 1 do
  begin
    sRuta := sRuta + Format(
      ', COALESCE(a%d.NOMBRE_FAM_FAM, a%d.CODIGO_FAM_FAM)',
      [i, i]);
  end;
  sRuta := sRuta +
    ', COALESCE(f.NOMBRE_FAM_FAM, f.CODIGO_FAM_FAM))';
  sJoins := '';
  sPadre := 'f';
  for i := 1 to 8 do
  begin
    sJoins := sJoins + Format(
      ' LEFT JOIN fza_articulos_familias a%d' +
      ' ON a%d.CODIGO_FAM_FAM = %s.CODIGO_SUBFAMILIA_FAM ',
      [i, i, sPadre]);
    sPadre := Format('a%d', [i]);
  end;
  sNiveles := 'SELECT 1 AS NIVEL';
  for i := 2 to ANiveles do
    sNiveles := sNiveles + Format(
      ' UNION ALL SELECT %d',
      [i]);
  Result :=
    ' SELECT CONCAT(REPEAT(''  '', x.NIVEL - 1), ' +
    'SUBSTRING_INDEX(x.CLAVE, ''|'', -1)) AS FAMILIA, ' +
    'COUNT(*) AS UDS, COALESCE(SUM(x.TOTAL), 0) AS NETO ' +
    'FROM (SELECT n.NIVEL AS NIVEL, ' +
    'SUBSTRING_INDEX(b.RUTA, ''|'', n.NIVEL) AS CLAVE, ' +
    'b.TOTAL AS TOTAL FROM (SELECT b0.RUTA, b0.TOTAL, ' +
    '(CHAR_LENGTH(b0.RUTA) - ' +
    'CHAR_LENGTH(REPLACE(b0.RUTA,''|'','''')))+1 AS PROF ' +
    'FROM (SELECT COALESCE(NULLIF(' + sRuta + ', ''''), ' +
    'l.NOMBRE_FAM_FACLIN, l.CODIGO_FAM_FACLIN, ' +
    'a.CODIGO_FAM_ART, ''(sin familia)'') AS RUTA, ' +
    'l.TOTAL_FACLIN AS TOTAL FROM fza_caja_operaciones o ' +
    'JOIN fza_facturas_lineas l ' +
    'ON l.CODIGO_EMP_FACLIN = o.CODIGO_EMP_OPCAJA ' +
    'AND l.CODIGO_ALM_FACLIN = o.CODIGO_ALM_OPCAJA ' +
    'AND l.CODIGO_CAJA_FACLIN = o.CODIGO_CAJA_OPCAJA ' +
    'AND l.NUMERO_OPERACION_FACLIN = ' +
    'o.NUMERO_OPERACION_OPCAJA LEFT JOIN fza_articulos a ' +
    'ON a.CODIGO_ART_ART = l.CODIGO_ART_FACLIN ' +
    'LEFT JOIN fza_articulos_familias f ' +
    'ON f.CODIGO_FAM_FAM = ' +
    'COALESCE(l.CODIGO_FAM_FACLIN, a.CODIGO_FAM_ART)' +
    sJoins +
    'WHERE o.TIPO_OPERACION_OPCAJA = ''VE'' ' +
    'AND o.CODIGO_EMP_OPCAJA = :pEMPRESA ' +
    'AND o.CODIGO_ALM_OPCAJA = :pALMACEN ' +
    'AND o.CODIGO_CAJA_OPCAJA = :pCAJA ' +
    'AND o.FECHA_OPERACION_OPCAJA >= :pFDESDE ' +
    'AND o.FECHA_OPERACION_OPCAJA <= :pFHASTA ' +
    SQLExcluirSimplificadaSustituida(
      'o.CODIGO_EMP_OPCAJA',
      'o.SERIE_FAC_OPCAJA',
      'o.NUMERO_FAC_OPCAJA') +
    ') b0) b JOIN (' + sNiveles +
    ') n ON n.NIVEL <= b.PROF) x ' +
    'GROUP BY x.NIVEL, x.CLAVE ORDER BY x.CLAVE';
end;

class function TArqueoCalculadora.SQLResumenTemporada: string;
begin
  Result :=
    'SELECT COALESCE(NULLIF(COALESCE(v.VALOR_PV, ' +
    'v.VALOR_LIBRE_ARTPROP), ''''), ''(sin temporada)'') AS TEMPORADA, ' +
    'COALESCE(SUM(l.CANTIDAD_FACLIN), 0) AS UDS, ' +
    'COALESCE(SUM(l.TOTAL_FACLIN), 0) AS NETO ' +
    'FROM fza_caja_operaciones o JOIN fza_facturas_lineas l ' +
    'ON l.CODIGO_EMP_FACLIN = o.CODIGO_EMP_OPCAJA ' +
    'AND l.CODIGO_ALM_FACLIN = o.CODIGO_ALM_OPCAJA ' +
    'AND l.CODIGO_CAJA_FACLIN = o.CODIGO_CAJA_OPCAJA ' +
    'AND l.NUMERO_OPERACION_FACLIN = o.NUMERO_OPERACION_OPCAJA ' +
    'LEFT JOIN vi_articulos_propiedades_efectivas v ' +
    'ON v.CODIGO_UNIDAD_SKU = l.CODIGO_UNIDAD_FACLIN ' +
    'AND v.CODIGO_PROP_ARTPROP = ''TEMPORADA'' ' +
    'WHERE o.TIPO_OPERACION_OPCAJA = ''VE'' ' +
    'AND o.CODIGO_EMP_OPCAJA = :pEMPRESA ' +
    'AND o.CODIGO_ALM_OPCAJA = :pALMACEN ' +
    'AND o.CODIGO_CAJA_OPCAJA = :pCAJA ' +
    'AND o.FECHA_OPERACION_OPCAJA >= :pFDESDE ' +
    'AND o.FECHA_OPERACION_OPCAJA <= :pFHASTA ' +
    SQLExcluirSimplificadaSustituida(
      'o.CODIGO_EMP_OPCAJA',
      'o.SERIE_FAC_OPCAJA',
      'o.NUMERO_FAC_OPCAJA') +
    'GROUP BY TEMPORADA ORDER BY TEMPORADA';
end;

end.
