﻿{******************************************************************************}
{                                                                              }
{  Módulo:       inLibTiraCajaTicket                                           }
{    Tipo:       Librería                                                      }
{ Versión:       1.0.0                                                         }
{   Fecha:       18/06/2026                                                    }
{   Autor:       Alejandro Laorden Hidalgo                                     }
{                                                                              }
{  Copyright (c) Alejandro Laorden Hidalgo. Todos los derechos reservados.     }
{                                                                              }
{  Descripción:                                                                }
{    Genera e imprime la "tira de caja": una tira térmica con el desglose de   }
{    las operaciones entre dos fechas para una empresa / almacén / caja. Las   }
{    ventas facturadas llevan nº de factura, nº de operación, fecha, líneas y  }
{    formas de pago. De forma opcional adjunta los traspasos salientes, los    }
{    ingresos por caja, los gastos por caja y las ventas a crédito (depósitos).}
{                                                                              }
{    Las ventas pueden acotarse a varias series de factura simplificada        }
{    (ASeries; vacío = todas). El agrupamiento (ACronologico) decide el orden: }
{    por tipo de documento (secciones con doble línea al romper el tipo) o por }
{    orden cronológico (operaciones intercaladas, cada una rotulada con su     }
{    tipo). En ambos modos hay una línea simple tras cada operación.           }
{                                                                              }
{    Si AImprimirQR es True y Verifactu está activo (envío PRE o PRO), añade   }
{    el QR tributario de cada venta. Si la impresora es 'DEBUG' abre el        }
{    preview (TFormVisualizador) en vez de mandar a la impresora física.       }
{******************************************************************************}
unit inLibTiraCajaTicket;

interface

uses
  System.SysUtils, System.Classes,
  inLibFTicket, inLibParametrosIntf,
  inLibTiraCajaTicketIntf;

type
  TTiraCajaTicket = class
  private
    class function FmtImp(AValor: Currency): string;
    class function LPad(const AValor: string; ALongitud: Integer): string;
    class function CentrarRelleno(const ATexto: string;
                                  ARelleno: Char): string;
    class procedure EscribirCabeceraEmpresa(ATicket: TTicketTermico;
                                            const ARepositorio:
                                            IRepositorioTiraCajaTicket;
                                            const AEmpresa: string);
    class procedure EscribirLineasArticulos(ATicket: TTicketTermico;
                                            const ARepositorio:
                                            IRepositorioTiraCajaTicket;
                                            const AEmpresa, AAlmacen,
                                                  ACaja, AOperacion: string);
    class procedure EscribirFormasPago(ATicket: TTicketTermico;
                                       const ARepositorio:
                                       IRepositorioTiraCajaTicket;
                                       const AEmpresa, AAlmacen,
                                             ACaja, AOperacion: string);
    class procedure EscribirOperacion(
                                      const AParametrosApp:
                                      IParametrosAplicacion;
                                      ATicket: TTicketTermico;
                                      const ARepositorio:
                                      IRepositorioTiraCajaTicket;
                                      const AOperacion:
                                      TOperacionTiraCaja;
                                      AImprimirQR: Boolean);
    // Render de una operación de traspaso saliente (cursor maestro posicionado):
    // cabecera (referencia + fecha) + almacén destino + detalle de artículos
    // (SKU, descripción, cantidad) de fza_movimientos_almacen. Con AValorar
    // (permiso caja.verCoste) añade el coste por línea y el total a coste, que
    // además devuelve.
    class function EscribirTraspasoOpe(ATicket: TTicketTermico;
                                       const ARepositorio:
                                       IRepositorioTiraCajaTicket;
                                       const AOperacion:
                                       TOperacionTiraCaja;
                                       AValorar: Boolean): Currency;
    // Render de una operación de ingreso (EC) o gasto (GC): referencia + fecha
    // + importe y el concepto. Devuelve el importe de la operación.
    class function EscribirIngresoGastoOpe(ATicket: TTicketTermico;
                                           const AOperacion:
                                           TOperacionTiraCaja): Currency;
    // Render de una operación de depósito (DE = venta a crédito): por cada
    // depósito ligado a la operación, el cliente, el artículo (SKU +
    // descripción), la valoración (precio x cantidad), lo entregado a cuenta
    // (cobro del cliente) y el pendiente. Devuelve el total vendido y, en
    // ACobrado, lo entregado a cuenta.
    class function EscribirDepositoOpe(ATicket: TTicketTermico;
                                       const ARepositorio:
                                       IRepositorioTiraCajaTicket;
                                       const AOperacion:
                                       TOperacionTiraCaja;
                                       out ACobrado: Currency): Currency;
  public
    // Series facturadas distintas en el rango para la caja (para preguntar
    // la serie cuando hay más de una). Devuelve [] si no hay operaciones.
    class function ObtenerSeries(
                                 const ARepositorio:
                                 IRepositorioTiraCajaTicket;
                                 const AEmpresa, AAlmacen, ACaja: string;
                                 AFechaDesde, AFechaHasta: TDate)
                                 : TArray<string>;
    class procedure Imprimir(
                             const AParametrosApp: IParametrosAplicacion;
                             const ARepositorio:
                             IRepositorioTiraCajaTicket;
                             const AEmpresa, AAlmacen, ACaja: string;
                             AFechaDesde, AFechaHasta: TDate;
                             const ASeries: TArray<string>;
                             AImprimirQR: Boolean = False;
                             const ANombreImpresora: string = 'DEBUG';
                             ACronologico: Boolean = False;
                             AIncluirTraspasos: Boolean = False;
                             AIncluirIngresos: Boolean = False;
                             AIncluirGastos: Boolean = False;
                             AIncluirCredito: Boolean = False;
                             AValorarTraspasos: Boolean = False);
    // Vuelca las mismas operaciones de la tira a una hoja de cálculo y la abre
    // en el visor de Excel (TfrmMtoPreviewExcel), con detalle por línea y el
    // mismo orden / agrupamiento que la impresión.
    class procedure ExportarExcel(AOwner: TComponent;
                                  const ARepositorio:
                                  IRepositorioTiraCajaTicket;
                                  const AEmpresa, AAlmacen, ACaja: string;
                                  AFechaDesde, AFechaHasta: TDate;
                                  const ASeries: TArray<string>;
                                  ACronologico: Boolean = False;
                                  AIncluirTraspasos: Boolean = False;
                                  AIncluirIngresos: Boolean = False;
                                  AIncluirGastos: Boolean = False;
                                  AIncluirCredito: Boolean = False;
                                  AValorarTraspasos: Boolean = False);
  end;

implementation

uses
  Vcl.Forms,
  dxSpreadSheet, dxSpreadSheetCore, dxSpreadSheetGraphics,
  dxSpreadSheetTypes, dxSpreadSheetStyles, dxHashUtils,
  inLibPreviewTicket, inLibDir, inLibFormatoDocumento, inLibVerifactu,
  inLibPreviewExcel, inLibDevExcel,
  inLibMsgTickets;

// =============================================================================
//   Helpers de formato
// =============================================================================

class function TTiraCajaTicket.FmtImp(AValor: Currency): string;
begin
  Result := FormatFloat(',0.00', AValor);
end;

class function TTiraCajaTicket.LPad(const AValor: string;
                                    ALongitud: Integer): string;
begin
  if Length(AValor) >= ALongitud then
    Result := AValor
  else
    Result := StringOfChar('0', ALongitud - Length(AValor)) + AValor;
end;

// Centra ATexto en N_CHAR_LIN columnas rellenando ambos lados con ARelleno,
// como en el ejemplo del nº de factura: _____Nº Fac.: 2026.CE.004227_____
class function TTiraCajaTicket.CentrarRelleno(const ATexto: string;
                                              ARelleno: Char): string;
var
  iLibre, iIzq: Integer;
begin
  if Length(ATexto) >= N_CHAR_LIN then
    Result := ATexto
  else
  begin
    iLibre := N_CHAR_LIN - Length(ATexto);
    iIzq   := iLibre div 2;
    Result := StringOfChar(ARelleno, iIzq) + ATexto +
              StringOfChar(ARelleno, iLibre - iIzq);
  end;
end;

// =============================================================================
//   Cabecera de empresa
// =============================================================================

class procedure TTiraCajaTicket.EscribirCabeceraEmpresa(
  ATicket: TTicketTermico;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AEmpresa: string);
var
  oEmpresa: TEmpresaTiraCajaTicket;
begin
  oEmpresa := ARepositorio.ObtenerEmpresa(
    AEmpresa);
  if oEmpresa.Encontrada then
  begin
    ATicket.Alinear(alCentro);
    ATicket.Negrita(True);
    ATicket.EscribirLinea(oEmpresa.RazonSocial);
    ATicket.Negrita(False);
    ATicket.EscribirLinea(oEmpresa.Direccion);
    ATicket.EscribirLinea(
      Trim(oEmpresa.CodigoPostal + ' ' + oEmpresa.Poblacion));
    ATicket.EscribirLinea(oEmpresa.Provincia);
    ATicket.EscribirLinea(
      Format(STicketCif, [oEmpresa.Nif]));
  end;
end;

// =============================================================================
//   Líneas de artículos y formas de pago de una operación
// =============================================================================

class procedure TTiraCajaTicket.EscribirLineasArticulos(
  ATicket: TTicketTermico;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AEmpresa, AAlmacen, ACaja, AOperacion: string);
var
  aLineas: TArray<TLineaVentaTiraCaja>;
  oLinea: TLineaVentaTiraCaja;
  sSku, sDesc, sIzq, sTot: string;
  dCant: Double;
  iMax: Integer;
begin
  aLineas := ARepositorio.ListarLineasVenta(
    AEmpresa,
    AAlmacen,
    ACaja,
    AOperacion);
  for oLinea in aLineas do
  begin
    sSku := Trim(oLinea.CodigoUnidad);
    sDesc := Trim(oLinea.Descripcion);
    dCant := oLinea.Cantidad;
    sTot := FmtImp(oLinea.Total);
    // Línea 1: SKU, cantidad opcional e importe.
    if dCant <> 1 then
      sIzq := FormatFloat('0.##', dCant) + 'x ' + sSku
    else
      sIzq := sSku;
    iMax := N_CHAR_LIN - Length(sTot) - 1;
    if Length(sIzq) > iMax then
      sIzq := Copy(sIzq, 1, iMax);
    ATicket.TextoColumnas(sIzq, sTot);
    if sDesc <> '' then
      ATicket.EscribirLinea(Copy(sDesc, 1, N_CHAR_LIN));
  end;
end;

class procedure TTiraCajaTicket.EscribirFormasPago(
  ATicket: TTicketTermico;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AEmpresa, AAlmacen, ACaja, AOperacion: string);
var
  aFormasPago: TArray<TFormaPagoTiraCaja>;
  oFormaPago: TFormaPagoTiraCaja;
  dCambio: Currency;
begin
  dCambio := 0;
  aFormasPago := ARepositorio.ListarFormasPago(
    AEmpresa,
    AAlmacen,
    ACaja,
    AOperacion);
  for oFormaPago in aFormasPago do
  begin
    dCambio := dCambio + oFormaPago.ImporteCambio;
    if oFormaPago.ImporteEntregado <> 0 then
      ATicket.TextoColumnas(
        UpperCase(Trim(oFormaPago.Descripcion)),
        FmtImp(oFormaPago.ImporteEntregado));
  end;
  if dCambio > 0 then
    ATicket.TextoColumnas(STicketCambio, FmtImp(dCambio));
end;

// =============================================================================
//   Bloque de una operación (cursor AOpe posicionado en la fila)
// =============================================================================

class procedure TTiraCajaTicket.EscribirOperacion(
  const AParametrosApp: IParametrosAplicacion;
  ATicket: TTicketTermico;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AOperacion: TOperacionTiraCaja;
  AImprimirQR: Boolean);
var
  sEmp, sAlm, sCaja, sOpe, sSerie, sNumFac, sNif, sQR: string;
  dFechaOpe, dFechaFac: TDateTime;
  dLiquido: Currency;
begin
  sEmp := AOperacion.Empresa;
  sAlm := AOperacion.Almacen;
  sCaja := AOperacion.Caja;
  sOpe := AOperacion.NumeroOperacion;
  dFechaOpe := AOperacion.FechaOperacion;
  sSerie := AOperacion.SerieFactura;
  sNumFac := AOperacion.NumeroFactura;
  dLiquido := AOperacion.TotalLiquido;
  dFechaFac := AOperacion.FechaFactura;
  sNif := AOperacion.NifEmpresaFactura;
  // Separador con el nº de factura formateado según la empresa.
  ATicket.Alinear(alIzquierda);
  ATicket.EscribirLinea(
    CentrarRelleno(
      Format(
        STicketNumeroFactura,
        [FormatearDocumento(
           AOperacion.FormatoDocumento,
           sSerie,
           sNumFac)]),
      '_'));
  // Operación, fecha/hora, empresa y Tda.almacén-caja.
  ATicket.EscribirLinea(
    Format(
      '%s %s %s',
      [sOpe,
       FormatDateTime('dd/mm/yy hh:nn:ss', dFechaOpe),
       Format(
         STicketFormatoTienda,
         [LPad(sEmp, 3),
          LPad(sAlm, 3),
          LPad(sCaja, 2)])]));
  // Líneas del ticket con su precio.
  EscribirLineasArticulos(
    ATicket,
    ARepositorio,
    sEmp,
    sAlm,
    sCaja,
    sOpe);
  // Total de la operación y formas de pago.
  ATicket.Negrita(True);
  ATicket.TextoColumnas(STicketAPagar, FmtImp(dLiquido));
  ATicket.Negrita(False);
  EscribirFormasPago(
    ATicket,
    ARepositorio,
    sEmp,
    sAlm,
    sCaja,
    sOpe);
  // QR tributario por operación si Verifactu está activo y se ha pedido.
  if AImprimirQR and (not SinVerifactuActivo(AParametrosApp))
     and (Trim(sSerie) <> '') and (Trim(sNumFac) <> '') then
  begin
    sQR := ConstruirUrlQR(AParametrosApp, sNif, sSerie, sNumFac,
      dFechaFac, dLiquido);
    if sQR <> '' then
    begin
      ATicket.Alinear(alCentro);
      // Nivel de corrección M (49) exigido por la AEAT para el QR.
      ATicket.ImprimirQRNativo(sQR, 6, 49);
      ATicket.Alinear(alIzquierda);
    end;
  end;
end;

// =============================================================================
//   Render por operación (traspaso / ingreso-gasto / depósito)
// =============================================================================

class function TTiraCajaTicket.EscribirIngresoGastoOpe(
  ATicket: TTicketTermico;
  const AOperacion: TOperacionTiraCaja): Currency;
var
  sRef, sConcepto: string;
  iMax: Integer;
begin
  Result := AOperacion.ImporteTotal;
  sConcepto := Trim(AOperacion.ConceptoGastoIngreso);
  // Fila 1: referencia (nº op + fecha) e importe a la derecha.
  sRef := Format(
    STicketOperacionCorta,
    [AOperacion.NumeroOperacion]) + ' ' +
    FormatDateTime(
      'dd/mm/yy hh:nn',
      AOperacion.FechaOperacion);
  iMax := N_CHAR_LIN - Length(FmtImp(Result)) - 1;
  if Length(sRef) > iMax then
    sRef := Copy(sRef, 1, iMax);
  ATicket.TextoColumnas(sRef, FmtImp(Result));
  // Fila 2: concepto descriptivo (gasto / ingreso), recortado.
  if sConcepto <> '' then
    ATicket.EscribirLinea(Copy(sConcepto, 1, N_CHAR_LIN));
end;

class function TTiraCajaTicket.EscribirTraspasoOpe(ATicket: TTicketTermico;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AOperacion: TOperacionTiraCaja;
  AValorar: Boolean): Currency;
var
  aLineas: TArray<TLineaTraspasoTiraCaja>;
  oLinea: TLineaTraspasoTiraCaja;
  iMax: Integer;
  sEmp, sAlm, sCaja, sOpe, sRef, sDestino, sSku, sDesc, sIzq: string;
  dCantidad, dCosteUnit: Double;
begin
  Result := 0;
  sEmp := AOperacion.Empresa;
  sAlm := AOperacion.Almacen;
  sCaja := AOperacion.Caja;
  sOpe := AOperacion.NumeroOperacion;
  sDestino := Trim(AOperacion.AlmacenContrapartida);
  // Referencia: documento formateado si lo tiene; si no, nº de operación.
  sRef := Trim(AOperacion.SerieFactura);
  if (sRef <> '') and
     (Trim(AOperacion.NumeroFactura) <> '') then
    sRef := FormatearDocumento(
      AOperacion.FormatoDocumento,
      sRef,
      AOperacion.NumeroFactura)
  else
    sRef := Format(STicketOperacionCorta, [sOpe]);
  ATicket.Negrita(True);
  ATicket.EscribirLinea(sRef + ' ' +
    FormatDateTime('dd/mm/yy hh:nn',
      AOperacion.FechaOperacion));
  ATicket.Negrita(False);
  if sDestino <> '' then
    ATicket.EscribirLinea('  -> ' + sDestino);
  aLineas := ARepositorio.ListarLineasTraspaso(
    sEmp,
    sAlm,
    sCaja,
    sOpe);
  for oLinea in aLineas do
  begin
    sSku := Trim(oLinea.CodigoUnidad);
    sDesc := Trim(oLinea.Descripcion);
    dCantidad := oLinea.Cantidad;
    dCosteUnit := oLinea.PrecioCosteUnitario;
    sIzq := FormatFloat('0.##', dCantidad) + 'x ' + sSku;
    if AValorar then
    begin
      iMax := N_CHAR_LIN - Length(FmtImp(dCantidad * dCosteUnit)) - 1;
      if Length(sIzq) > iMax then
        sIzq := Copy(sIzq, 1, iMax);
      ATicket.TextoColumnas(sIzq, FmtImp(dCantidad * dCosteUnit));
    end
    else
      ATicket.EscribirLinea(Copy(sIzq, 1, N_CHAR_LIN));
    if sDesc <> '' then
      ATicket.EscribirLinea(Copy(sDesc, 1, N_CHAR_LIN));
    Result := Result + dCantidad * dCosteUnit;
  end;
  if AValorar then
  begin
    ATicket.Negrita(True);
    ATicket.TextoColumnas(STicketTotalTraspasoCoste, FmtImp(Result));
    ATicket.Negrita(False);
  end;
end;

class function TTiraCajaTicket.EscribirDepositoOpe(ATicket: TTicketTermico;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AOperacion: TOperacionTiraCaja;
  out ACobrado: Currency): Currency;
var
  aDepositos: TArray<TDepositoTiraCaja>;
  oDeposito: TDepositoTiraCaja;
  iMax: Integer;
  sEmp, sAlm, sCaja, sOpe, sCli, sCliNom, sSku, sDesc, sIzq: string;
  dCantidad: Double;
  dPrecio, dTotal, dAnticipo, dPendiente: Currency;
begin
  Result := 0;
  ACobrado := 0;
  sEmp := AOperacion.Empresa;
  sAlm := AOperacion.Almacen;
  sCaja := AOperacion.Caja;
  sOpe := AOperacion.NumeroOperacion;
  // Cabecera del depósito: referencia de operación + fecha.
  ATicket.Negrita(True);
  ATicket.EscribirLinea(Format(STicketOperacionCorta, [sOpe]) + ' ' +
    FormatDateTime('dd/mm/yy hh:nn',
      AOperacion.FechaOperacion));
  ATicket.Negrita(False);
  aDepositos := ARepositorio.ListarDepositos(
    sEmp,
    sAlm,
    sCaja,
    sOpe);
  for oDeposito in aDepositos do
  begin
    sCli := Trim(oDeposito.CodigoCliente);
    sCliNom := Trim(oDeposito.Cliente);
    sSku := Trim(oDeposito.CodigoUnidad);
    sDesc := Trim(oDeposito.Descripcion);
    dPrecio := oDeposito.PrecioVenta;
    dCantidad := oDeposito.Cantidad;
    dAnticipo := oDeposito.ImporteAnticipo;
    dTotal := dPrecio * dCantidad;
    dPendiente := dTotal - dAnticipo;
    ATicket.EscribirLinea(
      Copy(
        Format(
          STicketClienteCorto,
          [Trim(sCli + ' ' + sCliNom)]),
        1,
        N_CHAR_LIN));
    sIzq := FormatFloat('0.##', dCantidad) + 'x ' + sSku;
    iMax := N_CHAR_LIN - Length(FmtImp(dTotal)) - 1;
    if Length(sIzq) > iMax then
      sIzq := Copy(sIzq, 1, iMax);
    ATicket.TextoColumnas(sIzq, FmtImp(dTotal));
    if sDesc <> '' then
      ATicket.EscribirLinea(Copy(sDesc, 1, N_CHAR_LIN));
    if dAnticipo <> 0 then
      ATicket.TextoColumnas(STicketEntregadoCuenta, FmtImp(dAnticipo));
    ATicket.TextoColumnas(STicketPendienteSangrado, FmtImp(dPendiente));
    Result := Result + dTotal;
    ACobrado := ACobrado + dAnticipo;
  end;
end;

// =============================================================================
//   API pública
// =============================================================================

class function TTiraCajaTicket.ObtenerSeries(
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AEmpresa, AAlmacen, ACaja: string;
  AFechaDesde, AFechaHasta: TDate): TArray<string>;
begin
  Result := ARepositorio.ListarSeries(
    AEmpresa,
    AAlmacen,
    ACaja,
    AFechaDesde,
    AFechaHasta);
end;

class procedure TTiraCajaTicket.Imprimir(
  const AParametrosApp: IParametrosAplicacion;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AEmpresa, AAlmacen, ACaja: string;
  AFechaDesde, AFechaHasta: TDate;
  const ASeries: TArray<string>;
  AImprimirQR: Boolean;
  const ANombreImpresora: string;
  ACronologico: Boolean;
  AIncluirTraspasos: Boolean;
  AIncluirIngresos: Boolean;
  AIncluirGastos: Boolean;
  AIncluirCredito: Boolean;
  AValorarTraspasos: Boolean);
var
  aOperaciones: TArray<TOperacionTiraCaja>;
  oOperacion: TOperacionTiraCaja;
  Ticket: TTicketTermico;
  ComandosESC, RutaPDF, sSerieTxt: string;
  sGrupo, sPrevGrupo: string;
  i: Integer;
  bVerCoste: Boolean;
  dCobradoOp: Currency;
  nVen, nTra, nIng, nGas, nDep: Integer;
  totVen, totTra, totIng, totGas, totDepV, totDepC: Currency;

  // Rótulo corto del tipo, para el modo cronológico.
  function RotuloGrupo(const AG: string): string;
  begin
    if AG = 'TRA' then
      Result := STicketRotuloTraspaso
    else if AG = 'ING' then
      Result := STicketRotuloIngreso
    else if AG = 'GAS' then
      Result := STicketRotuloGasto
    else if AG = 'DEP' then
      Result := STicketRotuloDeposito
    else
      Result := STicketRotuloVenta;
  end;

  // Cabecera de sección (modo por tipo de documento).
  procedure CabeceraGrupo(const AG: string);
  begin
    Ticket.Alinear(alCentro);
    Ticket.Negrita(True);
    if AG = 'TRA' then
      Ticket.EscribirLinea(STicketTraspasosSalientes)
    else if AG = 'ING' then
      Ticket.EscribirLinea(STicketIngresosPorCaja)
    else if AG = 'GAS' then
      Ticket.EscribirLinea(STicketGastosPorCaja)
    else if AG = 'DEP' then
      Ticket.EscribirLinea(STicketVentasCreditoDepositos)
    else
      Ticket.EscribirLinea(STicketVentasFacturadas);
    Ticket.Negrita(False);
    Ticket.Alinear(alIzquierda);
  end;

  // Pie / subtotal de un grupo según sus acumuladores.
  procedure SubtotalGrupo(const AG: string);
  begin
    if AG = 'TRA' then
    begin
      Ticket.TextoColumnas(STicketTraspasos, IntToStr(nTra));
      if bVerCoste then
      begin
        Ticket.Negrita(True);
        Ticket.TextoColumnas(STicketSubtotalCoste, FmtImp(totTra));
        Ticket.Negrita(False);
      end;
    end
    else if AG = 'ING' then
    begin
      Ticket.TextoColumnas(STicketIngresos, IntToStr(nIng));
      Ticket.Negrita(True);
      Ticket.TextoColumnas(STicketSubtotal, FmtImp(totIng));
      Ticket.Negrita(False);
    end
    else if AG = 'GAS' then
    begin
      Ticket.TextoColumnas(STicketGastos, IntToStr(nGas));
      Ticket.Negrita(True);
      Ticket.TextoColumnas(STicketSubtotal, FmtImp(totGas));
      Ticket.Negrita(False);
    end
    else if AG = 'DEP' then
    begin
      Ticket.TextoColumnas(STicketDepositos, IntToStr(nDep));
      Ticket.Negrita(True);
      Ticket.TextoColumnas(STicketSubtotalVenta, FmtImp(totDepV));
      Ticket.Negrita(False);
      if totDepC <> 0 then
        Ticket.TextoColumnas(STicketSubtotalCobrado, FmtImp(totDepC));
    end
    else
    begin
      Ticket.TextoColumnas(STicketOperaciones, IntToStr(nVen));
      Ticket.Negrita(True);
      Ticket.TextoColumnas(STicketTotalVentasSinSigno, FmtImp(totVen));
      Ticket.Negrita(False);
    end;
  end;

  // Render de la fila actual del cursor según su grupo, acumulando totales.
  procedure RenderFila(const AG: string);
  begin
    if AG = 'TRA' then
    begin
      totTra := totTra + EscribirTraspasoOpe(
        Ticket,
        ARepositorio,
        oOperacion,
        bVerCoste);
      Inc(nTra);
    end
    else if AG = 'ING' then
    begin
      totIng := totIng + EscribirIngresoGastoOpe(
        Ticket,
        oOperacion);
      Inc(nIng);
    end
    else if AG = 'GAS' then
    begin
      totGas := totGas + EscribirIngresoGastoOpe(
        Ticket,
        oOperacion);
      Inc(nGas);
    end
    else if AG = 'DEP' then
    begin
      totDepV := totDepV + EscribirDepositoOpe(
        Ticket,
        ARepositorio,
        oOperacion,
        dCobradoOp);
      totDepC := totDepC + dCobradoOp;
      Inc(nDep);
    end
    else
    begin
      EscribirOperacion(
        AParametrosApp,
        Ticket,
        ARepositorio,
        oOperacion,
        AImprimirQR);
      totVen := totVen + oOperacion.TotalLiquido;
      Inc(nVen);
    end;
  end;

begin
  nVen   := 0;
  nTra   := 0;
  nIng   := 0;
  nGas   := 0;
  nDep   := 0;
  totVen   := 0;
  totTra   := 0;
  totIng   := 0;
  totGas   := 0;
  totDepV  := 0;
  totDepC  := 0;
  // Los traspasos solo se valoran (coste) si el usuario tiene permiso para ver
  // coste; el resto de bloques (ingresos, gastos, depósitos) siempre se valoran.
  bVerCoste := AValorarTraspasos;
  Ticket := TTicketTermico.Create(ANombreImpresora);
  try
    Ticket.Inicializar;
    EscribirCabeceraEmpresa(
      Ticket,
      ARepositorio,
      AEmpresa);
    // Título: caja, rango exacto, series seleccionadas y modo de agrupamiento.
    Ticket.SaltarLineas(1);
    Ticket.Alinear(alCentro);
    Ticket.Negrita(True);
    Ticket.EscribirLinea(Format(STicketArqueoCajaHora,
      [ACaja, FormatDateTime('hh:nn', Now)]));
    Ticket.EscribirLinea(Format(STicketDel,
      [FormatDateTime('dd/mm/yy hh:nn', AFechaDesde)]));
    Ticket.EscribirLinea(Format(STicketAl,
      [FormatDateTime('dd/mm/yy hh:nn', AFechaHasta)]));
    if Length(ASeries) = 0 then
      Ticket.EscribirLinea(STicketTodasSeries)
    else
    begin
      sSerieTxt := '';
      for i := 0 to High(ASeries) do
      begin
        if sSerieTxt <> '' then
          sSerieTxt := sSerieTxt + ', ';
        sSerieTxt := sSerieTxt + ASeries[i];
      end;
      Ticket.EscribirLinea(Format(STicketSeries, [sSerieTxt]));
    end;
    if ACronologico then
      Ticket.EscribirLinea(STicketOrdenCronologico)
    else
      Ticket.EscribirLinea(STicketOrdenTipoDocumento);
    Ticket.Negrita(False);
    Ticket.Alinear(alIzquierda);
    Ticket.SaltarLineas(1);
    // Impresión y Excel comparten el mismo read model de operaciones.
    aOperaciones := ARepositorio.ListarOperaciones(
      AEmpresa,
      AAlmacen,
      ACaja,
      AFechaDesde,
      AFechaHasta,
      ASeries,
      ACronologico,
      AIncluirTraspasos,
      AIncluirIngresos,
      AIncluirGastos,
      AIncluirCredito);
    sPrevGrupo := '';
    for oOperacion in aOperaciones do
    begin
      sGrupo := oOperacion.Grupo;
      if ACronologico then
      begin
        // Cada operación rotulada con su tipo, para saber qué es cada una.
        Ticket.Negrita(True);
        Ticket.EscribirLinea('[' + RotuloGrupo(sGrupo) + ']');
        Ticket.Negrita(False);
      end
      else
      begin
        // Cambio de tipo: cierra el grupo anterior y abre el siguiente.
        if sGrupo <> sPrevGrupo then
        begin
          if sPrevGrupo <> '' then
          begin
            SubtotalGrupo(sPrevGrupo);
            Ticket.LineaSeparadora('=');
            Ticket.LineaSeparadora('=');
          end
          else
            Ticket.LineaSeparadora('=');
          CabeceraGrupo(sGrupo);
        end;
      end;
      RenderFila(sGrupo);
      Ticket.LineaSeparadora('-');
      sPrevGrupo := sGrupo;
    end;
    // Cierre: subtotal del último grupo (por tipo) o resumen (cronológico).
    if (nVen + nTra + nIng + nGas + nDep) = 0 then
      Ticket.EscribirLinea(STicketSinOperaciones)
    else if not ACronologico then
      SubtotalGrupo(sPrevGrupo)
    else
    begin
      Ticket.LineaSeparadora('=');
      Ticket.Alinear(alCentro);
      Ticket.Negrita(True);
      Ticket.EscribirLinea(STicketResumen);
      Ticket.Negrita(False);
      Ticket.Alinear(alIzquierda);
      if nVen > 0 then
        SubtotalGrupo('VEN');
      if nTra > 0 then
        SubtotalGrupo('TRA');
      if nIng > 0 then
        SubtotalGrupo('ING');
      if nGas > 0 then
        SubtotalGrupo('GAS');
      if nDep > 0 then
        SubtotalGrupo('DEP');
    end;
    Ticket.SaltarLineas(1);
    Ticket.Alinear(alCentro);
    Ticket.EscribirLinea(FormatDateTime('dd/mm/yyyy hh:nn:ss', Now));
    Ticket.SaltarLineas(2);
    Ticket.CortarPapel;
    // Vista previa (DEBUG) o impresión real.
    ComandosESC := Ticket.ObtenerComandos;
    RutaPDF := GetUserFolderTickets + 'TiraCaja_' +
               FormatDateTime('yyyy_mm_dd_hh_nn_ss', Now) + '.pdf';
    ImprimirOPrevisualizarTicket(Ticket, ComandosESC, RutaPDF,
                                 ANombreImpresora);
  finally
    FreeAndNil(Ticket);
  end;
end;

const
  COL_EXCEL_TIPO = 0;
  COL_EXCEL_FECHA = 1;
  COL_EXCEL_DOCUMENTO = 2;
  COL_EXCEL_REFERENCIA = 3;
  COL_EXCEL_SKU = 4;
  COL_EXCEL_DESCRIPCION = 5;
  COL_EXCEL_CANTIDAD = 6;
  COL_EXCEL_IMPORTE = 7;
  COL_EXCEL_COBRADO = 8;
  COL_EXCEL_PENDIENTE = 9;

type
  TExportadorTiraCajaExcel = class
  private
    FPropietario: TComponent;
    FRepositorio: IRepositorioTiraCajaTicket;
    FEmpresa: string;
    FAlmacen: string;
    FCaja: string;
    FFechaDesde: TDate;
    FFechaHasta: TDate;
    FSeries: TArray<string>;
    FCronologico: Boolean;
    FIncluirTraspasos: Boolean;
    FIncluirIngresos: Boolean;
    FIncluirGastos: Boolean;
    FIncluirCredito: Boolean;
    FVerCoste: Boolean;
    FPreview: TSesionPreviewExcel;
    FHoja: TdxSpreadSheetTableView;
    FOperacion: TOperacionTiraCaja;
    FFila: Integer;
    FImporteVentas: Currency;
    FImporteTraspasos: Currency;
    FImporteIngresos: Currency;
    FImporteGastos: Currency;
    FVentaDepositos: Currency;
    FCobroDepositos: Currency;
    FNumeroVentas: Integer;
    FNumeroTraspasos: Integer;
    FNumeroIngresos: Integer;
    FNumeroGastos: Integer;
    FNumeroDepositos: Integer;
    function ReferenciaDocumento: string;
    function FechaOperacion: string;
    function TextoSeries: string;
    procedure EscribirMoneda(AFila, AColumna: Integer; AValor: Currency);
    procedure EscribirCabecera;
    procedure VolcarVenta;
    procedure VolcarTraspaso;
    procedure VolcarIngresoGasto(const ATipo: string);
    procedure VolcarDeposito;
    procedure EscribirTituloGrupo(const AGrupo: string);
    procedure EscribirSubtotalGrupo(const AGrupo: string);
    procedure VolcarFila(const AGrupo: string);
    procedure ProcesarOperaciones;
    procedure EscribirCierre(const AUltimoGrupo: string);
  public
    constructor Create(
      APropietario: TComponent;
      const ARepositorio: IRepositorioTiraCajaTicket;
      const AEmpresa, AAlmacen, ACaja: string;
      AFechaDesde, AFechaHasta: TDate; const ASeries: TArray<string>;
      ACronologico, AIncluirTraspasos, AIncluirIngresos,
      AIncluirGastos, AIncluirCredito, AVerCoste: Boolean);
    procedure Ejecutar;
  end;

constructor TExportadorTiraCajaExcel.Create(APropietario: TComponent;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AEmpresa, AAlmacen, ACaja: string;
  AFechaDesde, AFechaHasta: TDate; const ASeries: TArray<string>;
  ACronologico, AIncluirTraspasos, AIncluirIngresos,
  AIncluirGastos, AIncluirCredito, AVerCoste: Boolean);
begin
  inherited Create;
  FPropietario := APropietario;
  FRepositorio := ARepositorio;
  FEmpresa := AEmpresa;
  FAlmacen := AAlmacen;
  FCaja := ACaja;
  FFechaDesde := AFechaDesde;
  FFechaHasta := AFechaHasta;
  FSeries := ASeries;
  FCronologico := ACronologico;
  FIncluirTraspasos := AIncluirTraspasos;
  FIncluirIngresos := AIncluirIngresos;
  FIncluirGastos := AIncluirGastos;
  FIncluirCredito := AIncluirCredito;
  FVerCoste := AVerCoste;
end;

function TExportadorTiraCajaExcel.ReferenciaDocumento: string;
begin
  if Trim(FOperacion.SerieFactura) <> '' then
    Result := FormatearDocumento(
      FOperacion.FormatoDocumento,
      FOperacion.SerieFactura,
      FOperacion.NumeroFactura)
  else
    Result := 'Op.' + FOperacion.NumeroOperacion;
end;

function TExportadorTiraCajaExcel.FechaOperacion: string;
begin
  Result := FormatDateTime('dd/mm/yyyy hh:nn',
    FOperacion.FechaOperacion);
end;

function TExportadorTiraCajaExcel.TextoSeries: string;
var
  iSerie: Integer;
begin
  if Length(FSeries) = 0 then
    Result := 'TODAS LAS SERIES'
  else
  begin
    Result := 'SERIES: ';
    for iSerie := 0 to High(FSeries) do
    begin
      if iSerie > 0 then
        Result := Result + ', ';
      Result := Result + FSeries[iSerie];
    end;
  end;
end;

procedure TExportadorTiraCajaExcel.EscribirMoneda(
  AFila, AColumna: Integer; AValor: Currency);
begin
  W(FHoja, AFila, AColumna, AValor, False, ssahRight);
  FHoja.Cells[AFila, AColumna].Style.DataFormat.FormatCode := '#,##0.00';
end;

procedure TExportadorTiraCajaExcel.EscribirCabecera;
begin
  W(FHoja, 0, COL_EXCEL_TIPO, 'TIRA DE CAJA · CAJA ' + FCaja, True);
  W(FHoja, 1, COL_EXCEL_TIPO, 'DEL ' +
    FormatDateTime('dd/mm/yyyy hh:nn', FFechaDesde) + '  AL ' +
    FormatDateTime('dd/mm/yyyy hh:nn', FFechaHasta));
  W(FHoja, 2, COL_EXCEL_TIPO, TextoSeries);
  if FCronologico then
    W(FHoja, 3, COL_EXCEL_TIPO, 'ORDEN: CRONOLOGICO')
  else
    W(FHoja, 3, COL_EXCEL_TIPO, 'ORDEN: POR TIPO DE DOCUMENTO');
  W(FHoja, 5, COL_EXCEL_TIPO, 'Tipo', True);
  W(FHoja, 5, COL_EXCEL_FECHA, 'Fecha', True);
  W(FHoja, 5, COL_EXCEL_DOCUMENTO, 'Documento', True);
  W(FHoja, 5, COL_EXCEL_REFERENCIA, 'Cliente/Destino', True);
  W(FHoja, 5, COL_EXCEL_SKU, 'SKU', True);
  W(FHoja, 5, COL_EXCEL_DESCRIPCION, 'Descripción', True);
  W(FHoja, 5, COL_EXCEL_CANTIDAD, 'Cantidad', True, ssahRight);
  W(FHoja, 5, COL_EXCEL_IMPORTE, 'Importe', True, ssahRight);
  W(FHoja, 5, COL_EXCEL_COBRADO, 'Cobrado', True, ssahRight);
  W(FHoja, 5, COL_EXCEL_PENDIENTE, 'Pendiente', True, ssahRight);
  FFila := 6;
end;

procedure TExportadorTiraCajaExcel.VolcarVenta;
var
  aLineas: TArray<TLineaVentaTiraCaja>;
  oLinea: TLineaVentaTiraCaja;
  sDocumento: string;
begin
  sDocumento := ReferenciaDocumento;
  aLineas := FRepositorio.ListarLineasVenta(
    FOperacion.Empresa,
    FOperacion.Almacen,
    FOperacion.Caja,
    FOperacion.NumeroOperacion);
  for oLinea in aLineas do
  begin
    W(FHoja, FFila, COL_EXCEL_TIPO, 'Venta');
    W(FHoja, FFila, COL_EXCEL_FECHA, FechaOperacion);
    W(FHoja, FFila, COL_EXCEL_DOCUMENTO, sDocumento);
    W(FHoja, FFila, COL_EXCEL_SKU, oLinea.CodigoUnidad);
    W(FHoja, FFila, COL_EXCEL_DESCRIPCION, oLinea.Descripcion);
    W(FHoja, FFila, COL_EXCEL_CANTIDAD,
      oLinea.Cantidad,
      False,
      ssahRight);
    EscribirMoneda(
      FFila,
      COL_EXCEL_IMPORTE,
      oLinea.Total);
    FImporteVentas := FImporteVentas + oLinea.Total;
    Inc(FFila);
  end;
  Inc(FNumeroVentas);
end;

procedure TExportadorTiraCajaExcel.VolcarTraspaso;
var
  aLineas: TArray<TLineaTraspasoTiraCaja>;
  dCantidad, dCoste: Double;
  oLinea: TLineaTraspasoTiraCaja;
  sDestino, sDocumento: string;
begin
  sDocumento := ReferenciaDocumento;
  sDestino := Trim(FOperacion.AlmacenContrapartida);
  aLineas := FRepositorio.ListarLineasTraspaso(
    FOperacion.Empresa,
    FOperacion.Almacen,
    FOperacion.Caja,
    FOperacion.NumeroOperacion);
  for oLinea in aLineas do
  begin
    dCantidad := oLinea.Cantidad;
    dCoste := oLinea.PrecioCosteUnitario;
    W(FHoja, FFila, COL_EXCEL_TIPO, 'Traspaso');
    W(FHoja, FFila, COL_EXCEL_FECHA, FechaOperacion);
    W(FHoja, FFila, COL_EXCEL_DOCUMENTO, sDocumento);
    W(FHoja, FFila, COL_EXCEL_REFERENCIA, sDestino);
    W(FHoja, FFila, COL_EXCEL_SKU, oLinea.CodigoUnidad);
    W(FHoja, FFila, COL_EXCEL_DESCRIPCION, oLinea.Descripcion);
    W(FHoja, FFila, COL_EXCEL_CANTIDAD, dCantidad, False, ssahRight);
    if FVerCoste then
    begin
      EscribirMoneda(FFila, COL_EXCEL_IMPORTE, dCantidad * dCoste);
      FImporteTraspasos := FImporteTraspasos + dCantidad * dCoste;
    end;
    Inc(FFila);
  end;
  Inc(FNumeroTraspasos);
end;

procedure TExportadorTiraCajaExcel.VolcarIngresoGasto(
  const ATipo: string);
var
  dImporte: Currency;
begin
  dImporte := FOperacion.ImporteTotal;
  W(FHoja, FFila, COL_EXCEL_TIPO, ATipo);
  W(FHoja, FFila, COL_EXCEL_FECHA, FechaOperacion);
  W(FHoja, FFila, COL_EXCEL_DOCUMENTO,
    'Op.' + FOperacion.NumeroOperacion);
  W(FHoja, FFila, COL_EXCEL_DESCRIPCION,
    Trim(FOperacion.ConceptoGastoIngreso));
  EscribirMoneda(FFila, COL_EXCEL_IMPORTE, dImporte);
  if ATipo = 'Ingreso' then
  begin
    FImporteIngresos := FImporteIngresos + dImporte;
    Inc(FNumeroIngresos);
  end
  else
  begin
    FImporteGastos := FImporteGastos + dImporte;
    Inc(FNumeroGastos);
  end;
  Inc(FFila);
end;

procedure TExportadorTiraCajaExcel.VolcarDeposito;
var
  aDepositos: TArray<TDepositoTiraCaja>;
  dAnticipo, dPrecio, dTotal: Currency;
  dCantidad: Double;
  oDeposito: TDepositoTiraCaja;
begin
  aDepositos := FRepositorio.ListarDepositos(
    FOperacion.Empresa,
    FOperacion.Almacen,
    FOperacion.Caja,
    FOperacion.NumeroOperacion);
  for oDeposito in aDepositos do
  begin
    dPrecio := oDeposito.PrecioVenta;
    dCantidad := oDeposito.Cantidad;
    dAnticipo := oDeposito.ImporteAnticipo;
    dTotal := dPrecio * dCantidad;
    W(FHoja, FFila, COL_EXCEL_TIPO, 'Crédito (depósito)');
    W(FHoja, FFila, COL_EXCEL_FECHA, FechaOperacion);
    W(FHoja, FFila, COL_EXCEL_DOCUMENTO,
      'Op.' + FOperacion.NumeroOperacion);
    W(FHoja, FFila, COL_EXCEL_REFERENCIA,
      Trim(oDeposito.CodigoCliente + ' ' + oDeposito.Cliente));
    W(FHoja, FFila, COL_EXCEL_SKU, oDeposito.CodigoUnidad);
    W(FHoja, FFila, COL_EXCEL_DESCRIPCION, oDeposito.Descripcion);
    W(FHoja, FFila, COL_EXCEL_CANTIDAD, dCantidad, False, ssahRight);
    EscribirMoneda(FFila, COL_EXCEL_IMPORTE, dTotal);
    EscribirMoneda(FFila, COL_EXCEL_COBRADO, dAnticipo);
    EscribirMoneda(FFila, COL_EXCEL_PENDIENTE, dTotal - dAnticipo);
    FVentaDepositos := FVentaDepositos + dTotal;
    FCobroDepositos := FCobroDepositos + dAnticipo;
    Inc(FFila);
  end;
  Inc(FNumeroDepositos);
end;

procedure TExportadorTiraCajaExcel.EscribirTituloGrupo(
  const AGrupo: string);
begin
  if AGrupo = 'TRA' then
    W(FHoja, FFila, COL_EXCEL_TIPO,
      'TRASPASOS SALIENTES (ORIGEN)', True)
  else if AGrupo = 'ING' then
    W(FHoja, FFila, COL_EXCEL_TIPO, 'INGRESOS POR CAJA', True)
  else if AGrupo = 'GAS' then
    W(FHoja, FFila, COL_EXCEL_TIPO, 'GASTOS POR CAJA', True)
  else if AGrupo = 'DEP' then
    W(FHoja, FFila, COL_EXCEL_TIPO,
      'VENTAS A CREDITO (DEPOSITOS)', True)
  else
    W(FHoja, FFila, COL_EXCEL_TIPO, 'VENTAS FACTURADAS', True);
  Inc(FFila);
end;

procedure TExportadorTiraCajaExcel.EscribirSubtotalGrupo(
  const AGrupo: string);
begin
  if AGrupo = 'TRA' then
  begin
    W(FHoja, FFila, COL_EXCEL_DESCRIPCION,
      'SUBTOTAL TRASPASOS (coste)', True, ssahRight);
    if FVerCoste then
      EscribirMoneda(FFila, COL_EXCEL_IMPORTE, FImporteTraspasos);
  end
  else if AGrupo = 'ING' then
  begin
    W(FHoja, FFila, COL_EXCEL_DESCRIPCION,
      'SUBTOTAL INGRESOS', True, ssahRight);
    EscribirMoneda(FFila, COL_EXCEL_IMPORTE, FImporteIngresos);
  end
  else if AGrupo = 'GAS' then
  begin
    W(FHoja, FFila, COL_EXCEL_DESCRIPCION,
      'SUBTOTAL GASTOS', True, ssahRight);
    EscribirMoneda(FFila, COL_EXCEL_IMPORTE, FImporteGastos);
  end
  else if AGrupo = 'DEP' then
  begin
    W(FHoja, FFila, COL_EXCEL_DESCRIPCION,
      'SUBTOTAL DEPOSITOS', True, ssahRight);
    EscribirMoneda(FFila, COL_EXCEL_IMPORTE, FVentaDepositos);
    EscribirMoneda(FFila, COL_EXCEL_COBRADO, FCobroDepositos);
  end
  else
  begin
    W(FHoja, FFila, COL_EXCEL_DESCRIPCION,
      'SUBTOTAL VENTAS', True, ssahRight);
    EscribirMoneda(FFila, COL_EXCEL_IMPORTE, FImporteVentas);
  end;
  Inc(FFila);
end;

procedure TExportadorTiraCajaExcel.VolcarFila(const AGrupo: string);
begin
  if AGrupo = 'TRA' then
    VolcarTraspaso
  else if AGrupo = 'ING' then
    VolcarIngresoGasto('Ingreso')
  else if AGrupo = 'GAS' then
    VolcarIngresoGasto('Gasto')
  else if AGrupo = 'DEP' then
    VolcarDeposito
  else
    VolcarVenta;
end;

procedure TExportadorTiraCajaExcel.ProcesarOperaciones;
var
  aOperaciones: TArray<TOperacionTiraCaja>;
  oOperacion: TOperacionTiraCaja;
  sGrupo, sGrupoAnterior: string;
begin
  sGrupoAnterior := '';
  aOperaciones := FRepositorio.ListarOperaciones(
    FEmpresa,
    FAlmacen,
    FCaja,
    FFechaDesde,
    FFechaHasta,
    FSeries,
    FCronologico,
    FIncluirTraspasos,
    FIncluirIngresos,
    FIncluirGastos,
    FIncluirCredito);
  for oOperacion in aOperaciones do
  begin
    FOperacion := oOperacion;
    sGrupo := FOperacion.Grupo;
    if (not FCronologico) and (sGrupo <> sGrupoAnterior) then
    begin
      if sGrupoAnterior <> '' then
      begin
        EscribirSubtotalGrupo(sGrupoAnterior);
        Inc(FFila);
      end;
      EscribirTituloGrupo(sGrupo);
    end;
    VolcarFila(sGrupo);
    sGrupoAnterior := sGrupo;
  end;
  EscribirCierre(sGrupoAnterior);
end;

procedure TExportadorTiraCajaExcel.EscribirCierre(
  const AUltimoGrupo: string);
begin
  if (FNumeroVentas + FNumeroTraspasos + FNumeroIngresos +
      FNumeroGastos + FNumeroDepositos) = 0 then
    W(FHoja, FFila, COL_EXCEL_TIPO, 'Sin operaciones')
  else if not FCronologico then
    EscribirSubtotalGrupo(AUltimoGrupo)
  else
  begin
    Inc(FFila);
    W(FHoja, FFila, COL_EXCEL_TIPO, 'RESUMEN', True);
    Inc(FFila);
    if FNumeroVentas > 0 then
      EscribirSubtotalGrupo('VEN');
    if FNumeroTraspasos > 0 then
      EscribirSubtotalGrupo('TRA');
    if FNumeroIngresos > 0 then
      EscribirSubtotalGrupo('ING');
    if FNumeroGastos > 0 then
      EscribirSubtotalGrupo('GAS');
    if FNumeroDepositos > 0 then
      EscribirSubtotalGrupo('DEP');
  end;
end;

procedure TExportadorTiraCajaExcel.Ejecutar;
begin
  FPreview := TPreviewExcel.Crear(FPropietario);
  try
    if FPreview.HojaCalculo.SheetCount = 0 then
      FPreview.HojaCalculo.AddSheet(
        'Tira de Caja', TdxSpreadSheetTableView);
    FHoja := FPreview.HojaCalculo.ActiveSheetAsTable;
    if FHoja <> nil then
    begin
      FHoja.BeginUpdate;
      try
        EscribirCabecera;
        ProcesarOperaciones;
      finally
        FHoja.EndUpdate;
      end;
      if FPropietario is TForm then
        FPreview.AsignarPopupParent(TForm(FPropietario));
      FPreview.AsignarNombreArchivo('TiraCaja_' +
        FormatDateTime('yyyy_mm_dd_hh_nn_ss', Now));
      FPreview.Mostrar;
    end;
  finally
    FreeAndNil(FPreview);
  end;
end;

class procedure TTiraCajaTicket.ExportarExcel(AOwner: TComponent;
  const ARepositorio: IRepositorioTiraCajaTicket;
  const AEmpresa, AAlmacen, ACaja: string;
  AFechaDesde, AFechaHasta: TDate; const ASeries: TArray<string>;
  ACronologico: Boolean; AIncluirTraspasos: Boolean;
  AIncluirIngresos: Boolean; AIncluirGastos: Boolean;
  AIncluirCredito: Boolean; AValorarTraspasos: Boolean);
var
  oExportador: TExportadorTiraCajaExcel;
begin
  oExportador := TExportadorTiraCajaExcel.Create(
    AOwner,
    ARepositorio,
    AEmpresa,
    AAlmacen,
    ACaja,
    AFechaDesde,
    AFechaHasta,
    ASeries,
    ACronologico,
    AIncluirTraspasos,
    AIncluirIngresos,
    AIncluirGastos,
    AIncluirCredito,
    AValorarTraspasos);
  try
    oExportador.Ejecutar;
  finally
    FreeAndNil(oExportador);
  end;
end;

end.
