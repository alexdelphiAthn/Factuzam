﻿program Fzam;

uses
//  {$IFDEF DEBUG}
//  FastMM4,
//  {$ENDIF}
  Winapi.Windows,
  Forms,
  MidasLib,
  {$IF CompilerVersion >= 37.0}
  Vcl.Consts in 'src\vcl37\Vcl.Consts.pas',
  {$ELSE}
  {$IFDEF VER350}
  Vcl.Consts in 'src\vcl\Vcl.Consts.pas',
  {$ENDIF }
  {$ENDIF }
  Sysutils,
  Classes,
  dxCore,
  JclDebug,
  JclHookExcept,
  inLibDevExp in 'src\Lib\inLibDevExp.pas',
  inLibHojaCalculoIntf in 'src\Lib\inLibHojaCalculoIntf.pas',
  inLibHojaCalculoUtil in 'src\Lib\inLibHojaCalculoUtil.pas',
  inLibHojaCalculoDevEx in 'src\Lib\inLibHojaCalculoDevEx.pas',
  inLibFormatoExcel in 'src\Lib\inLibFormatoExcel.pas',
  inLibDir in 'src\Lib\inLibDir.pas',
  inLibGlobalVar in 'src\Lib\inLibGlobalVar.pas',
  inLibLogIntf in 'src\Lib\inLibLogIntf.pas',
  inLibRegistroLogNulo in 'src\Lib\inLibRegistroLogNulo.pas',
  inLibConfigCamposIntf in 'src\Lib\inLibConfigCamposIntf.pas',
  inLibRepositoriosPantallaIntf in
    'src\Lib\inLibRepositoriosPantallaIntf.pas',
  inLibCargaMasivaArticulosPersistenciaIntf in
    'src\Lib\inLibCargaMasivaArticulosPersistenciaIntf.pas',
  inLibLog in 'src\Lib\inLibLog.pas',
  inLibDiag in 'src\Lib\inLibDiag.pas',
  inLibCadenas in 'src\Lib\inLibCadenas.pas',
  inLibCifrado in 'src\Lib\inLibCifrado.pas',
  inLibCifradoCopias in 'src\Lib\inLibCifradoCopias.pas',
  inLibConfiguracionIni in 'src\Lib\inLibConfiguracionIni.pas',
  inLibDatasets in 'src\Lib\inLibDatasets.pas',
  inLibValoresAutomaticos in 'src\Lib\inLibValoresAutomaticos.pas',
  inLibUser in 'src\Lib\inLibUser.pas',
  inLibWin in 'src\Lib\inLibWin.pas',
  inLibShowMto in 'src\Lib\inLibShowMto.pas',
  inLibAnfitrionMtoIntf in 'src\Lib\inLibAnfitrionMtoIntf.pas',
  inLibAnfitrionDatosIntf in 'src\Lib\inLibAnfitrionDatosIntf.pas',
  inLibInteraccionDatosIntf in
    'src\Lib\inLibInteraccionDatosIntf.pas',
  inLibRegistroPantallas in 'src\Lib\inLibRegistroPantallas.pas',
  inLibVentanaEmbebidaIntf in 'src\Lib\inLibVentanaEmbebidaIntf.pas',
  inLibUnitForm in 'src\Lib\inLibUnitForm.pas',
  inLibMsgComun in 'src\Lib\inLibMsgComun.pas',
  inLibMsgConfiguracion in 'src\Lib\inLibMsgConfiguracion.pas',
  inLibMsgArticulos in 'src\Lib\inLibMsgArticulos.pas',
  inLibMsgVentas in 'src\Lib\inLibMsgVentas.pas',
  inLibMsgCompras in 'src\Lib\inLibMsgCompras.pas',
  inLibMsgFacturas in 'src\Lib\inLibMsgFacturas.pas',
  inLibMsgCaja in 'src\Lib\inLibMsgCaja.pas',
  inLibMsgTickets in 'src\Lib\inLibMsgTickets.pas',
  inLibMsgIntegraciones in 'src\Lib\inLibMsgIntegraciones.pas',
  inLibMsgVerifactu in 'src\Lib\inLibMsgVerifactu.pas',
  inLibRegistroResourcestringTraducciones in
    'src\Lib\inLibRegistroResourcestringTraducciones.pas',
  inLibRectificativas in 'src\Lib\inLibRectificativas.pas',
  UniDataRectificativasSql in 'src\DataModules\UniDataRectificativasSql.pas',
  inLibNet in 'src\Lib\inLibNet.pas',
  inLibScriptDB in 'src\Lib\inLibScriptDB.pas',
  inLibIBAN in 'src\Lib\inLibIBAN.pas',
  inLibSepaRemesasVenta in 'src\Lib\inLibSepaRemesasVenta.pas',
  inLibFacturasLecturasIntf in
    'src\Lib\inLibFacturasLecturasIntf.pas',
  UniDataFacturasLecturas in
    'src\DataModules\UniDataFacturasLecturas.pas',
  inLibFacturasPersistenciaIntf in
    'src\Lib\inLibFacturasPersistenciaIntf.pas',
  UniDataFacturasOperaciones in
    'src\DataModules\UniDataFacturasOperaciones.pas',
  inLibFacturas in 'src\Lib\inLibFacturas.pas',
  inLibSqlSeguro in 'src\Lib\inLibSqlSeguro.pas',
  inLibMotorFiscalVenta in 'src\Lib\inLibMotorFiscalVenta.pas',
  inLibFacturasServiciosIntf in
    'src\Lib\inLibFacturasServiciosIntf.pas',
  UniDataCatalogoSqlValidacion in
    'src\DataModules\UniDataCatalogoSqlValidacion.pas',
  UniDataFacturasRepositorio in
    'src\DataModules\UniDataFacturasRepositorio.pas',
  inLibFacturasValidacionFiscal in
    'src\Lib\inLibFacturasValidacionFiscal.pas',
  inLibFacturasCalculo in
    'src\Lib\inLibFacturasCalculo.pas',
  inLibFacturasComposicion in
    'src\Lib\inLibFacturasComposicion.pas',
  inLibFacturasBorrado in 'src\Lib\inLibFacturasBorrado.pas',
  inLibFacturasEfectos in 'src\Lib\inLibFacturasEfectos.pas',
  inLibDocumentoIntf in 'src\Lib\inLibDocumentoIntf.pas',
  inLibDocumento in 'src\Lib\inLibDocumento.pas',
  inLibFacturasCobrosPresentacion in
    'src\Lib\inLibFacturasCobrosPresentacion.pas',
  inLibFacturasEstadoFiscalPresentacion in
    'src\Lib\inLibFacturasEstadoFiscalPresentacion.pas',
  inLibFacturasOperacionFiscal in
    'src\Lib\inLibFacturasOperacionFiscal.pas',
  inLibFacturasAplicacionIntf in
    'src\Lib\inLibFacturasAplicacionIntf.pas',
  inLibFacturasAplicacion in
    'src\Lib\inLibFacturasAplicacion.pas',
  inLibFacturasLineasEdicion in
    'src\Lib\inLibFacturasLineasEdicion.pas',
  inLibFacturasConsolidacionPresentacion in
    'src\Lib\inLibFacturasConsolidacionPresentacion.pas',
  inLibFacturasColumnasPresentacion in
    'src\Lib\inLibFacturasColumnasPresentacion.pas',
  inLibFacturasMovimientos in
    'src\Lib\inLibFacturasMovimientos.pas',
  inLibFacturasConsolidacion in
    'src\Lib\inLibFacturasConsolidacion.pas',
  inLibFacturasReapertura in
    'src\Lib\inLibFacturasReapertura.pas',
  inLibDevolucionesCompraStock in 'src\Lib\inLibDevolucionesCompraStock.pas',
  UniDataDevolucionesCompraStockRepositorio in
    'src\DataModules\UniDataDevolucionesCompraStockRepositorio.pas',
  inLibDevolucionesCompraPersistenciaIntf in
    'src\Lib\inLibDevolucionesCompraPersistenciaIntf.pas',
  UniDataDevolucionesCompraRepositorio in
    'src\DataModules\UniDataDevolucionesCompraRepositorio.pas',
  inLibFacturaPdfBlob in 'src\Lib\inLibFacturaPdfBlob.pas',
  inLibFormatoDocumento in 'src\Lib\inLibFormatoDocumento.pas',
  inLibInformesGuiasCache in 'src\Lib\inLibInformesGuiasCache.pas',
  inLibGridColumnChooser in 'src\Lib\inLibGridColumnChooser.pas',
  inLibConfigCampos in 'src\Lib\inLibConfigCampos.pas',
  inLibContextoSesionIntf in 'src\Lib\inLibContextoSesionIntf.pas',
  inLibContextoSesion in 'src\Lib\inLibContextoSesion.pas',
  inLibExcepcionesAplicacionIntf in
    'src\Lib\inLibExcepcionesAplicacionIntf.pas',
  inLibExcepcionesAplicacion in
    'src\Lib\inLibExcepcionesAplicacion.pas',
  inLibEnvioErroresIntf in
    'src\Lib\inLibEnvioErroresIntf.pas',
  inLibEnvioErrores in 'src\Lib\inLibEnvioErrores.pas',
  inLibFiltrosGuardadosIntf in 'src\Lib\inLibFiltrosGuardadosIntf.pas',
  inLibPerfilesUsuarioIntf in 'src\Lib\inLibPerfilesUsuarioIntf.pas',
  inLibPerfilesUsuarioValores in 'src\Lib\inLibPerfilesUsuarioValores.pas',
  inLibCatalogoSqlIntf in 'src\Lib\inLibCatalogoSqlIntf.pas',
  inLibCatalogoSqlValidacion in
    'src\Lib\inLibCatalogoSqlValidacion.pas',
  inLibCatalogoSqlPerfiles in
    'src\Lib\inLibCatalogoSqlPerfiles.pas',
  inLibCatalogoSqlAdmin in 'src\Lib\inLibCatalogoSqlAdmin.pas',
  inLibCatalogoSqlRegistro in 'src\Lib\inLibCatalogoSqlRegistro.pas',
  inLibCatalogoSqlIncidencias in
    'src\Lib\inLibCatalogoSqlIncidencias.pas',
  inLibCatalogoSqlEjecucion in
    'src\Lib\inLibCatalogoSqlEjecucion.pas',
  inLibTraduccionesIntf in 'src\Lib\inLibTraduccionesIntf.pas',
  inLibTraducciones in 'src\Lib\inLibTraducciones.pas',
  inLibTraduccionesInforme in 'src\Lib\inLibTraduccionesInforme.pas',
  inLibTraduccionesFastReport in
    'src\Lib\inLibTraduccionesFastReport.pas',
  inLibParametrosIntf in 'src\Lib\inLibParametrosIntf.pas',
  inLibParametrosBase in 'src\Lib\inLibParametrosBase.pas',
  inLibConexionesIntf in 'src\Lib\inLibConexionesIntf.pas',
  inLibConexionesUniDAC in 'src\Lib\inLibConexionesUniDAC.pas',
  inLibAuditoriaDatosIntf in 'src\Lib\inLibAuditoriaDatosIntf.pas',
  inLibAuditoriaDatos in 'src\Lib\inLibAuditoriaDatos.pas',
  inLibMonitorSQLIntf in 'src\Lib\inLibMonitorSQLIntf.pas',
  inLibMonitorSQLUniDAC in 'src\Lib\inLibMonitorSQLUniDAC.pas',
  inLibMonitorSQLLog in 'src\Lib\inLibMonitorSQLLog.pas',
  inLibPermisosIntf in 'src\Lib\inLibPermisosIntf.pas',
  inLibPermisos in 'src\Lib\inLibPermisos.pas',
  inLibPermisosUniDAC in 'src\Lib\inLibPermisosUniDAC.pas',
  inLibPermisosAdmin in 'src\Lib\inLibPermisosAdmin.pas',
  UniDataPermisosAdminRepositorio in
    'src\DataModules\UniDataPermisosAdminRepositorio.pas',
  inLibFiltroUsuario in 'src\Lib\inLibFiltroUsuario.pas',
  inLibGestorFiltrosMto in 'src\Lib\inLibGestorFiltrosMto.pas',
  inLibGestorPerfilesMto in 'src\Lib\inLibGestorPerfilesMto.pas',
  inLibGestorGuiasGridMto in 'src\Lib\inLibGestorGuiasGridMto.pas',
  inLibGestorTareasMto in 'src\Lib\inLibGestorTareasMto.pas',
  inLibGestorArticulosMto in 'src\Lib\inLibGestorArticulosMto.pas',
  inLibGestorCopiaLineasCompra in
    'src\Lib\inLibGestorCopiaLineasCompra.pas',
  inLibLicenciaAplicacion in 'src\Lib\inLibLicenciaAplicacion.pas',
  inMtoFrmBase in 'src\Core\inMtoFrmBase.pas' {frmBase},
  inMtoLogon in 'src\Core\inMtoLogon.pas' {frmLogon},
  inMtoPrincipal in 'src\Core\inMtoPrincipal.pas' {frmMtoPrincipal},
  inMtoGen in 'src\Forms\inMtoGen.pas' {frmMtoGen},
  inMtoBusquedaDatos in
    'src\Forms\inMtoBusquedaDatos.pas' {frmMtoBusquedaDatos},
  inMtoFacturasBase in 'src\Forms\inMtoFacturasBase.pas' {frmMtoFacturasBase},
  inMtoFacturasConsolidacionVcl in
    'src\Forms\inMtoFacturasConsolidacionVcl.pas',
  inMtoFacturasVistaVcl in 'src\Forms\inMtoFacturasVistaVcl.pas',
  inMtoFacturasCobrosVcl in 'src\Forms\inMtoFacturasCobrosVcl.pas',
  inMtoFacturasNormal in 'src\Forms\inMtoFacturasNormal.pas' {frmMtoFacturasNormal},
  inMtoFacturasSimplif in 'src\Forms\inMtoFacturasSimplif.pas' {frmMtoFacturasSimplif},
  inMtoArticulos in 'src\Forms\inMtoArticulos.pas' {frmMtoArticulos},
  inMtoArticulosGuardadoVcl in
    'src\Forms\inMtoArticulosGuardadoVcl.pas',
  inMtoClientes in 'src\Forms\inMtoClientes.pas' {frmMtoClientes},
  inMtoContadores in 'src\Forms\inMtoContadores.pas' {frmMtoContadores},
  inMtoEmpresas in 'src\Forms\inMtoEmpresas.pas' {frmMtoEmpresas},
  inMtoFamilias in 'src\Forms\inMtoFamilias.pas' {frmMtoFamilias},
  inMtoFormasdePago in 'src\Forms\inMtoFormasdePago.pas' {frmMtoFormasdePago},
  inMtoGeneradorProcesos in 'src\Forms\inMtoGeneradorProcesos.pas' {frmMtoGeneradorProcesos},
  inMtoGenSearch in 'src\Forms\inMtoGenSearch.pas' {frmMtoSearch},
  inMtoEmpleados in 'src\Forms\inMtoEmpleados.pas' {frmMtoEmpleados},
  inMtoGrupos in 'src\Forms\inMtoGrupos.pas' {frmMtoGrupos},
  inMtoIvas in 'src\Forms\inMtoIvas.pas' {frmMtoIvas},
  inMtoIvasGrupos in 'src\Forms\inMtoIvasGrupos.pas' {frmMtoIvasGrupos},
  inMtoProveedores in 'src\Forms\inMtoProveedores.pas' {frmMtoProveedores},
  inMtoTarifas in 'src\Forms\inMtoTarifas.pas' {frmMtoTarifas},
  inMtoUsuarios in 'src\Forms\inMtoUsuarios.pas' {frmMtoUsuarios},
  inMtoUsuariosPerfiles in 'src\Forms\inMtoUsuariosPerfiles.pas' {frmMtoUsuariosPerfiles},
  inMtoPermisos in 'src\Forms\inMtoPermisos.pas' {frmMtoPermisos},
  inMtoPermisosArbol in 'src\Forms\inMtoPermisosArbol.pas' {frmMtoPermisosArbol},
  inMtoModalArtTar in 'src\Modals\inMtoModalArtTar.pas' {frmMtoModalArtTar},
  inMtoModalFacRec in 'src\Modals\inMtoModalFacRec.pas' {frmGenFacRec},
  inMtoModalGenFilter in 'src\Modals\inMtoModalGenFilter.pas' {frmModalGenFilter},
  inMtoModalGenImp in 'src\Modals\inMtoModalGenImp.pas' {frmPrint},
  inMtoModalGenImpEle in 'src\Modals\inMtoModalGenImpEle.pas' {frmMtoModalGenImpEle},
  inMtoModalGenImpSave in 'src\Modals\inMtoModalGenImpSave.pas' {frmModalGenImpSave},
  inMtoModalGuardarFiltro in 'src\Modals\inMtoModalGuardarFiltro.pas' {frmModalGuardarFiltro},
  inMtoModalGestionFiltros in 'src\Modals\inMtoModalGestionFiltros.pas' {frmModalGestionFiltros},
  inMtoModalGuiasBase in 'src\Modals\inMtoModalGuiasBase.pas' {frmModalGuiasBase},
  inMtoModalInformesGuias in 'src\Modals\inMtoModalInformesGuias.pas' {frmModalInformesGuias},
  inMtoModalGridGuias in 'src\Modals\inMtoModalGridGuias.pas' {frmModalGridGuias},
  inMtoModalWizardEditar in 'src\Modals\inMtoModalWizardEditar.pas' {frmModalWizardEditar},
  inMtoModalGenPass in 'src\Modals\inMtoModalGenPass.pas' {frmModalGenPass},
  inMtoModalContrasenaCopia in
    'src\Modals\inMtoModalContrasenaCopia.pas',
  inMtoModalListadoVentas in
    'src\Modals\inMtoModalListadoVentas.pas' {frmModalListadoVentas},
  inMtoModalImpFac in 'src\Modals\inMtoModalImpFac.pas' {frmPrintFac},
  inMtoModalImpRecFac in 'src\Modals\inMtoModalImpRecFac.pas' {frmPrintRecFac},
  inMtoModalImpSesion in 'src\Modals\inMtoModalImpSesion.pas' {frmPrintSesion},
  inMtoModalImpFacCompra in
    'src\Modals\inMtoModalImpFacCompra.pas' {frmPrintFacCompra},
  inMtoModalImpFacCompraV in
    'src\Modals\inMtoModalImpFacCompraV.pas' {frmPrintFacCompraV},
  inMtoModalImpAlbCompra in 'src\Modals\inMtoModalImpAlbCompra.pas' {frmPrintAlbCompra},
  inMtoModalImpAlbCompraV in 'src\Modals\inMtoModalImpAlbCompraV.pas' {frmPrintAlbCompraV},
  inMtoModalEtiqAlb in 'src\Modals\inMtoModalEtiqAlb.pas' {frmPrintEtiqArt: TfrmPrintEtiqAlb},
  inMtoModalEtiqPed in 'src\Modals\inMtoModalEtiqPed.pas' {frmPrintEtiqArt: TfrmPrintEtiqPed},
  inMtoModalImpDevCompra in 'src\Modals\inMtoModalImpDevCompra.pas' {frmPrintDevCompra},
  inMtoModalImpDevCompraV in 'src\Modals\inMtoModalImpDevCompraV.pas' {frmPrintDevCompraV},
  inMtoModalEtiqDev in 'src\Modals\inMtoModalEtiqDev.pas' {frmPrintEtiqArt: TfrmPrintEtiqDev},
  inMtoModalDistribuidor in 'src\Modals\inMtoModalDistribuidor.pas' {frmModalDistribuidor},
  inMtoModalDocsCreados in 'src\Modals\inMtoModalDocsCreados.pas' {frmModalDocsCreados},
  inMtoModalCliEti in 'src\Modals\inMtoModalCliEti.pas' {frmPrintCliEti},
  inMtoModalEtiqArt in 'src\Modals\inMtoModalEtiqArt.pas' {frmPrintEtiqArt},
  inMtoModalImpMultiFiltro in 'src\Modals\inMtoModalImpMultiFiltro.pas' {frmPrintMultiFiltro},
  inMtoModalImpBalanceTallas in 'src\Modals\inMtoModalImpBalanceTallas.pas' {frmPrintBalanceTallas},
  inMtoModalImpBalanceSinTallas in 'src\Modals\inMtoModalImpBalanceSinTallas.pas' {frmPrintBalanceSinTallas},
  inMtoModalImpMovVentasArt in 'src\Modals\inMtoModalImpMovVentasArt.pas' {frmPrintMovVentasArt},
  inMtoModalImpDocsProveedor in 'src\Modals\inMtoModalImpDocsProveedor.pas' {frmPrintDocsProveedor},
  inMtoModalImpEfectosPago in 'src\Modals\inMtoModalImpEfectosPago.pas' {frmPrintEfectosPago},
  inMtoSplash in 'src\Core\inMtoSplash.pas' {frmSplash},
  UniDataConn in 'src\DataModules\UniDataConn.pas' {dmConn: TDataModule},
  UniDataComposicionAplicacion in
    'src\DataModules\UniDataComposicionAplicacion.pas',
  UniDataRepositoriosPantalla in
    'src\DataModules\UniDataRepositoriosPantalla.pas',
  UniDataRepositoriosGeneralesPantalla in
    'src\DataModules\UniDataRepositoriosGeneralesPantalla.pas',
  UniDataRepositoriosCajaPantalla in
    'src\DataModules\UniDataRepositoriosCajaPantalla.pas',
  UniDataGen in 'src\DataModules\UniDataGen.pas' {dmBase: TDataModule},
  UniDataArticulos in 'src\DataModules\UniDataArticulos.pas' {dmArticulos: TdmArticulos},
  UniDataClientes in 'src\DataModules\UniDataClientes.pas' {dmClientes: TdmClientes},
  UniDataContadores in 'src\DataModules\UniDataContadores.pas' {dmContadores: dmContadores},
  UniDataEmpresas in 'src\DataModules\UniDataEmpresas.pas' {dmEmpresas: TdmEmpresas},
  UniDataFamilias in 'src\DataModules\UniDataFamilias.pas' {dmFamilias1. TdmFamilias},
  UniDataFormasdePago in 'src\DataModules\UniDataFormasdePago.pas' {dmFormasdePago: TdmFormasdePago},
  UniDataGeneradorProcesos in 'src\DataModules\UniDataGeneradorProcesos.pas' {dmGeneradorProcesos: TDataModule},
  UniDataEmpleados in 'src\DataModules\UniDataEmpleados.pas' {dmEmpleados: TDataModule},
  UniDataGrupos in 'src\DataModules\UniDataGrupos.pas' {dmGrupos: TDataModule},
  UniDataIvas in 'src\DataModules\UniDataIvas.pas' {dmIvas: TDataModule},
  UniDataIvasGrupos in 'src\DataModules\UniDataIvasGrupos.pas' {dmIvasGrupos: TDataModule},
  UniDataPerfiles in 'src\DataModules\UniDataPerfiles.pas' {dmPerfiles: TDataModule},
  UniDataFiltros in 'src\DataModules\UniDataFiltros.pas' {dmFiltros: TDataModule},
  UniDataProveedores in 'src\DataModules\UniDataProveedores.pas' {dmProveedores: TDataModule},
  UniDataTarifas in 'src\DataModules\UniDataTarifas.pas' {dmTarifas: TDataModule},
  UniDataUsuarios in 'src\DataModules\UniDataUsuarios.pas' {dmUsuarios: TDataModule},
  UniDataUsuariosPerfiles in 'src\DataModules\UniDataUsuariosPerfiles.pas' {dmUsuariosPerfiles: TDataModule},
  UniDataPermisosGrupo in 'src\DataModules\UniDataPermisosGrupo.pas' {dmPermisosGrupo: TDataModule},
  UniDataFacturas in 'src\DataModules\UniDataFacturas.pas' {dmFacturas: TdmFacturas},
  UniDataGenFilter in 'src\DataModules\UniDataGenFilter.pas' {dmGenFilter: TDataModule},
  inMtoPedidos in 'src\Forms\inMtoPedidos.pas' {frmMtoPedidos},
  UniDataPedidos in 'src\DataModules\UniDataPedidos.pas' {/cxButtonHelper in 'cxButtonHelper.pas';: TdmPedidos},
  inMtoPaises in 'src\Forms\inMtoPaises.pas' {frmMtoPaises},
  UniDataPaises in 'src\DataModules\UniDataPaises.pas' {dmPaises: TDataModule},
  inMtoUnidadesMedida in 'src\Forms\inMtoUnidadesMedida.pas' {frmMtoUnidadesMedida},
  UniDataUnidadesMedida in 'src\DataModules\UniDataUnidadesMedida.pas' {dmUnidadesMedida: TDataModule},
  inLibCertificates in 'src\Lib\inLibCertificates.pas',
  inMtoModalEmpCer in 'src\Modals\inMtoModalEmpCer.pas',
  inMtoModalSeriesDocumentos in
    'src\Modals\inMtoModalSeriesDocumentos.pas' {frmModalSeriesDocumentos},
  inMtoCajaMenu in 'src\Caja\Forms\inMtoCajaMenu.pas' {frmMtoMenuCaja},
  inMtoCajaOpe in 'src\Caja\Forms\inMtoCajaOpe.pas' {frmMtoOpeCaja},
  inMtoCajaCierreVentaVcl in
    'src\Caja\Forms\inMtoCajaCierreVentaVcl.pas',
  inMtoCajaEntradaVcl in 'src\Caja\Forms\inMtoCajaEntradaVcl.pas',
  inMtoCajaImpresorVenta in
    'src\Caja\Forms\inMtoCajaImpresorVenta.pas',
  UniDataCaja in 'src\Caja\DataModules\UniDataCaja.pas' {dmCajaOpe},
  UniDataCajaUnidadTrabajo in
    'src\Caja\DataModules\UniDataCajaUnidadTrabajo.pas',
  inMtoTraspasoOpe in 'src\Caja\Forms\inMtoTraspasoOpe.pas' {frmMtoOpeTraspaso},
  inLibTraspasoOpePersistenciaIntf in 'src\Caja\Lib\inLibTraspasoOpePersistenciaIntf.pas',
  UniDataTraspasoOpeRepositorio in 'src\Caja\DataModules\UniDataTraspasoOpeRepositorio.pas',
  UniDataTraspaso in 'src\Caja\DataModules\UniDataTraspaso.pas' {dmTraspaso: TDataModule},
  inLibTraspasoTicketIntf in
    'src\Caja\Lib\inLibTraspasoTicketIntf.pas',
  UniDataTraspasoTicketRepositorio in
    'src\Caja\DataModules\UniDataTraspasoTicketRepositorio.pas',
  inLibTraspasoTicket in 'src\Caja\Lib\inLibTraspasoTicket.pas',
  inLibGridArticulos in 'src\Lib\inLibGridArticulos.pas',
  inLibColumnasSkuIntf in 'src\Lib\inLibColumnasSkuIntf.pas',
  inLibColumnasSku in 'src\Lib\inLibColumnasSku.pas',
  inLibColumnasSkuModoSku in 'src\Lib\inLibColumnasSkuModoSku.pas',
  inLibColumnasSkuModoDesglose in 'src\Lib\inLibColumnasSkuModoDesglose.pas',
  inLibModoTallasIntf in 'src\Lib\inLibModoTallasIntf.pas',
  inLibDistribuidorTallas in 'src\Lib\inLibDistribuidorTallas.pas',
  inLibModoTallasModelo in 'src\Lib\inLibModoTallasModelo.pas',
  inLibModoTallasLineas in 'src\Lib\inLibModoTallasLineas.pas',
  inLibModoTallasConversion in 'src\Lib\inLibModoTallasConversion.pas',
  inLibModoTallasBuscador in 'src\Lib\inLibModoTallasBuscador.pas',
  inLibModoTallasPresentacion in
    'src\Lib\inLibModoTallasPresentacion.pas',
  UniDataModoTallas in 'src\DataModules\UniDataModoTallas.pas',
  UniDataColumnasSkuServicios in
    'src\DataModules\UniDataColumnasSkuServicios.pas',
  inLibColumnasSkuModoTallas in 'src\Lib\inLibColumnasSkuModoTallas.pas',
  inLibLectorScanner in 'src\Lib\inLibLectorScanner.pas',
  inMtoCajaFaseCobro in 'src\Caja\Forms\inMtoCajaFaseCobro.pas' {frmMtoCajaFaseCobro},
  inMtoCajaFormasPago in 'src\Caja\Forms\inMtoCajaFormasPago.pas' {frmMtoCajaFormasPago},
  UniDataCajaFormasPago in 'src\Caja\DataModules\UniDataCajaFormasPago.pas' {dmCajaFormasPago: TdmCajaFormasPago},
  inLibGenBusq in 'src\Lib\inLibGenBusq.pas',
  inLibPreviewExcel in 'src\Lib\inLibPreviewExcel.pas',
  inMtoAlmacenes in 'src\Forms\inMtoAlmacenes.pas' {frmMtoAlmacenes},
  UniDataAlmacenes in 'src\DataModules\UniDataAlmacenes.pas' {dmAlmacenes: TDataModule},
  inMtoModalCajDef in 'src\Modals\inMtoModalCajDef.pas' {frmMtoModalCajDef},
  inLibCajasDefectoPersistenciaIntf in 'src\Lib\inLibCajasDefectoPersistenciaIntf.pas',
  UniDataCajasDefectoRepositorio in 'src\DataModules\UniDataCajasDefectoRepositorio.pas',
  inLibFormManager in 'src\Lib\inLibFormManager.pas',
  inMtoPreviewExcel in 'src\Core\inMtoPreviewExcel.pas' {frmMtoPreviewExcel},
  inLibDevExcel in 'src\Lib\inLibDevExcel.pas',
  inLibdxSpreadSheetStrs_ESP in 'src\Lib\inLibdxSpreadSheetStrs_ESP.pas',
  inMtoCajaReferenciaPago in 'src\Caja\Forms\inMtoCajaReferenciaPago.pas' {frmCajaReferenciaPago},
  inLibFaseCobro in 'src\Caja\Lib\inLibFaseCobro.pas',
  inLibFaseCobroPersistenciaIntf in
    'src\Caja\Lib\inLibFaseCobroPersistenciaIntf.pas',
  UniDataFaseCobroRepositorio in
    'src\Caja\DataModules\UniDataFaseCobroRepositorio.pas',
  inLibCajaVentanasIntf in 'src\Caja\Lib\inLibCajaVentanasIntf.pas',
  inLibCajaDatosFactura in 'src\Caja\Lib\inLibCajaDatosFactura.pas',
  inLibCajaTipos in 'src\Caja\Lib\inLibCajaTipos.pas',
  inLibCajaVentaIntf in 'src\Caja\Lib\inLibCajaVentaIntf.pas',
  inLibCajaVentaCliente in 'src\Caja\Lib\inLibCajaVentaCliente.pas',
  inLibCajaVentaOperacion in
    'src\Caja\Lib\inLibCajaVentaOperacion.pas',
  inLibCajaStock in 'src\Caja\Lib\inLibCajaStock.pas',
  inLibCajaDescuentos in 'src\Caja\Lib\inLibCajaDescuentos.pas',
  UniDataCajaConsultasRepositorio in
    'src\Caja\DataModules\UniDataCajaConsultasRepositorio.pas',
  inLibCajaRectificacion in
    'src\Caja\Lib\inLibCajaRectificacion.pas',
  inLibCajaOpeComposicion in
    'src\Caja\Lib\inLibCajaOpeComposicion.pas',
  inLibCajaEntradaIntf in 'src\Caja\Lib\inLibCajaEntradaIntf.pas',
  inLibCajaEntrada in 'src\Caja\Lib\inLibCajaEntrada.pas',
  inLibCajaCierreVenta in 'src\Caja\Lib\inLibCajaCierreVenta.pas',
  inLibCriptoCurr in 'src\Lib\inLibCriptoCurr.pas',
  inLibJsonSeguro in 'src\Lib\inLibJsonSeguro.pas',
  inLibDivCurr in 'src\Lib\inLibDivCurr.pas',
  inMtoCajaSeleccionVale in 'src\Caja\Forms\inMtoCajaSeleccionVale.pas' {frmMtoCajaSeleccionVale},
  inMtoCajaParam in 'src\Caja\Forms\inMtoCajaParam.pas' {frmMtoCajaParam},
  inLibCajaParam in 'src\Caja\Lib\inLibCajaParam.pas',
  inLibArqueoIntf in 'src\Caja\Lib\inLibArqueoIntf.pas',
  UniDataArqueoRepositorio in
    'src\Caja\DataModules\UniDataArqueoRepositorio.pas',
  inLibArqueoTicketIntf in
    'src\Caja\Lib\inLibArqueoTicketIntf.pas',
  UniDataArqueoTicketRepositorio in
    'src\Caja\DataModules\UniDataArqueoTicketRepositorio.pas',
  inLibTiraCajaTicketIntf in
    'src\Caja\Lib\inLibTiraCajaTicketIntf.pas',
  UniDataTiraCajaTicketRepositorio in
    'src\Caja\DataModules\UniDataTiraCajaTicketRepositorio.pas',
  inLibTicketsCajaIntf in
    'src\Caja\Lib\inLibTicketsCajaIntf.pas',
  UniDataTicketsCajaRepositorio in
    'src\Caja\DataModules\UniDataTicketsCajaRepositorio.pas',
  inLibArqueo in 'src\Caja\Lib\inLibArqueo.pas',
  inLibArqueoTicket in 'src\Caja\Lib\inLibArqueoTicket.pas',
  inLibArqueoPersistencia in 'src\Caja\Lib\inLibArqueoPersistencia.pas',
  UniDataArqueoPersistencia in
    'src\Caja\DataModules\UniDataArqueoPersistencia.pas',
  inLibGenerarTicketCaja in 'src\Caja\Lib\inLibGenerarTicketCaja.pas',
  inLibTiraCajaTicket in 'src\Caja\Lib\inLibTiraCajaTicket.pas',
  inMtoModalArqueo in 'src\Caja\Modals\inMtoModalArqueo.pas' {frmModalArqueo},
  inLibModalArqueoPersistenciaIntf in 'src\Caja\Lib\inLibModalArqueoPersistenciaIntf.pas',
  UniDataModalArqueoRepositorio in 'src\Caja\DataModules\UniDataModalArqueoRepositorio.pas',
  inMtoModalArqueosHistCaja in 'src\Caja\Modals\inMtoModalArqueosHistCaja.pas' {frmModalArqueosHistCaja},
  inMtoModalTiraCaja in 'src\Caja\Modals\inMtoModalTiraCaja.pas' {frmModalTiraCaja},
  inMtoModalImpArqueos in 'src\Caja\Modals\inMtoModalImpArqueos.pas' {frmPrintArqueos},
  inLibInformesCajaPersistenciaIntf in 'src\Caja\Lib\inLibInformesCajaPersistenciaIntf.pas',
  UniDataInformesCajaRepositorio in 'src\Caja\DataModules\UniDataInformesCajaRepositorio.pas',
  inLibGastoCajaPersistenciaIntf in 'src\Caja\Lib\inLibGastoCajaPersistenciaIntf.pas',
  UniDataGastoCajaRepositorio in 'src\Caja\DataModules\UniDataGastoCajaRepositorio.pas',
  inLibEntradaCambioPersistenciaIntf in 'src\Caja\Lib\inLibEntradaCambioPersistenciaIntf.pas',
  UniDataEntradaCambioRepositorio in 'src\Caja\DataModules\UniDataEntradaCambioRepositorio.pas',
  inLibCajaPagosHistPersistenciaIntf in 'src\Caja\Lib\inLibCajaPagosHistPersistenciaIntf.pas',
  UniDataCajaPagosHistRepositorio in 'src\Caja\DataModules\UniDataCajaPagosHistRepositorio.pas',
  inMtoModalImpOperaciones in 'src\Caja\Modals\inMtoModalImpOperaciones.pas' {frmPrintOperaciones},
  inMtoModalImpOperacionesVenta in 'src\Caja\Modals\inMtoModalImpOperacionesVenta.pas' {frmPrintOperacionesVenta},
  inMtoModalImpPagos in 'src\Caja\Modals\inMtoModalImpPagos.pas' {frmPrintPagos},
  inMtoModalImpDepositos in 'src\Caja\Modals\inMtoModalImpDepositos.pas' {frmPrintDepositos},
  inMtoModalEntradaCambio in 'src\Modals\inMtoModalEntradaCambio.pas' {frmModalEntradaCambio},
  inMtoModalGastoCaja in 'src\Caja\Modals\inMtoModalGastoCaja.pas' {frmModalGastoCaja},
  inMtoModalDevolucionTicket in
    'src\Caja\Modals\inMtoModalDevolucionTicket.pas'
    {frmModalDevolucionTicket},
  inMtoModalSeleccionVentaOrigen in
    'src\Caja\Modals\inMtoModalSeleccionVentaOrigen.pas'
    {frmModalSeleccionVentaOrigen},
  inMtoModalMotivoDevolucion in
    'src\Caja\Modals\inMtoModalMotivoDevolucion.pas'
    {frmModalMotivoDevolucion},
  inLibFacturaExcel in 'src\Lib\inLibFacturaExcel.pas',
  inLibDocCompraExcel in 'src\Lib\inLibDocCompraExcel.pas',
  inLibImpuestosComun in 'src\Lib\inLibImpuestosComun.pas',
  inLibComprasImpuestos in 'src\Lib\inLibComprasImpuestos.pas',
  inLibVentasImpuestos in 'src\Lib\inLibVentasImpuestos.pas',
  inLibInventarioExcel in 'src\Lib\inLibInventarioExcel.pas',
  inLibDocumentosTrabajoExcel in 'src\Lib\inLibDocumentosTrabajoExcel.pas',
  inLibBalanceExcelComun in 'src\Lib\inLibBalanceExcelComun.pas',
  inLibBalanceTallasExcel in 'src\Lib\inLibBalanceTallasExcel.pas',
  inLibBalanceSinTallasExcel in 'src\Lib\inLibBalanceSinTallasExcel.pas',
  inLibMovVentasArtExcel in 'src\Lib\inLibMovVentasArtExcel.pas',
  inLibInventarioNube in 'src\Lib\inLibInventarioNube.pas',
  ts.core.sqlparser in 'src\Lib\sqlformatter\ts.core.sqlparser.pas',
  ts.core.sqlscanner in 'src\Lib\sqlformatter\ts.core.sqlscanner.pas',
  ts.core.sqltree in 'src\Lib\sqlformatter\ts.core.sqltree.pas',
  ts.core.utils in 'src\Lib\sqlformatter\ts.core.utils.pas',
  ts.editor.codeformatters in 'src\Lib\sqlformatter\ts.editor.codeformatters.pas',
  ts.editor.codeformatters.sql in 'src\Lib\sqlformatter\ts.editor.codeformatters.sql.pas',
  Backup.Engine in 'src\Lib\backup\Backup.Engine.pas',
  Core_Engine in 'src\Lib\backup\Core_Engine.pas',
  Core_Helpers in 'src\Lib\backup\Core_Helpers.pas',
  Providers_MySQL in 'src\Lib\backup\Providers_MySQL.pas',
  Providers_MySQL_Helpers in 'src\Lib\backup\Providers_MySQL_Helpers.pas',
  Core_Interfaces in 'src\Lib\backup\Core_Interfaces.pas',
  Backup.Types in 'src\Lib\backup\Backup.Types.pas',
  ScriptWriters in 'src\Lib\backup\ScriptWriters.pas',
  inLibEAN13 in 'src\Lib\inLibEAN13.pas',
  Vcl.Themes,
  Vcl.Styles,
  inMtoModalArticulosPropiedades in
    'src\Modals\inMtoModalArticulosPropiedades.pas',
  inLibArticulosVariaciones in 'src\Lib\inLibArticulosVariaciones.pas',
  inLibArticulosAtributosBasicos in
    'src\Lib\inLibArticulosAtributosBasicos.pas',
  inLibArticulosAtributosBasicosIntf in
    'src\Lib\inLibArticulosAtributosBasicosIntf.pas',
  inLibArticulosGuardadoIntf in
    'src\Lib\inLibArticulosGuardadoIntf.pas',
  inLibArticulosGuardado in
    'src\Lib\inLibArticulosGuardado.pas',
  inLibArticulosVisibilidad in
    'src\Lib\inLibArticulosVisibilidad.pas',
  inLibStockConsultaInfo in 'src\Lib\inLibStockConsultaInfo.pas',
  inLibInventariosEntrada in 'src\Lib\inLibInventariosEntrada.pas',
  inLibInventariosEntradaDataSet in
    'src\Lib\inLibInventariosEntradaDataSet.pas',
  inLibInventariosAplicacionIntf in
    'src\Lib\inLibInventariosAplicacionIntf.pas',
  inLibInventariosAplicacion in
    'src\Lib\inLibInventariosAplicacion.pas',
  UniDataStockConsultaInfo in
    'src\DataModules\UniDataStockConsultaInfo.pas',
  inLibStockConsultaPersistenciaIntf in
    'src\Lib\inLibStockConsultaPersistenciaIntf.pas',
  inLibStockConsultaEntradaIntf in
    'src\Lib\inLibStockConsultaEntradaIntf.pas',
  inLibStockConsultaEntrada in
    'src\Lib\inLibStockConsultaEntrada.pas',
  UniDataStockConsultaRepositorio in
    'src\DataModules\UniDataStockConsultaRepositorio.pas',
  inLibImpresionPersistenciaIntf in
    'src\Lib\inLibImpresionPersistenciaIntf.pas',
  UniDataImpresionGuiasEnriquecedor in
    'src\DataModules\UniDataImpresionGuiasEnriquecedor.pas',
  UniDataImpresionRepositorio in
    'src\DataModules\UniDataImpresionRepositorio.pas',
  UniDataInformesGuiasRepositorio in
    'src\DataModules\UniDataInformesGuiasRepositorio.pas',
  inLibAppParamPersistenciaIntf in
    'src\Lib\inLibAppParamPersistenciaIntf.pas',
  UniDataAppParamRepositorio in
    'src\DataModules\UniDataAppParamRepositorio.pas',
  inLibArticulosVariacionesIntf in
    'src\Lib\inLibArticulosVariacionesIntf.pas',
  UniDataArticulosVariaciones in
    'src\DataModules\UniDataArticulosVariaciones.pas',
  inLibArticulosCodigosBarras in 'src\Lib\inLibArticulosCodigosBarras.pas',
  inLibArticulosAltaTarifas in 'src\Lib\inLibArticulosAltaTarifas.pas',
  inLibStockCeldaDocumento in 'src\Lib\inLibStockCeldaDocumento.pas',
  inLibArticulosFiltro in 'src\Lib\inLibArticulosFiltro.pas',
  inMtoModalAceptCancel in 'src\Modals\inMtoModalAceptCancel.pas' {frmModalAceptCancel},
  inMtoModalGenerarSKUs in 'src\Modals\inMtoModalGenerarSKUs.pas' {frmMtoModalGenerarSKUS},
  inLibFTicket in 'src\Lib\inLibFTicket.pas',
  inLibPreviewTicket in 'src\Lib\inLibPreviewTicket.pas',
  inMtoPreviewTicket in 'src\Core\inMtoPreviewTicket.pas' {frmMtoPreviewTicket},
  inLibBuscarImpresora in 'src\Lib\inLibBuscarImpresora.pas',
  DelphiZXIngQRCode in 'src\Lib3par\DelphiZXIngQRCode.pas',
  uDJMSepa in 'src\Lib3par\uDJMSepa.pas',
  uDJMSepa1914XML in 'src\Lib3par\uDJMSepa1914XML.pas',
  uDJMSepa3414XML in 'src\Lib3par\uDJMSepa3414XML.pas',
  inLibGenerarTicket in 'src\Lib\inLibGenerarTicket.pas',
  inLibGenerarTicketIntf in 'src\Lib\inLibGenerarTicketIntf.pas',
  UniDataGenerarTicketRepositorio in
    'src\DataModules\UniDataGenerarTicketRepositorio.pas',
  inLibBusquedaDatosPersistenciaIntf in
    'src\Lib\inLibBusquedaDatosPersistenciaIntf.pas',
  UniDataBusquedaDatosRepositorio in
    'src\DataModules\UniDataBusquedaDatosRepositorio.pas',
  inLibGeneracionSkusPersistenciaIntf in
    'src\Lib\inLibGeneracionSkusPersistenciaIntf.pas',
  UniDataGeneracionSkusRepositorio in
    'src\DataModules\UniDataGeneracionSkusRepositorio.pas',
  inLibDistribuidorPersistenciaIntf in
    'src\Lib\inLibDistribuidorPersistenciaIntf.pas',
  UniDataDistribuidorRepositorio in
    'src\DataModules\UniDataDistribuidorRepositorio.pas',
  inLibMargenPersistenciaIntf in
    'src\Lib\inLibMargenPersistenciaIntf.pas',
  UniDataMargenRepositorio in
    'src\DataModules\UniDataMargenRepositorio.pas',
  inLibDestinosFiltrosPersistenciaIntf in
    'src\Lib\inLibDestinosFiltrosPersistenciaIntf.pas',
  UniDataDestinosFiltrosRepositorio in
    'src\DataModules\UniDataDestinosFiltrosRepositorio.pas',
  inLibFiltroArticulosPersistenciaIntf in
    'src\Lib\inLibFiltroArticulosPersistenciaIntf.pas',
  UniDataFiltroArticulosRepositorio in
    'src\DataModules\UniDataFiltroArticulosRepositorio.pas',
  inLibGuiasPersistenciaIntf in
    'src\Lib\inLibGuiasPersistenciaIntf.pas',
  UniDataGuiasRepositorio in
    'src\DataModules\UniDataGuiasRepositorio.pas',
  inLibDestinoEnvioPersistenciaIntf in
    'src\Lib\inLibDestinoEnvioPersistenciaIntf.pas',
  UniDataDestinoEnvioRepositorio in
    'src\DataModules\UniDataDestinoEnvioRepositorio.pas',
  inLibSeleccionFamiliaPersistenciaIntf in
    'src\Lib\inLibSeleccionFamiliaPersistenciaIntf.pas',
  UniDataSeleccionFamiliaRepositorio in
    'src\DataModules\UniDataSeleccionFamiliaRepositorio.pas',
  inLibSerieFechaFacturaPersistenciaIntf in
    'src\Lib\inLibSerieFechaFacturaPersistenciaIntf.pas',
  UniDataSerieFechaFacturaRepositorio in
    'src\DataModules\UniDataSerieFechaFacturaRepositorio.pas',
  inLibSeleccionAlmacenPersistenciaIntf in
    'src\Lib\inLibSeleccionAlmacenPersistenciaIntf.pas',
  UniDataSeleccionAlmacenRepositorio in
    'src\DataModules\UniDataSeleccionAlmacenRepositorio.pas',
  inLibFacturacionAlbaranesFechasPersistenciaIntf in
    'src\Lib\inLibFacturacionAlbaranesFechasPersistenciaIntf.pas',
  UniDataFacturacionAlbaranesFechasRepositorio in
    'src\DataModules\UniDataFacturacionAlbaranesFechasRepositorio.pas',
  inLibFacturacionAlbaranesCompraPersistenciaIntf in
    'src\Lib\inLibFacturacionAlbaranesCompraPersistenciaIntf.pas',
  UniDataFacturacionAlbaranesCompraRepositorio in
    'src\DataModules\UniDataFacturacionAlbaranesCompraRepositorio.pas',
  inLibCargaEfectosRemesaPersistenciaIntf in
    'src\Lib\inLibCargaEfectosRemesaPersistenciaIntf.pas',
  UniDataCargaEfectosRemesaRepositorio in
    'src\DataModules\UniDataCargaEfectosRemesaRepositorio.pas',
  inLibConsultaFacturasOperacionesPersistenciaIntf in
    'src\Lib\inLibConsultaFacturasOperacionesPersistenciaIntf.pas',
  UniDataConsultaFacturasOperacionesRepositorio in
    'src\DataModules\UniDataConsultaFacturasOperacionesRepositorio.pas',
  inLibSeriesEmpresaPersistenciaIntf in
    'src\Lib\inLibSeriesEmpresaPersistenciaIntf.pas',
  UniDataSeriesEmpresaRepositorio in
    'src\DataModules\UniDataSeriesEmpresaRepositorio.pas',
  inLibEntradaAlbaranVentaPersistenciaIntf in
    'src\Lib\inLibEntradaAlbaranVentaPersistenciaIntf.pas',
  UniDataEntradaAlbaranVentaRepositorio in
    'src\DataModules\UniDataEntradaAlbaranVentaRepositorio.pas',
  inLibClientesPersistenciaIntf in
    'src\Lib\inLibClientesPersistenciaIntf.pas',
  UniDataClientesRepositorio in
    'src\DataModules\UniDataClientesRepositorio.pas',
  inLibSeleccionBancoEmpresaPersistenciaIntf in
    'src\Lib\inLibSeleccionBancoEmpresaPersistenciaIntf.pas',
  UniDataSeleccionBancoEmpresaRepositorio in
    'src\DataModules\UniDataSeleccionBancoEmpresaRepositorio.pas',
  inLibOperacionesCajaSkuPersistenciaIntf in
    'src\Lib\inLibOperacionesCajaSkuPersistenciaIntf.pas',
  UniDataOperacionesCajaSkuRepositorio in
    'src\DataModules\UniDataOperacionesCajaSkuRepositorio.pas',
  inLibListadoVentasPersistenciaIntf in
    'src\Lib\inLibListadoVentasPersistenciaIntf.pas',
  UniDataListadoVentasRepositorio in
    'src\DataModules\UniDataListadoVentasRepositorio.pas',
  inLibFacturacionTicketPersistenciaIntf in
    'src\Lib\inLibFacturacionTicketPersistenciaIntf.pas',
  UniDataFacturacionTicketRepositorio in
    'src\DataModules\UniDataFacturacionTicketRepositorio.pas',
  UniDataCargaMasivaArticulosRepositorio in
    'src\DataModules\UniDataCargaMasivaArticulosRepositorio.pas',
  inLibGenerarTicketBD in 'src\Lib\inLibGenerarTicketBD.pas',
  inLibCorreoTickets in 'src\Lib\inLibCorreoTickets.pas',
  inLibFactuzamApi in 'src\Lib\inLibFactuzamApi.pas',
  inLibTraduccionesDescarga in
    'src\Lib\inLibTraduccionesDescarga.pas',
  inLibVentasWsJsonIntf in 'src\Lib\inLibVentasWsJsonIntf.pas',
  inLibVentasWsJson in 'src\Lib\inLibVentasWsJson.pas',
  UniDataVentasWsJson in 'src\DataModules\UniDataVentasWsJson.pas',
  inLibVentasWsColaIntf in 'src\Lib\inLibVentasWsColaIntf.pas',
  UniDataVentasWsCola in 'src\DataModules\UniDataVentasWsCola.pas',
  UniDataVentasWsSesion in 'src\DataModules\UniDataVentasWsSesion.pas',
  inLibVentasWsCola in 'src\Lib\inLibVentasWsCola.pas',
  inLibXades in 'src\Lib\inLibXades.pas',
  inLibDocumentoFiscal in 'src\Lib\inLibDocumentoFiscal.pas',
  inLibRelojFiscal in 'src\Lib\inLibRelojFiscal.pas',
  inLibFacturaePersistenciaIntf in
    'src\Lib\inLibFacturaePersistenciaIntf.pas',
  UniDataFacturaeRepositorio in
    'src\DataModules\UniDataFacturaeRepositorio.pas',
  inLibFacturae in 'src\Lib\inLibFacturae.pas',
  inLibVerifactuNoVerifactuExportIntf in
    'src\verifactu\inLibVerifactuNoVerifactuExportIntf.pas',
  UniDataVerifactuNoVerifactuExport in
    'src\verifactu\UniDataVerifactuNoVerifactuExport.pas',
  inLibVerifactuNoVerifactuExport in 'src\Lib\inLibVerifactuNoVerifactuExport.pas',
  inLibVerifactuNoVerifactuVerify in 'src\Lib\inLibVerifactuNoVerifactuVerify.pas',
  inLibVerifactuInstalacion in 'src\verifactu\inLibVerifactuInstalacion.pas',
  inLibVerifactuTipos in 'src\verifactu\inLibVerifactuTipos.pas',
  inLibVerifactu in 'src\verifactu\inLibVerifactu.pas',
  inLibVerifactuEnvio in 'src\verifactu\inLibVerifactuEnvio.pas',
  inLibVerifactuColaIntf in
    'src\verifactu\inLibVerifactuColaIntf.pas',
  inLibVerifactuCola in 'src\verifactu\inLibVerifactuCola.pas',
  UniDataVerifactuColaRepositorio in
    'src\verifactu\UniDataVerifactuColaRepositorio.pas',
  inLibVerifactuEsquemaIntf in
    'src\verifactu\inLibVerifactuEsquemaIntf.pas',
  UniDataVerifactuEsquema in
    'src\verifactu\UniDataVerifactuEsquema.pas',
  UniDataVerifactuColaProcesador in
    'src\verifactu\UniDataVerifactuColaProcesador.pas',
  UniDataVerifactuColaResultados in
    'src\verifactu\UniDataVerifactuColaResultados.pas',
  inLibVerifactuReintentos in
    'src\verifactu\inLibVerifactuReintentos.pas',
  UniDataVerifactuColaOperaciones in
    'src\verifactu\UniDataVerifactuColaOperaciones.pas',
  inLibEmisionFiscalIntf in
    'src\verifactu\inLibEmisionFiscalIntf.pas',
  inLibEmisionFiscal in 'src\verifactu\inLibEmisionFiscal.pas',
  inMtoVerifactuCola in 'src\verifactu\inMtoVerifactuCola.pas' {frmMtoVerifactuCola},
  UniDataVerifactuCola in 'src\verifactu\UniDataVerifactuCola.pas' {dmVerifactuCola: TDataModule},
  inMtoVerifactuLog in 'src\verifactu\inMtoVerifactuLog.pas' {frmMtoVerifactuLog},
  UniDataVerifactuLog in 'src\verifactu\UniDataVerifactuLog.pas' {dmVerifactuLog: TDataModule},
  inMtoModalVerifactuDecl in 'src\Modals\inMtoModalVerifactuDecl.pas' {frmModalVerifactuDecl},
  inMtoModalDescargaTraduccion in
    'src\Modals\inMtoModalDescargaTraduccion.pas' {frmModalDescargaTraduccion},
  inMtoModalFacturarTicket in 'src\Modals\inMtoModalFacturarTicket.pas' {frmModalFacturarTicket},
  inMtoModalSerieFechaFactura in 'src\Modals\inMtoModalSerieFechaFactura.pas' {frmModalSerieFechaFactura},
  inLibData in 'src\Lib\inLibData.pas',
  inLibAppParam in 'src\Lib\inLibAppParam.pas',
  inLibUnidadesMedida in 'src\Lib\inLibUnidadesMedida.pas',
  inLibGridCantidad in 'src\Lib\inLibGridCantidad.pas',
  inMtoAppParam in 'src\Core\inMtoAppParam.pas' {frmMtoAppParam},
  inLibPathTokens in 'src\Lib\inLibPathTokens.pas',
  uGenericIfThen in 'src\Lib\uGenericIfThen.pas',
  UniDataConsultaOpe in 'src\DataModules\UniDataConsultaOpe.pas' {dmConsultaOpe: TDataModule},
  inMtoConsultaOpe in 'src\Forms\inMtoConsultaOpe.pas' {frmConsultaOpe},
  inLibVentasCalendarioIntf in 'src\Lib\inLibVentasCalendarioIntf.pas',
  UniDataVentasCalendario in
    'src\DataModules\UniDataVentasCalendario.pas',
  inLibVentasCalendario in 'src\Lib\inLibVentasCalendario.pas',
  inLibLayoutForm in 'src\Lib\inLibLayoutForm.pas',
  inMtoInventarios in 'src\Forms\inMtoInventarios.pas' {frmMtoInventarios},
  inMtoInventariosEntradaVcl in
    'src\Forms\inMtoInventariosEntradaVcl.pas',
  UniDataInventarios in 'src\DataModules\UniDataInventarios.pas' {dmInventarios: TDataModule},
  inMtoAtributosConjuntos in 'src\Forms\inMtoAtributosConjuntos.pas' {frmMtoAtributosConjuntos},
  UniDataAtributosConjuntos in 'src\DataModules\UniDataAtributosConjuntos.pas' {dmAtributosConjuntos: TDataModule},
  inMtoAtributosBasicos in 'src\Forms\inMtoAtributosBasicos.pas' {frmMtoAtributosBasicos},
  UniDataAtributosBasicos in 'src\DataModules\UniDataAtributosBasicos.pas' {dmAtributosBasicos: TDataModule},
  inMtoVariaciones in 'src\Forms\inMtoVariaciones.pas' {frmMtoVariaciones},
  UniDataVariaciones in 'src\DataModules\UniDataVariaciones.pas' {dmVariaciones: TdmVariaciones},
  inMtoPropiedades in 'src\Forms\inMtoPropiedades.pas' {frmMtoPropiedades},
  UniDataPropiedades in 'src\DataModules\UniDataPropiedades.pas' {dmPropiedades: TDataModule},
  inMtoPropiedadesValores in 'src\Forms\inMtoPropiedadesValores.pas' {frmMtoPropiedadesValores},
  UniDataPropiedadesValores in 'src\DataModules\UniDataPropiedadesValores.pas' {dmPropiedadesValores: TDataModule},
  inMtoMovimientosAlmacen in 'src\Forms\inMtoMovimientosAlmacen.pas' {frmMtoMovimientosAlmacen},
  UniDataMovimientosAlmacen in 'src\DataModules\UniDataMovimientosAlmacen.pas' {dmMovimientosAlmacen: TDataModule},
  inMtoDocumentosTrabajo in 'src\Forms\inMtoDocumentosTrabajo.pas' {frmMtoDocumentosTrabajo},
  UniDataDocumentosTrabajo in 'src\DataModules\UniDataDocumentosTrabajo.pas' {dmDocumentosTrabajo: TdmDocumentosTrabajo},
  inMtoDepositosCliente in 'src\Forms\inMtoDepositosCliente.pas' {frmMtoDepositosCliente},
  UniDataDepositosCliente in 'src\DataModules\UniDataDepositosCliente.pas' {dmDepositosCliente: TDataModule},
  inMtoAlbaranes in 'src\Forms\inMtoAlbaranes.pas' {frmMtoAlbaranes},
  inMtoDocumento in 'src\Forms\inMtoDocumento.pas',
  UniDataAlbaranes in 'src\DataModules\UniDataAlbaranes.pas' {dmAlbaranes: TdmAlbaranes},
  inMtoAlbaranesCompra in 'src\Forms\inMtoAlbaranesCompra.pas' {frmMtoAlbaranesCompra},
  UniDataAlbaranesCompra in 'src\DataModules\UniDataAlbaranesCompra.pas' {dmAlbaranesCompra: TdmAlbaranesCompra},
  UniDataAlbaranesCompraMovimientos in
    'src\DataModules\UniDataAlbaranesCompraMovimientos.pas',
  UniDataDevolucionesCompraMovimientos in
    'src\DataModules\UniDataDevolucionesCompraMovimientos.pas',
  inMtoDevolucionesCompra in 'src\Forms\inMtoDevolucionesCompra.pas' {frmMtoDevolucionesCompra},
  UniDataDevolucionesCompra in 'src\DataModules\UniDataDevolucionesCompra.pas' {dmDevolucionesCompra: TdmDevolucionesCompra},
  inMtoFacturasCompra in 'src\Forms\inMtoFacturasCompra.pas' {frmMtoFacturasCompra},
  UniDataFacturasCompra in 'src\DataModules\UniDataFacturasCompra.pas' {dmFacturasCompra: TdmFacturasCompra},
  inMtoEfectosCompra in 'src\Forms\inMtoEfectosCompra.pas' {frmMtoEfectosCompra},
  UniDataEfectosCompra in 'src\DataModules\UniDataEfectosCompra.pas' {dmEfectosCompra: TdmEfectosCompra},
  inMtoRemesasCompra in 'src\Forms\inMtoRemesasCompra.pas' {frmMtoRemesasCompra},
  UniDataRemesasCompra in 'src\DataModules\UniDataRemesasCompra.pas' {dmRemesasCompra: TdmRemesasCompra},
  inMtoEfectosVenta in 'src\Forms\inMtoEfectosVenta.pas' {frmMtoEfectosVenta},
  UniDataEfectosVenta in 'src\DataModules\UniDataEfectosVenta.pas' {dmEfectosVenta: TdmEfectosVenta},
  inMtoRemesasVenta in 'src\Forms\inMtoRemesasVenta.pas' {frmMtoRemesasVenta},
  UniDataRemesasVenta in 'src\DataModules\UniDataRemesasVenta.pas' {dmRemesasVenta: TdmRemesasVenta},
  inMtoModalFacturarAlbaranes in 'src\Modals\inMtoModalFacturarAlbaranes.pas' {frmModalFacturarAlbaranes},
  inMtoModalCargarEfectosRemesa in 'src\Modals\inMtoModalCargarEfectosRemesa.pas' {frmModalCargarEfectosRemesa},
  inMtoModalSeleccionarBanco in 'src\Modals\inMtoModalSeleccionarBanco.pas' {frmModalSeleccionarBanco},
  inMtoModalRegistrarPago in 'src\Modals\inMtoModalRegistrarPago.pas' {frmModalRegistrarPago},
  inMtoModalSepaRemesaVenta in 'src\Modals\inMtoModalSepaRemesaVenta.pas',
  inMtoPedidosCompra in 'src\Forms\inMtoPedidosCompra.pas' {frmMtoPedidosCompra},
  UniDataPedidosCompra in 'src\DataModules\UniDataPedidosCompra.pas' {dmPedidosCompra: TdmPedidosCompra},
  UniDataPedidosCompraPendientes in
    'src\DataModules\UniDataPedidosCompraPendientes.pas',
  UniDataPedidosCompraAlbaranComun in
    'src\DataModules\UniDataPedidosCompraAlbaranComun.pas',
  UniDataPedidosCompraCreacionAlbaran in
    'src\DataModules\UniDataPedidosCompraCreacionAlbaran.pas',
  UniDataPedidosCompraIncorporacionAlbaran in
    'src\DataModules\UniDataPedidosCompraIncorporacionAlbaran.pas',
  UniDataPedidosCompraRecepcion in
    'src\DataModules\UniDataPedidosCompraRecepcion.pas',
  UniDataPedidosCompraOperaciones in
    'src\DataModules\UniDataPedidosCompraOperaciones.pas',
  inMtoModalSelAlmacenPedido in 'src\Modals\inMtoModalSelAlmacenPedido.pas' {frmModalSelAlmacenPedido},
  inMtoModalSelAlmacenAlbaran in 'src\Modals\inMtoModalSelAlmacenAlbaran.pas' {frmModalSelAlmacenAlbaran},
  inLibPedidosCompraIntf in 'src\Lib\inLibPedidosCompraIntf.pas',
  inLibPedidosCompraRecepcionIntf in
    'src\Lib\inLibPedidosCompraRecepcionIntf.pas',
  inLibPedidosCompra in 'src\Lib\inLibPedidosCompra.pas',
  inLibGridPivoteCompraPersistenciaIntf in
    'src\Lib\inLibGridPivoteCompraPersistenciaIntf.pas',
  inLibGridPivoteCompraTipos in
    'src\Lib\inLibGridPivoteCompraTipos.pas',
  inLibPivoteCompraCalculo in
    'src\Lib\inLibPivoteCompraCalculo.pas',
  inLibPivoteCompraCorrespondencia in
    'src\Lib\inLibPivoteCompraCorrespondencia.pas',
  inLibPivoteCompraEstadoEdicion in
    'src\Lib\inLibPivoteCompraEstadoEdicion.pas',
  inLibPivoteCompraValidacion in
    'src\Lib\inLibPivoteCompraValidacion.pas',
  inLibGridPivoteCompraPresentacion in
    'src\Lib\inLibGridPivoteCompraPresentacion.pas',
  inLibGridPivoteCompraEdicion in
    'src\Lib\inLibGridPivoteCompraEdicion.pas',
  UniDataGridPivoteCompraRepositorio in
    'src\DataModules\UniDataGridPivoteCompraRepositorio.pas',
  inLibGridPivoteCompra in 'src\Lib\inLibGridPivoteCompra.pas',
  inLibGridPivoteVenta in 'src\Lib\inLibGridPivoteVenta.pas',
  inLibPivoteVentaCalculo in 'src\Lib\inLibPivoteVentaCalculo.pas',
  inLibPivoteVentaIntf in 'src\Lib\inLibPivoteVentaIntf.pas',
  inLibPivoteVentaComposicionIntf in
    'src\Lib\inLibPivoteVentaComposicionIntf.pas',
  inLibPivoteVentaModelo in 'src\Lib\inLibPivoteVentaModelo.pas',
  inLibGridPivoteVentaVista in
    'src\Lib\inLibGridPivoteVentaVista.pas',
  inLibGridPivoteVentaPresentacion in
    'src\Lib\inLibGridPivoteVentaPresentacion.pas',
  UniDataPivoteVenta in 'src\DataModules\UniDataPivoteVenta.pas',
  inMtoModalFacturarAlbaranesFechas in 'src\Modals\inMtoModalFacturarAlbaranesFechas.pas' {frmModalFacturarAlbaranesFechas},
  inMtoCajaOperacionesHist in 'src\Caja\Forms\inMtoCajaOperacionesHist.pas' {frmMtoCajaOperacionesHist},
  UniDataCajaOperacionesHist in 'src\Caja\DataModules\UniDataCajaOperacionesHist.pas' {dmCajaOperacionesHist: TDataModule},
  inLibCajaOperacionesHistPersistenciaIntf in 'src\Caja\Lib\inLibCajaOperacionesHistPersistenciaIntf.pas',
  UniDataCajaOperacionesHistRepositorio in 'src\Caja\DataModules\UniDataCajaOperacionesHistRepositorio.pas',
  inMtoCajaArqueosHist in 'src\Caja\Forms\inMtoCajaArqueosHist.pas' {frmMtoCajaArqueosHist},
  UniDataCajaArqueosHist in 'src\Caja\DataModules\UniDataCajaArqueosHist.pas' {dmCajaArqueosHist: TDataModule},
  inMtoCajaPagosHist in 'src\Caja\Forms\inMtoCajaPagosHist.pas' {frmMtoCajaPagosHist},
  UniDataCajaPagosHist in 'src\Caja\DataModules\UniDataCajaPagosHist.pas' {dmCajaPagosHist: TDataModule},
  inMtoCajaValesHist in 'src\Caja\Forms\inMtoCajaValesHist.pas' {frmMtoCajaValesHist},
  UniDataCajaValesHist in 'src\Caja\DataModules\UniDataCajaValesHist.pas' {dmCajaValesHist: TDataModule},
  inMtoModalAddBlockBase in 'src\Modals\inMtoModalAddBlockBase.pas' {frmModalAddBlockBase},
  inMtoModalAddBlockInventario in 'src\Modals\inMtoModalAddBlockInventario.pas' {frmModalAddBlockInventario},
  inMtoModalAddBlockTarifa in 'src\Modals\inMtoModalAddBlockTarifa.pas' {frmModalAddBlockTarifa},
  inMtoModalAddBlockDocumentoTrabajo in 'src\Modals\inMtoModalAddBlockDocumentoTrabajo.pas' {frmModalAddBlockDocumentoTrabajo},
  inMtoModalEnviarDestino in 'src\Modals\inMtoModalEnviarDestino.pas' {frmModalEnviarDestino},
  inLibDBStructure in 'src\Lib\inLibDBStructure.pas',
  inLibBackupWorker in 'src\Lib\inLibBackupWorker.pas',
  inLibCopiasSeguridadIntf in
    'src\Lib\inLibCopiasSeguridadIntf.pas',
  inLibCopiasSeguridadReglas in
    'src\Lib\inLibCopiasSeguridadReglas.pas',
  inLibCopiasSeguridad in 'src\Lib\inLibCopiasSeguridad.pas',
  inLibOperacionesAplicacionIntf in
    'src\Lib\inLibOperacionesAplicacionIntf.pas',
  inLibCoordinadorOperacionesAplicacion in
    'src\Lib\inLibCoordinadorOperacionesAplicacion.pas',
  UniDataCopiasSeguridad in
    'src\DataModules\UniDataCopiasSeguridad.pas',
  inMtoRestauracionCopiasVcl in
    'src\Core\inMtoRestauracionCopiasVcl.pas',
  inLibRestauracionCopiasConexionIntf in
    'src\Lib\inLibRestauracionCopiasConexionIntf.pas',
  inLibRestauracionCopiasConexion in
    'src\Lib\inLibRestauracionCopiasConexion.pas',
  UniDataRestauracionCopiasConexion in
    'src\DataModules\UniDataRestauracionCopiasConexion.pas',
  inMtoLogonRestauracionVcl in
    'src\Core\inMtoLogonRestauracionVcl.pas',
  inLibFusionEfectosIntf in
    'src\Lib\inLibFusionEfectosIntf.pas',
  inLibFusionEfectos in
    'src\Lib\inLibFusionEfectos.pas',
  UniDataFusionEfectos in
    'src\DataModules\UniDataFusionEfectos.pas',
  inMtoFusionEfectosVcl in
    'src\Forms\inMtoFusionEfectosVcl.pas',
  inLibImportacionPedidosIntf in
    'src\Lib\inLibImportacionPedidosIntf.pas',
  inLibImportacionPedidos in
    'src\Lib\inLibImportacionPedidos.pas',
  inLibPrestaShopPedidosAdaptador in
    'src\Lib\inLibPrestaShopPedidosAdaptador.pas',
  UniDataImportacionPedidos in
    'src\DataModules\UniDataImportacionPedidos.pas',
  inMtoImportacionPedidosVcl in
    'src\Modals\inMtoImportacionPedidosVcl.pas',
  UniDataComprasSesiones in 'src\DataModules\UniDataComprasSesiones.pas' {dmComprasSesiones: TdmComprasSesiones},
  UniDataComprasSesionesRepositorio in
    'src\DataModules\UniDataComprasSesionesRepositorio.pas',
  UniDataComprasSesionesMaterializacionRepositorio in
    'src\DataModules\UniDataComprasSesionesMaterializacionRepositorio.pas',
  UniDataComprasSesionesOperaciones in
    'src\DataModules\UniDataComprasSesionesOperaciones.pas',
  UniDataComprasSesionesAlbaranes in
    'src\DataModules\UniDataComprasSesionesAlbaranes.pas',
  UniDataComprasSesionesArticulos in
    'src\DataModules\UniDataComprasSesionesArticulos.pas',
  UniDataComprasSesionesComposicion in
    'src\DataModules\UniDataComprasSesionesComposicion.pas',
  UniDataComprasSesionesLecturasComposicion in
    'src\DataModules\UniDataComprasSesionesLecturasComposicion.pas',
  UniDataComprasSesionesDocumentosComun in
    'src\DataModules\UniDataComprasSesionesDocumentosComun.pas',
  UniDataComprasSesionesEstado in
    'src\DataModules\UniDataComprasSesionesEstado.pas',
  UniDataComprasSesionesMaterializar in
    'src\DataModules\UniDataComprasSesionesMaterializar.pas',
  UniDataComprasSesionesPedidos in
    'src\DataModules\UniDataComprasSesionesPedidos.pas',
  UniDataComprasSesionesReversion in
    'src\DataModules\UniDataComprasSesionesReversion.pas',
  UniDataComprasSesionesUnidadTrabajo in
    'src\DataModules\UniDataComprasSesionesUnidadTrabajo.pas',
  UniDataCatalogoSqlAplicacion in
    'src\DataModules\UniDataCatalogoSqlAplicacion.pas',
  inMtoComprasPlantillas in 'src\Forms\inMtoComprasPlantillas.pas' {frmMtoComprasPlantillas},
  inMtoModalSesionMaterializar in 'src\Modals\inMtoModalSesionMaterializar.pas' {frmModalSesionMaterializar},
  inMtoModalSesionDuplicado in 'src\Modals\inMtoModalSesionDuplicado.pas' {frmModalSesionDuplicado},
  inMtoModalRepetirModelo in 'src\Modals\inMtoModalRepetirModelo.pas' {frmModalRepetirModelo},
  inMtoModalIncidencias in 'src\Modals\inMtoModalIncidencias.pas' {frmModalIncidencias},
  inMtoModalCrearAlbaranSesion in 'src\Modals\inMtoModalCrearAlbaranSesion.pas' {frmModalCrearAlbaranSesion},
  inLibComprasSesiones in 'src\Lib\inLibComprasSesiones.pas',
  inLibComprasSesionesIntf in 'src\Lib\inLibComprasSesionesIntf.pas',
  inLibComprasSesionesCreacion in
    'src\Lib\inLibComprasSesionesCreacion.pas',
  inLibComprasSesionesCreacionDataSet in
    'src\Lib\inLibComprasSesionesCreacionDataSet.pas',
  inLibComprasSesionesAplicacionIntf in
    'src\Lib\inLibComprasSesionesAplicacionIntf.pas',
  inLibComprasSesionesAplicacion in
    'src\Lib\inLibComprasSesionesAplicacion.pas',
  inLibComprasSesionesMaterializacionIntf in
    'src\Lib\inLibComprasSesionesMaterializacionIntf.pas',
  inLibComprasSesionesLecturasIntf in
    'src\Lib\inLibComprasSesionesLecturasIntf.pas',
  inLibComprasSesionesReglas in 'src\Lib\inLibComprasSesionesReglas.pas',
  inLibGridTallasInline in 'src\Lib\inLibGridTallasInline.pas',
  inLibColumnasDocumento in 'src\Lib\inLibColumnasDocumento.pas',
  inLibBusquedasCompra in 'src\Lib\inLibBusquedasCompra.pas',
  inLibValidacionDocumento in
    'src\Lib\inLibValidacionDocumento.pas',
  inLibPresentacionDocumento in
    'src\Lib\inLibPresentacionDocumento.pas',
  inLibComprasSesionesMaterializar in 'src\Lib\inLibComprasSesionesMaterializar.pas',
  inLibAlbaranesCompraMovimientos in 'src\Lib\inLibAlbaranesCompraMovimientos.pas',
  inLibAlbaranesCompraMovimientosIntf in
    'src\Lib\inLibAlbaranesCompraMovimientosIntf.pas',
  inLibDevolucionesCompraMovimientos in 'src\Lib\inLibDevolucionesCompraMovimientos.pas',
  inLibDevolucionesCompraMovimientosIntf in
    'src\Lib\inLibDevolucionesCompraMovimientosIntf.pas',
  inLibContadorLineas in 'src\Lib\inLibContadorLineas.pas',
  UniDataContadorLineasRepositorio in
    'src\DataModules\UniDataContadorLineasRepositorio.pas',
  inMtoModalAltaRapida in 'src\Modals\inMtoModalAltaRapida.pas' {frmMtoModalAltaRapida},
  inLibArticulosValidadorIntf in
    'src\Lib\inLibArticulosValidadorIntf.pas',
  UniDataArticulosValidadorRepositorio in
    'src\DataModules\UniDataArticulosValidadorRepositorio.pas',
  inLibArticulosResolverIntf in
    'src\Lib\inLibArticulosResolverIntf.pas',
  UniDataArticulosResolverRepositorio in
    'src\DataModules\UniDataArticulosResolverRepositorio.pas',
  inLibAplicacionArticuloCompraIntf in
    'src\Lib\inLibAplicacionArticuloCompraIntf.pas',
  inLibAplicacionArticuloCompra in
    'src\Lib\inLibAplicacionArticuloCompra.pas',
  UniDataAplicacionArticuloCompra in
    'src\DataModules\UniDataAplicacionArticuloCompra.pas',
  UniDataDocsProveedorSql in
    'src\DataModules\UniDataDocsProveedorSql.pas',
  UniDataDocsProveedor in 'src\DataModules\UniDataDocsProveedor.pas',
  inLibArticulosResolver in 'src\Lib\inLibArticulosResolver.pas',
  inMtoModalAddPreciosTar in 'src\Modals\inMtoModalAddPreciosTar.pas' {frmMtoModalAddPreciosTar},
  inMtoModalCalcularMargen in 'src\Modals\inMtoModalCalcularMargen.pas' {frmModalCalcularMargen},
  inLibArticulosAtributosIntf in
    'src\Lib\inLibArticulosAtributosIntf.pas',
  UniDataArticulosAtributosRepositorio in
    'src\DataModules\UniDataArticulosAtributosRepositorio.pas',
  inLibArticulosPropiedadesPersistenciaIntf in
    'src\Lib\inLibArticulosPropiedadesPersistenciaIntf.pas',
  UniDataArticulosPropiedadesRepositorio in
    'src\DataModules\UniDataArticulosPropiedadesRepositorio.pas',
  UniDataArticulosAtributosBasicosRepositorio in
    'src\DataModules\UniDataArticulosAtributosBasicosRepositorio.pas',
  inLibAtributosPaleta in 'src\Lib\inLibAtributosPaleta.pas',
  inLibAtributosPaletaIntf in 'src\Lib\inLibAtributosPaletaIntf.pas',
  UniDataAtributosPaletaRepositorio in
    'src\DataModules\UniDataAtributosPaletaRepositorio.pas',
  inMtoModalScriptLog in 'src\Modals\inMtoModalScriptLog.pas' {frmMtoModalScriptLog},
  inLibPresta in 'src\Lib\inLibPresta.pas',
  inLibScanDateTime in 'src\Lib\inLibScanDateTime.pas',
  inMtoModalImportarPedidosPS in 'src\Modals\inMtoModalImportarPedidosPS.pas' {frmModalImportarPedidosPS},
  inLibPrestaImporter in 'src\Lib\inLibPrestaImporter.pas',
  inMtoModalSelFamilia in 'src\Modals\inMtoModalSelFamilia.pas' {frmModalSelFamilia},
  inLibFotosPersistenciaIntf in
    'src\Lib\inLibFotosPersistenciaIntf.pas',
  inLibFotosTipos in 'src\Lib\inLibFotosTipos.pas',
  inLibFotosConsulta in 'src\Lib\inLibFotosConsulta.pas',
  inLibFotosAlmacenamiento in
    'src\Lib\inLibFotosAlmacenamiento.pas',
  inLibFotosEdicion in 'src\Lib\inLibFotosEdicion.pas',
  inLibFotosSesion in 'src\Lib\inLibFotosSesion.pas',
  inLibFotosPresentacion in 'src\Lib\inLibFotosPresentacion.pas',
  UniDataFotosRepositorio in
    'src\DataModules\UniDataFotosRepositorio.pas',
  inLibFotos in 'src\Lib\inLibFotos.pas',
  inLibDocumentosTrabajo in 'src\Lib\inLibDocumentosTrabajo.pas',
  inLibDocumentosTrabajoPresentacion in
    'src\Lib\inLibDocumentosTrabajoPresentacion.pas',
  UniDataDocumentosTrabajoRepositorio in
    'src\DataModules\UniDataDocumentosTrabajoRepositorio.pas',
  inLibImagen in 'src\Lib\inLibImagen.pas',
  inLibFotosNube in 'src\Lib\inLibFotosNube.pas',
  inMtoFotoArticulo in 'src\Forms\inMtoFotoArticulo.pas' {frmFotoArticulo},
  inMtoStockConsulta in 'src\Forms\inMtoStockConsulta.pas' {frmStockConsulta},
  inMtoStockConsultaEntradaVcl in
    'src\Forms\inMtoStockConsultaEntradaVcl.pas',
  inMtoModalOperacionesCajaSku in
    'src\Modals\inMtoModalOperacionesCajaSku.pas'
    {frmModalOperacionesCajaSku},
  inMtoModalFotoArticulo in 'src\Modals\inMtoModalFotoArticulo.pas',
  inMtoModalFiltroArt in 'src\Modals\inMtoModalFiltroArt.pas',
  inMtoComprasSesiones in 'src\Forms\inMtoComprasSesiones.pas' {frmMtoComprasSesiones},
  inMtoComprasSesionesMaterializacionVcl in
    'src\Forms\inMtoComprasSesionesMaterializacionVcl.pas',
  UniDataTarifasCambios in 'src\DataModules\UniDataTarifasCambios.pas' {dmTarifasCambios: TdmTarifasCambios},
  inMtoModalCargarSesionTarifa in 'src\Modals\inMtoModalCargarSesionTarifa.pas' {frmModalCargarSesionTarifa},
  inMtoTarifasCambios in 'src\Forms\inMtoTarifasCambios.pas' {frmMtoTarifasCambios},
  inMtoCajaOpePresentacionVcl in
    'src\Caja\Forms\inMtoCajaOpePresentacionVcl.pas',
  inLibCajaOpePresentacion in 'src\Caja\Lib\inLibCajaOpePresentacion.pas',
  inLibCajaOpePresentacionIntf in
    'src\Caja\Lib\inLibCajaOpePresentacionIntf.pas',
  UniDataArticulosPresentacionRepositorio in
    'src\DataModules\UniDataArticulosPresentacionRepositorio.pas',
  UniDataFacturasListado in 'src\DataModules\UniDataFacturasListado.pas',
  UniDataInventariosBusquedas in
    'src\DataModules\UniDataInventariosBusquedas.pas',
  inMtoArticulosPresentacionAtributos in
    'src\Forms\inMtoArticulosPresentacionAtributos.pas',
  inMtoArticulosPresentacionFiltros in
    'src\Forms\inMtoArticulosPresentacionFiltros.pas',
  inMtoArticulosPresentacionStock in
    'src\Forms\inMtoArticulosPresentacionStock.pas',
  inMtoArticulosPresentacionTarifas in
    'src\Forms\inMtoArticulosPresentacionTarifas.pas',
  inMtoComprasSesionesPresentacionCopiaLineas in
    'src\Forms\inMtoComprasSesionesPresentacionCopiaLineas.pas',
  inMtoComprasSesionesPresentacionMaterializacion in
    'src\Forms\inMtoComprasSesionesPresentacionMaterializacion.pas',
  inMtoComprasSesionesPresentacionModelo in
    'src\Forms\inMtoComprasSesionesPresentacionModelo.pas',
  inMtoComprasSesionesPresentacionPlanificador in
    'src\Forms\inMtoComprasSesionesPresentacionPlanificador.pas',
  inMtoComprasSesionesPresentacionProveedor in
    'src\Forms\inMtoComprasSesionesPresentacionProveedor.pas',
  inMtoComprasSesionesPresentacionTallas in
    'src\Forms\inMtoComprasSesionesPresentacionTallas.pas',
  inMtoFacturasPresentadorCabeceraVcl in
    'src\Forms\inMtoFacturasPresentadorCabeceraVcl.pas',
  inMtoFacturasPresentadorLineasVcl in
    'src\Forms\inMtoFacturasPresentadorLineasVcl.pas',
  inMtoInventariosPresentacionBusquedas in
    'src\Forms\inMtoInventariosPresentacionBusquedas.pas',
  inMtoInventariosPresentacionColumnas in
    'src\Forms\inMtoInventariosPresentacionColumnas.pas',
  inMtoInventariosPresentacionEntrada in
    'src\Forms\inMtoInventariosPresentacionEntrada.pas',
  inMtoStockConsultaPresentacionArticuloVcl in
    'src\Forms\inMtoStockConsultaPresentacionArticuloVcl.pas',
  inMtoStockConsultaPresentacionComposicion in
    'src\Forms\inMtoStockConsultaPresentacionComposicion.pas',
  inMtoStockConsultaPresentacionFotosVcl in
    'src\Forms\inMtoStockConsultaPresentacionFotosVcl.pas',
  inMtoStockConsultaPresentacionPivoteVcl in
    'src\Forms\inMtoStockConsultaPresentacionPivoteVcl.pas',
  inLibArticulosPresentacion in 'src\Lib\inLibArticulosPresentacion.pas',
  inLibArticulosPresentacionIntf in
    'src\Lib\inLibArticulosPresentacionIntf.pas',
  inLibComprasSesionesPresentacion in
    'src\Lib\inLibComprasSesionesPresentacion.pas',
  inLibComprasSesionesPresentacionIntf in
    'src\Lib\inLibComprasSesionesPresentacionIntf.pas',
  inLibFacturasPresentadorCabecera in
    'src\Lib\inLibFacturasPresentadorCabecera.pas',
  inLibFacturasPresentadorDetalle in
    'src\Lib\inLibFacturasPresentadorDetalle.pas',
  inLibFacturasPresentadorListado in
    'src\Lib\inLibFacturasPresentadorListado.pas',
  inLibInventariosPresentacion in 'src\Lib\inLibInventariosPresentacion.pas',
  inLibInventariosPresentacionIntf in
    'src\Lib\inLibInventariosPresentacionIntf.pas',
  inLibStockConsultaPresentacionCoincidencias in
    'src\Lib\inLibStockConsultaPresentacionCoincidencias.pas',
  inLibStockConsultaPresentacionEstados in
    'src\Lib\inLibStockConsultaPresentacionEstados.pas',
  inLibStockConsultaPresentacionFotos in
    'src\Lib\inLibStockConsultaPresentacionFotos.pas',
  inLibStockConsultaPresentacionHistorial in
    'src\Lib\inLibStockConsultaPresentacionHistorial.pas',
  inLibStockConsultaPresentacionPivote in
    'src\Lib\inLibStockConsultaPresentacionPivote.pas',
  inLibStockConsultaPresentacionPropiedades in
    'src\Lib\inLibStockConsultaPresentacionPropiedades.pas',
  inLibStockConsultaPresentacionVista in
    'src\Lib\inLibStockConsultaPresentacionVista.pas';

{$R *.res}
{$R fondo.res}

function CrearContextoSesionInicial(
  const ARegistroLog: IRegistroLog;
  out AContextoSesion: IContextoSesionAplicacion;
  out AResultadoLicencia: TResultadoLicenciaAplicacion): Boolean;
var
  frmLogon: TfrmLogon;
  AutoLoginCorrecto: Boolean;
  ResultadoInicioSesion: TResultadoInicioSesion;
begin
  Result := False;
  AContextoSesion := nil;
  AResultadoLicencia :=
    TResultadoLicenciaAplicacion.CrearNoComprobada;
  frmLogon := TfrmLogon.Create(Application);
  frmLogon.AsignarRegistroLog(ARegistroLog);
  try
    if not frmLogon.DebeCerrarAplicacion then
    begin
      AutoLoginCorrecto := False;
      if frmLogon.IsInitializeAuto then
      begin
        frmLogon.btnAceptarClick(nil);
        AutoLoginCorrecto :=
          frmLogon.ResultadoInicioSesion.Autenticado;
      end;
      if not AutoLoginCorrecto then
        frmLogon.ShowModal;
      ResultadoInicioSesion := frmLogon.ResultadoInicioSesion;
      if ResultadoInicioSesion.Autenticado then
      begin
        AResultadoLicencia := frmLogon.ResultadoLicencia;
        AContextoSesion := TContextoSesionAplicacion.Create(
          ResultadoInicioSesion.Identidad,
          ResultadoInicioSesion.Ubicacion);
        Result := True;
      end;
    end;
  finally
    frmLogon.Free;
  end;
end;

begin
  var ContextoSesionInicial: IContextoSesionAplicacion;
  var GestorContextoCierre: IGestorContextoSesion;
  var Principal: TfrmMtoPrincipal;
  var RegistroLogAplicacion: IRegistroLog;
  var ResultadoLicenciaInicial: TResultadoLicenciaAplicacion;
//  {$IFDEF DEBUG}
//      ReportMemoryLeaksOnShutdown := True;
//  {$ENDIF}
  // Tracking de excepciones con JCL: rellena E.StackTrace al lanzar
  // cualquier excepcion. AppException en inMtoPrincipal ya vuelca el
  // detalle (incluido el stack) al log y al modal del usuario.
  Include(JclStackTrackingOptions, stStack);
  Include(JclStackTrackingOptions, stStaticModuleList);
  JclStartExceptionTracking;
  TdxDiacriticStringOptions.ComparisonMode :=
                                   TdxDiacriticStringComparisonMode.Insensitive;
  TdxDiacriticStringOptions.NormalizationMode :=
                                     TdxDiacriticStringNormalizationMode.System;
  Application.Initialize;
  ConfigurarLecturasAtributosPaleta(LecturasAtributosPaleta);
  Application.MainFormOnTaskbar := True;
  Application.Title := 'Fzam';
  RegistroLogAplicacion := CrearRegistroLog;
  if CrearContextoSesionInicial(
    RegistroLogAplicacion,
    ContextoSesionInicial,
    ResultadoLicenciaInicial) then
  begin
    // Fuente global para toda la aplicacion
    Application.DefaultFont.Name   := 'Lucida Sans';
    Application.DefaultFont.Height := -15;
    Screen.MenuFont.Name := 'Lucida Sans';
    Screen.MenuFont.Size := 11;
    Application.CreateForm(TfrmMtoPrincipal, Principal);
    Principal.AsignarRegistroLog(RegistroLogAplicacion);
    Principal.AsignarServiciosVisuales(
      CrearBusquedaVisualMto,
      CrearDistribuidorTallasVisualMto,
      CrearSolicitudPermisoLayoutMto,
      CrearPreviewTicketMto,
      CrearProveedorPreviewExcelMto);
    Principal.InicializarAplicacion(
      ContextoSesionInicial,
      ResultadoLicenciaInicial);
    // Diagnóstico: con /teststack se encola una excepción de prueba
    // para verificar JCL stack trace + AppException + log + modal.
//  if FindCmdLineSwitch('teststack', True) then
//    TThread.ForceQueue(nil, procedure
//                            begin
//                              inLibDiag.ProbarStackTrace;
//                            end);
    try
      Application.Run;
    finally
      if Supports(
        ContextoSesionInicial,
        IGestorContextoSesion,
        GestorContextoCierre
      ) then
        GestorContextoCierre.MarcarCierreAplicacion;
      // Principal ya puede estar liberado por FormClose (caFree).
      TVerifactuCola.DetenerHilo;
    end;
    // Salida garantizada del proceso. Una tarea huerfana bloqueada contra
    // MySQL deja colgada la finalizacion de System.Threading (espera a sus
    // workers) y el exe se queda en memoria sin ventanas (visto 14/07/26).
    // Se cierra el log de forma explicita (su finalization ya no correra)
    // y se termina el proceso sin ejecutar las finalizaciones restantes.
    RegistroLogAplicacion.RegistrarInformacion('Salida del proceso');
    RegistroLogAplicacion := nil;
    inLibLog.LiberarLog;
    ExitProcess(0);
  end;
end.
