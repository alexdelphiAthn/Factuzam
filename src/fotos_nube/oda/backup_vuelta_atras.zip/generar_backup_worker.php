<?php
// ----------------------------------------------------------------------
// generar_backup_worker.php
// Worker en background lanzado por generar_backup.php.
// Lee origenes.txt de un cliente, reconstruye cada foto a partir del
// PNG _real en el formato original (.jpg/.png/.webp/.gif) y empaqueta
// todo en un ZIP cifrado con AES-256.
//
// Argumentos:   php generar_backup_worker.php <job_id>
// Contraseña:   se lee de backups/jobs/<job_id>.pwd (se borra al usar)
//
// Solo se ejecuta por CLI. Rechaza requests HTTP.
// ----------------------------------------------------------------------

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    echo "Forbidden\n";
    exit;
}

// ---------- Tiempos / memoria ----------
set_time_limit(0);
ini_set('memory_limit', '512M');

// ---------- Argumentos ----------
if ($argc < 2) {
    fwrite(STDERR, "Uso: php generar_backup_worker.php <job_id>\n");
    exit(2);
}
$jobId = $argv[1];
if (!preg_match('/^[0-9a-f]{32}$/', $jobId)) {
    fwrite(STDERR, "job_id inválido\n");
    exit(2);
}

// ---------- Rutas ----------
$root        = __DIR__;
$baseStorage = $root . DIRECTORY_SEPARATOR . 'cloud_storage';
$backupsDir  = $root . DIRECTORY_SEPARATOR . 'backups';
$jobsDir     = $backupsDir . DIRECTORY_SEPARATOR . 'jobs';
$jobPath     = $jobsDir . DIRECTORY_SEPARATOR . $jobId . '.json';
$pwdPath     = $jobsDir . DIRECTORY_SEPARATOR . $jobId . '.pwd';

// ---------- Cargar job ----------
if (!is_file($jobPath)) {
    fwrite(STDERR, "Job no encontrado: $jobPath\n");
    exit(2);
}
$job = json_decode(file_get_contents($jobPath), true);
if (!is_array($job)) {
    fwrite(STDERR, "Job JSON inválido\n");
    exit(2);
}

// ---------- Cargar password ----------
$password = '';
if (is_file($pwdPath)) {
    $password = file_get_contents($pwdPath);
}
@unlink($pwdPath);  // borrar inmediatamente

if ($password === '' || $password === false) {
    update_job($jobPath, $job, [
        'status'     => 'error',
        'error'      => 'Sin contraseña',
        'updated_at' => date('c'),
    ]);
    exit(1);
}

$carpeta = $job['carpeta_cliente'] ?? '';
$baseDir = $baseStorage . DIRECTORY_SEPARATOR . $carpeta;
if (!is_dir($baseDir)) {
    update_job($jobPath, $job, [
        'status'     => 'error',
        'error'      => 'Carpeta cliente no existe',
        'updated_at' => date('c'),
    ]);
    exit(1);
}

// ---------- Leer origenes.txt ----------
$origenesPath = $baseDir . DIRECTORY_SEPARATOR . 'origenes.txt';
if (!is_file($origenesPath)) {
    update_job($jobPath, $job, [
        'status'     => 'error',
        'error'      => 'No hay origenes.txt (no se puede reconstruir)',
        'updated_at' => date('c'),
    ]);
    exit(1);
}

$entradas = [];  // [{nombre_real_png, subcarpeta, nombre_fichero}]
$fh = fopen($origenesPath, 'r');
if ($fh) {
    while (($linea = fgets($fh)) !== false) {
        $linea = rtrim($linea, "\r\n");
        if ($linea === '') continue;
        $cols = explode("\t", $linea);
        // Formato esperado:
        // 0: osha1
        // 1: NOMBRE_real.png
        // 2: carpeta_base
        // 3: subcarpeta
        // 4: nombre_fichero
        // 5: ruta_completa
        if (count($cols) < 5) continue;
        $entradas[] = [
            'png_name'       => $cols[1],
            'subcarpeta'     => $cols[3] ?? '',
            'nombre_fichero' => $cols[4] ?? '',
        ];
    }
    fclose($fh);
}

$total = count($entradas);
update_job($jobPath, $job, [
    'status'     => 'running',
    'progress'   => 0,
    'total'      => $total,
    'updated_at' => date('c'),
]);

if ($total === 0) {
    update_job($jobPath, $job, [
        'status'     => 'error',
        'error'      => 'origenes.txt vacío, nada que reconstruir',
        'updated_at' => date('c'),
    ]);
    exit(1);
}

// ---------- Limpiar ZIPs antiguos de este cliente ----------
$patron = $backupsDir . DIRECTORY_SEPARATOR . 'backup_' . $carpeta . '_*.zip';
foreach (glob($patron) ?: [] as $f) {
    @unlink($f);
}

// ---------- Crear ZIP ----------
$nombreZip = sprintf(
    'backup_%s_%s_%s.zip',
    $carpeta,
    date('Ymd_His'),
    bin2hex(random_bytes(4))
);
$zipPath = $backupsDir . DIRECTORY_SEPARATOR . $nombreZip;

$zip = new ZipArchive();
$flags = ZipArchive::CREATE | ZipArchive::OVERWRITE;
if ($zip->open($zipPath, $flags) !== true) {
    update_job($jobPath, $job, [
        'status'     => 'error',
        'error'      => 'No se pudo crear el ZIP',
        'updated_at' => date('c'),
    ]);
    exit(1);
}

// Cifrado: ZipArchive::EM_AES_256 requiere PHP 7.2+ con libzip >= 1.5
$cifrado = false;
if (defined('ZipArchive::EM_AES_256')) {
    $zip->setPassword($password);
    $cifrado = true;  // se aplicará por entrada con setEncryptionName
}

// ---------- Procesar entradas ----------
// Buffer para flush periódico al JSON del job (no en cada foto)
$ultimoFlush = microtime(true);
$flushCadaSeg = 1.0;

$procesadas = 0;
$errores    = 0;

foreach ($entradas as $i => $e) {
    $procesadas++;
    $pngPath = $baseDir . DIRECTORY_SEPARATOR . $e['png_name'];
    if (!is_file($pngPath)) {
        $errores++;
        continue;
    }

    $nombreFichero = $e['nombre_fichero'];
    if ($nombreFichero === '') {
        // Si no hay nombre original, usar el del PNG quitando "_real.png"
        $nombreFichero = substr($e['png_name'], 0, -9) . '.png';
    }

    // Ruta dentro del ZIP (siempre con "/", convención ZIP)
    $rutaZip = '';
    if ($e['subcarpeta'] !== '') {
        $rutaZip = str_replace('\\', '/', $e['subcarpeta']);
        $rutaZip = trim($rutaZip, '/') . '/';
    }
    $rutaZip .= $nombreFichero;

    // Determinar formato destino por extensión del nombre original
    $ext  = strtolower(pathinfo($nombreFichero, PATHINFO_EXTENSION));
    $bytesDestino = null;

    if ($ext === 'png') {
        // Sin conversión, copiamos el PNG tal cual
        $bytesDestino = @file_get_contents($pngPath);
    } else {
        // Necesitamos convertir
        $bytesDestino = convertir_imagen($pngPath, $ext);
    }

    if ($bytesDestino === null || $bytesDestino === false) {
        $errores++;
        continue;
    }

    if (!$zip->addFromString($rutaZip, $bytesDestino)) {
        $errores++;
        continue;
    }
    if ($cifrado) {
        $zip->setEncryptionName($rutaZip, ZipArchive::EM_AES_256);
    }

    // Flush del progreso cada ~1 segundo
    if (microtime(true) - $ultimoFlush >= $flushCadaSeg) {
        update_job($jobPath, $job, [
            'progress'   => $procesadas,
            'updated_at' => date('c'),
        ]);
        $ultimoFlush = microtime(true);
    }
}

// ---------- Cerrar ZIP (aquí se escribe en disco realmente) ----------
update_job($jobPath, $job, [
    'progress'   => $procesadas,
    'status'     => 'finishing',
    'updated_at' => date('c'),
]);

if (!$zip->close()) {
    update_job($jobPath, $job, [
        'status'     => 'error',
        'error'      => 'Error al cerrar el ZIP',
        'updated_at' => date('c'),
    ]);
    exit(1);
}

$size = @filesize($zipPath) ?: 0;

// ---------- Marcar job como OK ----------
update_job($jobPath, $job, [
    'status'     => 'done',
    'progress'   => $procesadas,
    'errores'    => $errores,
    'cifrado'    => $cifrado,
    'archivo'    => $nombreZip,
    'url'        => 'backups/' . $nombreZip,
    'size'       => $size,
    'updated_at' => date('c'),
]);

exit(0);

// ----------------------------------------------------------------------
function update_job(string $jobPath, array &$job, array $cambios): void
{
    foreach ($cambios as $k => $v) {
        $job[$k] = $v;
    }
    // Escritura atómica: tmp + rename
    $tmp = $jobPath . '.tmp';
    file_put_contents($tmp, json_encode($job, JSON_PRETTY_PRINT));
    @rename($tmp, $jobPath);
}

/**
 * Convierte el PNG _real al formato indicado por la extensión.
 * Devuelve los bytes del fichero destino, o null/false en error.
 */
function convertir_imagen(string $pngPath, string $extDestino)
{
    if (!extension_loaded('gd')) {
        return null;
    }
    $img = @imagecreatefrompng($pngPath);
    if (!$img) return null;

    ob_start();
    $ok = false;
    switch ($extDestino) {
        case 'jpg':
        case 'jpeg':
            // JPEG no soporta alfa: aplanar sobre blanco
            $w = imagesx($img);
            $h = imagesy($img);
            $flat = imagecreatetruecolor($w, $h);
            $white = imagecolorallocate($flat, 255, 255, 255);
            imagefilledrectangle($flat, 0, 0, $w, $h, $white);
            imagecopy($flat, $img, 0, 0, 0, 0, $w, $h);
            $ok = imagejpeg($flat, null, 95);
            imagedestroy($flat);
            break;
        case 'webp':
            if (function_exists('imagewebp')) {
                $ok = imagewebp($img, null, 95);
            }
            break;
        case 'gif':
            $ok = imagegif($img);
            break;
        case 'bmp':
            if (function_exists('imagebmp')) {
                $ok = imagebmp($img);
            }
            break;
        default:
            // extensión desconocida: dejamos como PNG
            $ok = imagepng($img, null, 8);
    }
    $data = ob_get_clean();
    imagedestroy($img);
    return $ok ? $data : null;
}
