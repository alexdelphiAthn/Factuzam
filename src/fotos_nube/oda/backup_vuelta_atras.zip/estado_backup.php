<?php
// ----------------------------------------------------------------------
// estado_backup.php
// Devuelve el estado actual de un job de backup.
// GET params: job_id
// ----------------------------------------------------------------------

ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_DEPRECATED);
header('Content-Type: application/json');

// ---------- 1. API key ----------
$apiKeyEsperada = 'k7Hq9mZ2pXvR4nL8';
if (($_SERVER['HTTP_X_API_KEY'] ?? '') !== $apiKeyEsperada) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'No autorizado.']);
    exit;
}

// ---------- 2. Método ----------
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido.']);
    exit;
}

// ---------- 3. Parámetros ----------
$jobId = $_GET['job_id'] ?? '';
if (!preg_match('/^[0-9a-f]{32}$/', $jobId)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'job_id inválido.']);
    exit;
}

// ---------- 4. Leer JSON ----------
$jobPath = __DIR__ . DIRECTORY_SEPARATOR . 'backups' . DIRECTORY_SEPARATOR .
           'jobs' . DIRECTORY_SEPARATOR . $jobId . '.json';

if (!is_file($jobPath)) {
    http_response_code(404);
    echo json_encode(['status' => 'error', 'message' => 'Job no encontrado.']);
    exit;
}

$contenido = @file_get_contents($jobPath);
if ($contenido === false) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'No se pudo leer el job.']);
    exit;
}

$job = json_decode($contenido, true);
if (!is_array($job)) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Job JSON corrupto.']);
    exit;
}

// Asegurar que devolvemos status:ok en el envoltorio (status del job va dentro)
echo json_encode([
    'status' => 'ok',
    'job'    => $job,
]);
