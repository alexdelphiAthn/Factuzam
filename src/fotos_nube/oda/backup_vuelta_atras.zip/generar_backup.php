<?php
// ----------------------------------------------------------------------
// generar_backup.php
// Crea un trabajo de backup, lo lanza en segundo plano y devuelve el
// job_id inmediatamente. El cliente sondea estado_backup.php para ver
// el progreso y obtener el nombre del .zip final.
//
// POST params: carpeta_cliente, password
// ----------------------------------------------------------------------

ini_set('display_errors', '0');
error_reporting(E_ALL & ~E_DEPRECATED);
header('Content-Type: application/json');

// ---------- 1. API key ----------
$apiKeyEsperada = 'k7Hq9mZ2pXvR4nL8';
if (($_SERVER['HTTP_X_API_KEY'] ?? '') !== $apiKeyEsperada) {
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'No autorizado.']);
    exit;
}

// ---------- 2. Método ----------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Método no permitido.']);
    exit;
}

// ---------- 3. Parámetros ----------
$carpetaRaw = $_POST['carpeta_cliente'] ?? '';
$password   = $_POST['password']        ?? '';

$carpeta = preg_replace('/[^A-Za-z0-9_-]/', '_', $carpetaRaw);
if ($carpeta === '') {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Falta carpeta_cliente.']);
    exit;
}
if ($password === '') {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Falta la contraseña.']);
    exit;
}

// ---------- 4. Validar carpeta del cliente ----------
$baseStorage = __DIR__ . DIRECTORY_SEPARATOR . 'cloud_storage';
$baseDir     = $baseStorage . DIRECTORY_SEPARATOR . $carpeta;
if (!is_dir($baseDir)) {
    http_response_code(404);
    echo json_encode([
        'status'          => 'error',
        'message'         => 'Carpeta de cliente no encontrada.',
        'carpeta_cliente' => $carpeta,
    ]);
    exit;
}

// ---------- 5. Directorios de jobs y backups ----------
$backupsDir = __DIR__ . DIRECTORY_SEPARATOR . 'backups';
$jobsDir    = $backupsDir . DIRECTORY_SEPARATOR . 'jobs';
if (!is_dir($backupsDir)) @mkdir($backupsDir, 0775, true);
if (!is_dir($jobsDir))    @mkdir($jobsDir,    0775, true);
if (!is_dir($jobsDir) || !is_writable($jobsDir)) {
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => 'No se puede crear/escribir el directorio de jobs.',
    ]);
    exit;
}

// ---------- 6. Crear job ----------
$jobId   = bin2hex(random_bytes(16));
$jobPath = $jobsDir . DIRECTORY_SEPARATOR . $jobId . '.json';
$pwdPath = $jobsDir . DIRECTORY_SEPARATOR . $jobId . '.pwd';

$job = [
    'job_id'          => $jobId,
    'carpeta_cliente' => $carpeta,
    'status'          => 'pending',
    'progress'        => 0,
    'total'           => 0,
    'archivo'         => null,
    'url'             => null,
    'size'            => null,
    'error'           => null,
    'created_at'      => date('c'),
    'updated_at'      => date('c'),
];
file_put_contents($jobPath, json_encode($job, JSON_PRETTY_PRINT));

// Guardar la contraseña en un fichero temporal con permisos restringidos
// (no la pasamos por argv para que no aparezca en ps/tasklist).
file_put_contents($pwdPath, $password);
@chmod($pwdPath, 0600);

// ---------- 7. Lanzar worker en background ----------
$workerScript = __DIR__ . DIRECTORY_SEPARATOR . 'generar_backup_worker.php';
$phpBin       = PHP_BINARY;
$stdoutPath   = $jobsDir . DIRECTORY_SEPARATOR . $jobId . '.out';
$stderrPath   = $jobsDir . DIRECTORY_SEPARATOR . $jobId . '.err';

$launched    = false;
$launchError = '';

try {
    if (stripos(PHP_OS, 'WIN') === 0) {
        // Windows: usar "start /B" para que el proceso quede desvinculado.
        // El worker leerá la pwd del fichero .pwd, no necesitamos pipes.
        $cmd = sprintf(
            'start /B "" "%s" "%s" "%s" > "%s" 2> "%s"',
            $phpBin, $workerScript, $jobId, $stdoutPath, $stderrPath
        );
        // pclose+popen es la forma fiable de "dispara y olvida" en Windows
        $h = popen($cmd, 'r');
        if ($h !== false) {
            pclose($h);
            $launched = true;
        } else {
            $launchError = 'popen falló';
        }
    } else {
        // Linux / Mac: nohup + & para desvincular
        $cmd = sprintf(
            'nohup %s %s %s > %s 2> %s < /dev/null &',
            escapeshellarg($phpBin),
            escapeshellarg($workerScript),
            escapeshellarg($jobId),
            escapeshellarg($stdoutPath),
            escapeshellarg($stderrPath)
        );
        exec($cmd, $out, $rc);
        $launched = ($rc === 0);
        if (!$launched) {
            $launchError = 'exec rc=' . $rc;
        }
    }
} catch (Throwable $e) {
    $launchError = $e->getMessage();
}

if (!$launched) {
    @unlink($pwdPath);
    $job['status']     = 'error';
    $job['error']      = 'No se pudo lanzar el worker: ' . $launchError;
    $job['updated_at'] = date('c');
    file_put_contents($jobPath, json_encode($job, JSON_PRETTY_PRINT));
    http_response_code(500);
    echo json_encode([
        'status'  => 'error',
        'message' => $job['error'],
        'job_id'  => $jobId,
    ]);
    exit;
}

// ---------- 8. Responder ----------
echo json_encode([
    'status'  => 'ok',
    'job_id'  => $jobId,
    'message' => 'Backup en curso. Sondea con estado_backup.php?job_id=' . $jobId,
]);
